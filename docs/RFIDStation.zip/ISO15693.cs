using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Resources;

namespace RFIDStation
{
    public partial class ISO15693 : Form
    {
        ResourceManager res = new ResourceManager(typeof(ISO15693));
        private int serialDevice;                   //�����豸
        public static Thread receiveFrameThread = null;
        public bool bOperatingSerial;

        public delegate void Delegate(object obj);

        public RFIDStation fatherForm;

        private ushort[] opDeviceAddr = new ushort[2];
        private Byte[] opTagUid = new Byte[8 * 256];
        private int opTagUidNum = 0;
        private Byte[] opTagBlockAddr = new Byte[8];
        private Byte opTagBlockNum = 0;
        private Byte[] opTagBlock = new Byte[8 * 256 * 8];

        private int directOpTimer = 0;
        private int directOpTagMode = 0;

        private Byte imOpTagMode = 0;

        private Byte gateAlarmMode = 0;

        private Byte imOpAnt = 0;
        private ISO15693_IMOP iso15693ImOp;
        private int imOpTagNum = 0;
        private int imOpTestNum = 0;
        private int imOpTestOkNum = 0;

        private void ISO15693_FormClosing(object sender, FormClosingEventArgs e)
        {
            fatherForm.Enabled = true;
            DisableIso15693();
            Dispose();
            Close();
        }

        public ISO15693()
        {
            ChangeLang.LoadLanguage(this, typeof(ISO15693));
            InitializeComponent();
            serialDevice = -1;
            bOperatingSerial = false;

            this.textBoxWMBlockData.Text = "01020304\r\n01020304";
            comboBoxImOpMode.SelectedIndex = 0;
            comboBoxImOpAnt.SelectedIndex = 0;

            iso15693ImOp = new ISO15693_IMOP();
            iso15693ImOp.antAddr = new Byte[255];
            iso15693ImOp.opBlockResult = new Byte[256];
            iso15693ImOp.blockAddr = new Byte[8];
            iso15693ImOp.block = new Byte[256 * 32 * 4];
            iso15693ImOp.uid = new Byte[256 * 8];
            comboBoxOpTag.SelectedIndex = 0;

            comboBoxEnableGateMode.SelectedIndex = 0;

            receiveFrameThread = new Thread(new ThreadStart(ReceiveFrame));
            receiveFrameThread.IsBackground = true;
            receiveFrameThread.Start();
        }

        public void EnableIso15693(int h)
        {
            serialDevice = h;
            this.tabControlISO15693TagOp.Enabled = true;
        }

        public void DisableIso15693()
        {
            this.tabControlISO15693TagOp.Enabled = false;
            serialDevice = -1;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxInf.Invoke(d, obj);
            }
            else
            {
                if (obj == null)
                {
                    this.textBoxInf.Text = "";
                }
                else
                {
                    this.textBoxInf.Text = obj.ToString();
                }
            }
        }

        private void AddOpTagInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddOpTagInfo);
                this.textBoxOpTagInfo.Invoke(d, obj);
            }
            else
            {
                this.textBoxOpTagInfo.Text = obj.ToString();
            }
        }

        private void AddGateAlarmTagInfo(object obj)
        {
            if (this.textBoxGateAlarmUid.InvokeRequired)
            {
                Delegate d = new Delegate(AddGateAlarmTagInfo);
                this.textBoxGateAlarmUid.Invoke(d, obj);
            }
            else
            {
                this.textBoxGateAlarmUid.Text = this.textBoxGateAlarmUid.Text;
            }
        }

        private void AddImOpTagInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddImOpTagInfo);
                this.textBoxImTagInfo.Invoke(d, obj);
            }
            else
            {
                this.textBoxImTagInfo.Text = obj.ToString();
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            if (pSendBuf[2] == 0)
            {
                len = 13 + pSendBuf[9] + pSendBuf[10] * 256;
            }
            String s = cmdNmae;
            for (i = 0; i < len; i++)
            {
                s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                s += " ";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxInf.Text = res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxInf.Text = res.GetString("Operror1") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxInf.Text = res.GetString("Operror2") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxInf.Text = res.GetString("Operror3") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxInf.Text = res.GetString("Operror4") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else
                {
                    this.textBoxInf.Text = res.GetString("Operror5") + "\r\n\r\n" + this.textBoxInf.Text;
                }
            }
        }

        //��ʾ������Ϣ
        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;
            if (pRcvBuf[2] == 0)
            {
                len = 14 + pRcvBuf[10] + pRcvBuf[11] * 256;
            }
            String s = cmdNmae;
            if (pRcvBuf[0] == 0x7E && pRcvBuf[1] == 0x55)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n"+res.GetString("Operror6")+"\r\n";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        private string DirectReadTagUid(ref Byte[] uid, ref int tagNum, ref long delay)
        {
            int rlt = 0;
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            string sList = "";
            Byte[] blockAddr = new Byte[4];
            Byte[] block = new Byte[1024];
            Stopwatch sw = new Stopwatch();
            if (checkBoxWaitTime.Checked == false)
            {
                sw.Start();
                rlt = hfReaderDll.iso15693OpTagsRUidAndBlock(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, 0, uid, block, sendBuffer, rcvBuffer);
                sw.Stop();
            }
            else
            {
                sw.Start();
                rlt = hfReaderDll.iso15693ReadDishTags(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, 0, uid, block, 20, sendBuffer, rcvBuffer);
                sw.Stop();
            }
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                tagNum = rlt / hfReaderDll.HFREADER_ISO15693_SIZE_UID;
                int i = 0, j = 0;
                string sUid = "";
                for (i = 0; i < opTagUidNum; i++)
                {
                    sUid = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "        " + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess")+"\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String1"));
            DisplaySendInf(sendBuffer, res.GetString("String2"));

            return sList;
        }

        //��ȡUID�����ݿ�
        private string DirectReadTagUidAndBlock(ref Byte[] uid, ref int tagNum, ref Byte[] block, Byte[] blockAddr, int blockNum, ref long delay)
        {
            int rlt = 0;
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            string sList = "";
            Stopwatch sw = new Stopwatch();
            if (checkBoxWaitTime.Checked == false)
            {
                sw.Start();
                rlt = hfReaderDll.iso15693OpTagsRUidAndBlock(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, (byte)blockNum, uid, block, sendBuffer, rcvBuffer);
                sw.Stop();
            }
            else
            {
                sw.Start();
                rlt = hfReaderDll.iso15693ReadDishTags(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, (byte)blockNum, uid, block, 20, sendBuffer, rcvBuffer);
                sw.Stop();
            }
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                tagNum = rlt / hfReaderDll.HFREADER_ISO15693_SIZE_UID;
                int i = 0, j = 0;
                string sUid = "", sBlock = "";
                for (i = 0; i < opTagUidNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum; j++)
                    {
                        sBlock += block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum + j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sBlock + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String3"));
            DisplaySendInf(sendBuffer, res.GetString("String4"));

            return sList;
        }

        //ֱ��д���ݿ�
        private string DirectWriteBlock(Byte[] uid, int tagNum, Byte[] blockAddr, int blockNum, ref long delay)
        {
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            Byte[] block = new Byte[tagNum * blockNum * 4];
            Byte[] result = new Byte[tagNum * blockNum];

            int i = 0, j = 0;
            for (i = 0; i < tagNum; i++)
            {
                for (j = 0; j < blockNum; j++)
                {
                    directOpTimer++;
                    block[(i * blockNum + j) * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 0] = (Byte)((directOpTimer >> 0) & 0xFF);
                    block[(i * blockNum + j) * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 1] = (Byte)((directOpTimer >> 8) & 0xFF);
                    block[(i * blockNum + j) * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 2] = (Byte)((directOpTimer >> 16) & 0xFF);
                    block[(i * blockNum + j) * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 3] = (Byte)((directOpTimer >> 24) & 0xFF);
                }
            }

            string sList = "";
            Stopwatch sw = new Stopwatch();
            sw.Start();
            int rlt = hfReaderDll.iso15693OpTagsWriteBlock(serialDevice, 0x0000, opDeviceAddr[1], 3000, 9000, (byte)tagNum, uid, (byte)blockNum, blockAddr, block, result, sendBuffer, rcvBuffer);
            sw.Stop();
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                string sUid = "", sBlock = "", sResult = "";
                for (i = 0; i < tagNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    sResult = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < blockNum; j++)
                    {
                        sResult += result[i * blockNum + j].ToString("X").PadLeft(1);
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum; j++)
                    {
                        sBlock += block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum + j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sResult + "    " + sBlock + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String5"));
            DisplaySendInf(sendBuffer, res.GetString("String6"));

            return sList;
        }

        private string DirectWriteAfi(Byte[] uid, int tagNum, ref long delay)
        {
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            Byte[] result = new Byte[tagNum];
            int i = 0, j = 0;

            string sList = "";
            Stopwatch sw = new Stopwatch();
            directOpTimer++;
            sw.Start();
            int rlt = hfReaderDll.iso15693OpTagsWriteAfi(serialDevice, 0x0000, opDeviceAddr[1], 5000, 9000, (byte)tagNum, uid, (byte)directOpTimer, result, sendBuffer, rcvBuffer);
            sw.Stop();
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                string sUid = "", sResult = "";
                for (i = 0; i < tagNum; i++)
                {
                    sUid = "";
                    sResult = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    sResult += result[i].ToString("X").PadLeft(1);
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sResult + "    " + (directOpTimer & 0xFF).ToString("X").PadLeft(2, '0') + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String7"));
            DisplaySendInf(sendBuffer, res.GetString("String8"));

            return sList;
        }

        //ֱ��д���ݿ�
        private string DirectReadUidAndWriteBlock(Byte[] uid, ref int tagNum, Byte[] blockAddr, int blockNum, ref long delay)
        {
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            Byte[] block = new Byte[256 * blockNum * 4];
            Byte[] result = new Byte[256 * blockNum];
            Byte[] num = new Byte[1];

            int i = 0;
            for (i = 0; i < blockNum; i++)
            {
                directOpTimer++;
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 0] = (Byte)((directOpTimer >> 0) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 1] = (Byte)((directOpTimer >> 8) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 2] = (Byte)((directOpTimer >> 16) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 3] = (Byte)((directOpTimer >> 24) & 0xFF);
            }

            string sList = "";
            Stopwatch sw = new Stopwatch();
            sw.Start();
            int rlt = hfReaderDll.iso15693OpTagsRUidAndWBlock(serialDevice, 0x0000, opDeviceAddr[1], 3000, 9000, num, uid, (byte)blockNum, blockAddr, block, result, sendBuffer, rcvBuffer);
            sw.Stop();
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                string sUid = "", sBlock = "", sResult = "";
                tagNum = num[0];
                for (i = 0; i < tagNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    sResult = "";
                    int j = 0;

                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < blockNum; j++)
                    {
                        sResult += result[i * blockNum + j].ToString("X").PadLeft(1);
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum; j++)
                    {
                        sBlock += block[j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sResult + "    " + sBlock + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String9"));
            DisplaySendInf(sendBuffer, res.GetString("String10"));

            return sList;
        }


        private string DirectReadOneTagUid(ref Byte[] uid, ref int tagNum, ref long delay)
        {
            int rlt = 0;
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            string sList = "";
            Byte[] blockAddr = new Byte[4];
            Byte[] block = new Byte[1024];
            Stopwatch sw = new Stopwatch();

            sw.Start();
            rlt = hfReaderDll.iso15693OpTagRUidAndBlock(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, 0, uid, block, sendBuffer, rcvBuffer);
            sw.Stop();

            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                tagNum = rlt / hfReaderDll.HFREADER_ISO15693_SIZE_UID;
                int i = 0, j = 0;
                string sUid = "";
                for (i = 0; i < opTagUidNum; i++)
                {
                    sUid = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "        " + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String11"));
            DisplaySendInf(sendBuffer, res.GetString("String12"));

            return sList;
        }

        //��ȡUID�����ݿ�
        private string DirectReadOneTagUidAndBlock(ref Byte[] uid, ref int tagNum, ref Byte[] block, Byte[] blockAddr, int blockNum, ref long delay)
        {
            int rlt = 0;
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            string sList = "";
            Stopwatch sw = new Stopwatch();

            sw.Start();
            rlt = hfReaderDll.iso15693OpTagRUidAndBlock(serialDevice, 0x0000, opDeviceAddr[1], blockAddr, (byte)blockNum, uid, block, sendBuffer, rcvBuffer);
            sw.Stop();

            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                tagNum = rlt / hfReaderDll.HFREADER_ISO15693_SIZE_UID;
                int i = 0, j = 0;
                string sUid = "", sBlock = "";
                for (i = 0; i < opTagUidNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum; j++)
                    {
                        sBlock += block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum + j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sBlock + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String13"));
            DisplaySendInf(sendBuffer, res.GetString("String14"));

            return sList;
        }

        //ֱ��д���ݿ�
        private string DirectReadOneUidAndWriteBlock(Byte[] uid, ref int tagNum, Byte[] blockAddr, int blockNum, ref long delay)
        {
            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];
            Byte[] block = new Byte[256 * blockNum * 4];
            Byte[] result = new Byte[256 * blockNum];
            Byte[] num = new Byte[1];

            int i = 0;
            for (i = 0; i < blockNum; i++)
            {
                directOpTimer++;
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 0] = (Byte)((directOpTimer >> 0) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 1] = (Byte)((directOpTimer >> 8) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 2] = (Byte)((directOpTimer >> 16) & 0xFF);
                block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + 3] = (Byte)((directOpTimer >> 24) & 0xFF);
            }

            string sList = "";
            Stopwatch sw = new Stopwatch();
            sw.Start();
            int rlt = hfReaderDll.iso15693OpTagRUidAndWBlock(serialDevice, 0x0000, opDeviceAddr[1], 3000, 9000, num, uid, (byte)blockNum, blockAddr, block, result, sendBuffer, rcvBuffer);
            sw.Stop();
            delay = sw.ElapsedMilliseconds;
            AddDisplayInfo(null);
            if (rlt > 0)
            {
                string sUid = "", sBlock = "", sResult = "";
                tagNum = num[0];
                for (i = 0; i < tagNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    sResult = "";
                    int j = 0;

                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < blockNum; j++)
                    {
                        sResult += result[i * blockNum + j].ToString("X").PadLeft(1);
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum; j++)
                    {
                        sBlock += block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * blockNum + j].ToString("X").PadLeft(2, '0');
                    }
                    sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sResult + "    " + sBlock + "\r\n";
                }
            }
            else
            {
                tagNum = 0;
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String15"));
            DisplaySendInf(sendBuffer, res.GetString("String16"));

            return sList;
        }

        //ֱ�Ӳ���
        private void DirOpTag()
        {
            string sInfo = "", sResult = "";
            long opDelay = 0;
            
            if (directOpTagMode == 1) //ֻ��UID
            {
                sInfo = DirectReadTagUid(ref opTagUid, ref opTagUidNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 2) //UID+���ݿ�
            {
                sInfo = DirectReadTagUidAndBlock(ref opTagUid, ref opTagUidNum, ref opTagBlock, opTagBlockAddr, opTagBlockNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 3) //д���ݿ�
            {
                sInfo = DirectWriteBlock(opTagUid, opTagUidNum, opTagBlockAddr, opTagBlockNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 4)  //дAFI
            {
                sInfo = DirectWriteAfi(opTagUid, opTagUidNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 5)  //ֱ�Ӷ�UID��д���ݿ�
            {
                opTagUidNum = 0;
                sInfo = DirectReadUidAndWriteBlock(opTagUid, ref opTagUidNum, opTagBlockAddr, opTagBlockNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            if (directOpTagMode == 6) //ֻ��UID
            {
                sInfo = DirectReadOneTagUid(ref opTagUid, ref opTagUidNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 7) //UID+���ݿ�
            {
                sInfo = DirectReadOneTagUidAndBlock(ref opTagUid, ref opTagUidNum, ref opTagBlock, opTagBlockAddr, opTagBlockNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            else if (directOpTagMode == 8)  //ֱ�Ӷ�UID��д���ݿ�
            {
                opTagUidNum = 0;
                sInfo = DirectReadOneUidAndWriteBlock(opTagUid, ref opTagUidNum, opTagBlockAddr, opTagBlockNum, ref opDelay);
                sResult = res.GetString("String17") + opTagUidNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }
            AddOpTagInfo(sResult + sInfo);
            Thread.Sleep(100);
        }

        private void ImOpTag()
        {
            string sInfo = "", sResult = "";
            long opDelay = 0;

            Byte[] rcvBuffer = new Byte[4096];
            Byte[] sendBuffer = new Byte[4096];

            iso15693ImOp.timeout = 20000;
            iso15693ImOp.tagNum = 0;
            iso15693ImOp.tagQuite = 0;
            Stopwatch sw = new Stopwatch();
            sw.Start();
            int rlt = hfReaderDll.iso15693ImOp(serialDevice, 0x0000, opDeviceAddr[1], ref iso15693ImOp, sendBuffer, rcvBuffer);
            sw.Stop();
            AddDisplayInfo(null);
            opDelay = sw.ElapsedMilliseconds;
            if (rlt > 0)
            {
                int i = 0, j = 0;
                string sUid = "", sBlock = "";
                for (i = 0; i < iso15693ImOp.tagNum; i++)
                {
                    sUid = "";
                    sBlock = "";
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                    {
                        sUid += iso15693ImOp.uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + hfReaderDll.HFREADER_ISO15693_SIZE_UID - 1 - j].ToString("X").PadLeft(2, '0');
                    }
                    for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * iso15693ImOp.blockNum; j++)
                    {
                        sBlock += iso15693ImOp.block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * iso15693ImOp.blockNum + j].ToString("X").PadLeft(2, '0');
                    }
                    sInfo += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "    " + sBlock + "\r\n";
                }
                if (imOpTagNum == 0)
                {
                    imOpTagNum = (int)iso15693ImOp.tagNum;
                    if (imOpTagNum > 0)
                    {
                        imOpTestNum = 0;
                        imOpTestOkNum = 0;
                    }
                }
            }
            if (rcvBuffer[0] == 0x7E && rcvBuffer[1] == 0x55)
            {
                AddDisplayInfo(res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text);
            }

            if (imOpTagNum > 0)
            {
                imOpTestNum++;
                if (imOpTagNum == iso15693ImOp.tagNum)
                {
                    imOpTestOkNum++;
                }
                sResult = res.GetString("String17") + iso15693ImOp.tagNum.ToString() + res.GetString("String18") + opDelay.ToString() + res.GetString("String19") + imOpTestNum.ToString() + res.GetString("String20") + imOpTestOkNum.ToString() + res.GetString("String21") + (imOpTestOkNum * 100.0 / imOpTestNum).ToString("F2") + "%\r\n";
            }
            else
            {
                sResult = res.GetString("String17") + iso15693ImOp.tagNum.ToString() + res.GetString("String18") + opDelay.ToString() + "ms\r\n";
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String22"));
            DisplaySendInf(sendBuffer, res.GetString("String23"));

            AddImOpTagInfo(sResult + sInfo);
            Thread.Sleep(100);
        }

        private void ReceiveFrame()
        {
            while (true)
            {
                if (serialDevice > 0 && (!bOperatingSerial))
                {
                    //��ȫ��
                    if (gateAlarmMode > 0)
                    {
                        #region ��ȫ��

                        Byte[] txFrame = new Byte[4096];
                        Byte[] rxFrame = new Byte[4096];
                        ISO15693_GATEUIDPARAM uidsParams = new ISO15693_GATEUIDPARAM();
                        uidsParams.uid = new Byte[hfReaderDll.HFREADER_ISO15693_GATE_ALARM_UID_NUM * hfReaderDll.HFREADER_ISO15693_SIZE_UID];
                        uidsParams.rssi = new uint[hfReaderDll.HFREADER_ISO15693_GATE_ALARM_UID_NUM];

                        uidsParams.num = 0;
                        int rlt = hfReaderDll.iso15693GetGateAlarmUid(serialDevice, 0x0000, 0x0001, ref uidsParams, txFrame, rxFrame);
                        if (uidsParams.num > 0)
                        {
                            int i = 0, j = 0;
                            string sUid = "", rssiStr = "", sList = "";
                            sList += "���ߣ�" + (uidsParams.ant + 1).ToString() + "\r\n";
                            for (i = 0; i < uidsParams.num; i++)
                            {
                                sUid = "";
                                rssiStr = "";
                                for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_UID; j++)
                                {
                                    sUid += uidsParams.uid[i * hfReaderDll.HFREADER_ISO15693_SIZE_UID + j].ToString("X").PadLeft(2, '0');
                                }
                                rssiStr += uidsParams.rssi[i].ToString();
                                sList += (i + 1).ToString("D").PadLeft(2, ' ') + ":" + sUid + "        " + rssiStr + "\r\n";
                            }
                            AddGateAlarmTagInfo(sList);
                        }

                        #endregion ��ȫ��
                    }
                    //ֱ�Ӳ���֡
                    else if (directOpTagMode > 0)
                    {
                        DirOpTag();
                    }
                    else if (imOpTagMode > 0)
                    {
                        ImOpTag();
                    }
                }
            }
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("String24"));
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show(res.GetString("String25"));
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("String24"));
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        private bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            b = fatherForm.GetDeviceAddr(addArray);
            return b;
        }

        private void buttonReadTags_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte mode = 0;

            ISO15693_UIDPARAM pGetUid = new ISO15693_UIDPARAM();
            pGetUid.uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID * hfReaderDll.HFREADER_ISO15693_MAX_UID_NUM];
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            mode = hfReaderDll.HFREADER_READ_UID_NORMAL;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693GetUid(serialDevice, addrArray[0], addrArray[1], mode, ref pGetUid, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pGetUid.result);
                if (pGetUid.num > 0)
                {
                    int i = 0, j = 0;
                    String s;
                    for (i = 0; i < pGetUid.num; i++)
                    {
                        s = "";
                        for (j = 0; j < 8; j++)
                        {
                            s += pGetUid.uid[i * 8 + j].ToString("X").PadLeft(2, '0');
                        }
                        if (this.listBoxUID.FindString(s) < 0)
                        {
                            this.listBoxUID.Items.Add(s);
                        }
                    }
                    this.textBoxReadTagNum.Text = this.listBoxUID.Items.Count.ToString("X").PadLeft(2, '0');
                    this.textBoxRemainTagNum.Text = pGetUid.remainNum.ToString("X").PadLeft(2, '0');
                }
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String26"));
            DisplaySendInf(sendBuffer, res.GetString("String27"));
        }

        private void listBoxUID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listBoxUID.SelectedItem != null)
            {
                this.textBoxSelectedIso15693Uid.Text = this.listBoxUID.SelectedItem.ToString();
            }
        }

        private void buttonClearListBox_Click(object sender, EventArgs e)
        {
            this.textBoxReadTagNum.Text = "00";
            this.textBoxRemainTagNum.Text = "00";
            this.listBoxUID.Items.Clear();
        }

        private void buttonLockBlock_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte[] blockAddr = new Byte[1];
            Byte[] blockNum = new Byte[1];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            Byte[] rcvBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            if (GetHexInput(this.textBoxLBlockAddr.Text, blockAddr, 1) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693LockBlock(serialDevice, addrArray[0], addrArray[1], uid, blockAddr[0], ref pResult, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String28"));
            DisplaySendInf(sendBuffer, res.GetString("String29"));
        }

        //�������ݿ�
        private void buttonReadMBlock_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            Stopwatch sw = new Stopwatch();
            sw.Start();

            int i = 0;

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte[] blockAddr = new Byte[1];
            Byte[] blockNum = new Byte[1];

            ISO15693_BLOCKPARAM pBlock = new ISO15693_BLOCKPARAM();
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM];
            Byte[] sendBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            Byte[] rcvBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            if (GetHexInput(this.textBoxRMBlockAddr.Text, blockAddr, 1) <= 0)
            {
                return;
            }
            pBlock.addr = blockAddr[0];

            if (GetHexInput(this.textBoxRMBlockNum.Text, blockNum, 1) <= 0)
            {
                return;
            }
            pBlock.num = blockNum[0];

           /* if (blockNum[0] > hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM)
            {
                MessageBox.Show(res.GetString("String30") + hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM.ToString("X").PadLeft(2, '0') + res.GetString("String31"));
                return;
            }*/

            while (bOperatingSerial) ;

            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693ReadBlock(serialDevice, addrArray[0], addrArray[1], uid, ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            string strTT = "";

            if (rlt > 0)
            {
                if (pBlock.result.flag == 0)
                {
                    String s = "";
                    int j = 0;
                    for (j = 0; j < pBlock.num; j++)
                    {
                        for (i = 0; i < 4; i++)
                        {
                            s += pBlock.block[j * 4 + i].ToString("X").PadLeft(2, '0');
                        }
                        s += "\r\n";
                    }
                    s += "\r\n";
                    this.textBoxRMBlockData.Text += s;
                }
                DisplayOpResult(pBlock.result);
            }
            sw.Stop();
            strTT = res.GetString("String32");
            DisplayRcvInf(rcvBuffer, strTT);
            DisplaySendInf(sendBuffer, res.GetString("String33"));
        }

        private void buttonWriteMBlock_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            int i = 0;

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte[] blockAddr = new Byte[1];
            Byte[] blockNum = new Byte[1];

            ISO15693_BLOCKPARAM pBlock = new ISO15693_BLOCKPARAM();
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK * hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM];
            Byte[] sendBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            Byte[] rcvBuffer = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxWMBlockAddr.Text, blockAddr, 1) <= 0)
            {
                return;
            }
            pBlock.addr = blockAddr[0];
            if (GetHexInput(this.textBoxWMBlockNum.Text, blockNum, 1) <= 0)
            {
                return;
            }
            pBlock.num = blockNum[0];

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            String s = this.textBoxWMBlockData.Text;
            String[] dataString = new String[32];
            dataString = s.Split('\n');
           /* if (blockNum[0] > hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM)
            {
                MessageBox.Show(res.GetString("String34") + hfReaderDll.HFREADER_ISO15693_MAX_BLOCK_NUM.ToString("X").PadLeft(2, '0') + res.GetString("String31"));
                return;
            }*/
            if (blockNum[0] > dataString.Length)
            {
                MessageBox.Show(res.GetString("String35"));
                return;
            }
            else
            {
                int j = 0;
                for (i = 0; i < blockNum[0]; i++)
                {
                    int pos = dataString[i].IndexOf('\r');
                    Byte[] data = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK];
                    if (pos >= 0)
                    {
                        dataString[i] = dataString[i].Remove(pos);
                    }

                    pos = dataString[i].IndexOf(' ');
                    if (pos >= 0)
                    {
                        dataString[i] = dataString[i].Remove(pos);
                    }

                    s = dataString[i];

                    if (GetHexInput(s, data, hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK) <= 0)
                    {
                        return;
                    }
                    else
                    {
                        for (j = 0; j < hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK; j++)
                        {
                            pBlock.block[i * hfReaderDll.HFREADER_ISO15693_SIZE_BLOCK + j] = data[j];
                        }
                    }
                }
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693WriteBlock(serialDevice, addrArray[0], addrArray[1], uid, ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pBlock.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String36"));
            DisplaySendInf(sendBuffer, res.GetString("String37"));
        }

        private void buttonClearMultBlock_Click(object sender, EventArgs e)
        {
            this.textBoxRMBlockData.Text = "";
        }

        private void buttonCtrlAfi_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte[] afi = new Byte[1];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            if (GetHexInput(this.textBoxAFIValue.Text, afi, 1) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = 0;
            if (this.radioButtonWriteAFI.Checked)
            {
                rlt = hfReaderDll.iso15693WriteAfi(serialDevice, addrArray[0], addrArray[1], uid, afi[0], ref pResult, sendBuffer, rcvBuffer);
            }
            else
            {
                rlt = hfReaderDll.iso15693LockAfi(serialDevice, addrArray[0], addrArray[1], uid, ref pResult, sendBuffer, rcvBuffer);
            }

            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            if (this.radioButtonWriteAFI.Checked)
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String38"));
                DisplaySendInf(sendBuffer, res.GetString("String39"));
            }
            else
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String40"));
                DisplaySendInf(sendBuffer, res.GetString("String41"));
            }
        }

        private void buttonCtrlDsfid_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte[] dsfid = new Byte[1];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            if (GetHexInput(this.textBoxDSFIDValue.Text, dsfid, 1) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = 0;
            if (this.radioButtonWriteDSFID.Checked)
            {
                rlt = hfReaderDll.iso15693WriteDsfid(serialDevice, addrArray[0], addrArray[1], uid, dsfid[0], ref pResult, sendBuffer, rcvBuffer);
            }
            else
            {
                rlt = hfReaderDll.iso15693LockDsfid(serialDevice, addrArray[0], addrArray[1], uid, ref pResult, sendBuffer, rcvBuffer);
            }

            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            if (this.radioButtonWriteDSFID.Checked)
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String42"));
                DisplaySendInf(sendBuffer, res.GetString("String43"));
            }
            else
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String44"));
                DisplaySendInf(sendBuffer, res.GetString("String45"));
            }
        }

        private void buttonCtrlEas_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];
            Byte cmd = 0;

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = 0;
            if (this.radioButtonSetEAS.Checked)
            {
                cmd = hfReaderDll.HFREADER_ISO15693_CMD_SET_EAS;
            }
            else if (this.radioButtonResetEAS.Checked)
            {
                cmd = hfReaderDll.HFREADER_ISO15693_CMD_RESET_EAS;
            }
            else
            {
                cmd = hfReaderDll.HFREADER_ISO15693_CMD_LOCK_EAS;
            }
            rlt = hfReaderDll.iso15693SetEas(serialDevice, addrArray[0], addrArray[1], uid, cmd, ref pResult, sendBuffer, rcvBuffer);

            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            if (this.radioButtonSetEAS.Checked)
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String46"));
                DisplaySendInf(sendBuffer, res.GetString("String47"));
            }
            else if (this.radioButtonResetEAS.Checked)
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String48"));
                DisplaySendInf(sendBuffer, res.GetString("String49"));
            }
            else
            {
                DisplayRcvInf(rcvBuffer, res.GetString("String50"));
                DisplaySendInf(sendBuffer, res.GetString("String51"));
            }
        }

        private void buttonReadTagInf_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO15693_SIZE_UID];
            ushort[] addrArray = new ushort[2];

            ISO15693_TAGPARAM pTagInfo = new ISO15693_TAGPARAM();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxSelectedIso15693Uid.Text, uid, hfReaderDll.HFREADER_ISO15693_SIZE_UID) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693ReadTagInfo(serialDevice, addrArray[0], addrArray[1], uid, ref pTagInfo, sendBuffer, rcvBuffer);

            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pTagInfo.result.flag == 0)
                {
                    this.textBoxTagInfFlag.Text = pTagInfo.infoFlag.ToString("X").PadLeft(2, '0');
                    this.textBoxTagInfDSFID.Text = pTagInfo.dsfid.ToString("X").PadLeft(2, '0');
                    this.textBoxTagInfBlockNum.Text = pTagInfo.blockNum.ToString("X").PadLeft(2, '0');
                    this.textBoxTagInfBlockSize.Text = pTagInfo.blockSize.ToString("X").PadLeft(2, '0');
                    this.textBoxTagInfICRef.Text = pTagInfo.ic.ToString("X").PadLeft(2, '0');
                    this.textBoxTagInfAFI.Text = pTagInfo.afi.ToString("X").PadLeft(2, '0');
                }
                DisplayOpResult(pTagInfo.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String52"));
            DisplaySendInf(sendBuffer, res.GetString("String53"));
        }

        private void buttonClearInfo_Click(object sender, EventArgs e)
        {
            this.textBoxInf.Text = "";
        }

        private void buttonClearTagInfo_Click(object sender, EventArgs e)
        {
            this.textBoxTagInfFlag.Text = "";
            this.textBoxTagInfDSFID.Text = "";
            this.textBoxTagInfBlockNum.Text = "";
            this.textBoxTagInfBlockSize.Text = "";
            this.textBoxTagInfICRef.Text = "";
            this.textBoxTagInfAFI.Text = "";
        }

        private void buttonClearLockBlock_Click(object sender, EventArgs e)
        {
            this.textBoxLBlockAddr.Text = "";
        }

        private void buttonClearWMBlock_Click(object sender, EventArgs e)
        {
            this.textBoxWMBlockData.Text = "";
        }

        private void buttonDtu_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            ushort[] addrArray = new ushort[2];
            Byte[] rxLen = new Byte[1];

            ISO15693_DTU pDtu = new ISO15693_DTU();
            pDtu.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];//hfReaderDll.HFREADER_BUFFER_MAX
            pDtu.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX]; //hfReaderDll.HFREADER_BUFFER_MAX

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxDtuRxLen.Text, rxLen, 1) <= 0)
            {
                return;
            }
            pDtu.rxLen = rxLen[0];

            pDtu.txLen = (uint)(GetHexInput(this.textBoxDtuTx.Text, pDtu.txFrame));

            pDtu.timeout = Convert.ToUInt32(this.textBoxDtuTime.Text, 10);

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso15693Dtu(serialDevice, addrArray[0], addrArray[1], ref pDtu, sendBuffer, rcvBuffer);
            bOperatingSerial = false;

            if (rlt > 0)
            {
                if (pDtu.result.flag == 0)
                {
                    string s = "";
                    for (uint i = 0; i < pDtu.rxLen; i++)
                    {
                        s += pDtu.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxDtuRx.Text = s;
                }
                DisplayOpResult(pDtu.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String54"));
            DisplaySendInf(sendBuffer, res.GetString("String55"));
        }

        private void buttonDtuTxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuTx.Text = "";
        }

        private void buttonDtuRxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuRx.Text = "";
        }

        private void buttonOpTagStart_Click(object sender, EventArgs e)
        {
            if (directOpTagMode > 0)
            {
                buttonOpTagStart.Text = "��ʼ";
                comboBoxOpTag.Enabled = true;

                if (directOpTagMode == 2 || directOpTagMode == 3)
                {
                    textBoxDirOpBlockAddr.Enabled = true;
                }
                else
                {
                    textBoxDirOpBlockAddr.Enabled = false;
                }
                directOpTagMode = 0;

                checkBoxWaitTime.Enabled = true;
                this.fatherForm.Enabled = true;
                this.textBoxInf.Text = "";
            }
            else
            {
                if (serialDevice < 0)
                {
                    MessageBox.Show(res.GetString("Operror7"));
                    return;
                }
                if (!GetDeviceAddr(opDeviceAddr))
                {
                    return;
                }

                int mode = comboBoxOpTag.SelectedIndex + 1;
                if (mode == 2 || mode == 3 || mode == 5 || mode == 7 || mode == 8)
                {
                    int i = 0;
                    Byte[] addr = new Byte[1];
                    string[] addrList = textBoxDirOpBlockAddr.Text.Split('-');
                    opTagBlockNum = 0;
                    for (i = 0; i < 8 && i < addrList.Length; i++)
                    {
                        if (GetHexInput(addrList[i], addr, 1) <= 0)
                        {
                            return;
                        }
                        else
                        {
                            opTagBlockAddr[opTagBlockNum++] = addr[0];
                        }
                    }
                    if (opTagBlockNum == 0)
                    {
                        MessageBox.Show(res.GetString("String56"));
                        return;
                    }
                    else if (opTagBlockNum > 8)
                    {
                        MessageBox.Show(res.GetString("String57"));
                        return;
                    }
                }

                buttonOpTagStart.Text = res.GetString("String58");
                comboBoxOpTag.Enabled = false;
                directOpTimer = 0;
                directOpTagMode = mode;
                if (comboBoxOpTag.SelectedIndex == 1)
                {
                    checkBoxWaitTime.Enabled = true;
                }
                else
                {
                    checkBoxWaitTime.Enabled = false;
                }
                textBoxDirOpBlockAddr.Enabled = false;
                this.fatherForm.Enabled = false;
                this.textBoxInf.Text = "";
            }
        }

        private void tabControlISO15693TagOp_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (directOpTagMode > 0 || gateAlarmMode > 0)
            {
                e.Cancel = true;
            }
        }

        private void comboBoxOpTag_SelectedIndexChanged(object sender, EventArgs e)
        {
            int mode = 0;
            AddOpTagInfo("");

            if (comboBoxOpTag.SelectedIndex == 1)
            {
                checkBoxWaitTime.Enabled = true;
            }
            else
            {
                checkBoxWaitTime.Enabled = false;
                checkBoxWaitTime.Checked = false;
            }

            mode = comboBoxOpTag.SelectedIndex + 1;
            if (mode == 3 || mode == 2 || mode == 5 || mode == 7 || mode == 8)   //op block
            {
                textBoxDirOpBlockAddr.Enabled = true;
            }
            else
            {
                textBoxDirOpBlockAddr.Enabled = false;
            }

            if (mode == 3 || mode == 4)   //write block and write afi need uid
            {
                if (!GetDeviceAddr(opDeviceAddr))
                {
                    return;
                }
                long t = 0;
                string sInfo = DirectReadTagUid(ref opTagUid, ref opTagUidNum, ref t);
                string sResult = res.GetString("String59") + opTagUidNum.ToString() + res.GetString("String60")+ "\r\n";
                AddOpTagInfo(sResult + sInfo);
            }
        }

        private void buttonImOpStart_Click(object sender, EventArgs e)
        {
            if (buttonImOpStart.Text == res.GetString("String61"))
            {
                if (serialDevice < 0)
                {
                    MessageBox.Show(res.GetString("Operror7"));
                    return;
                }

                if (!GetDeviceAddr(opDeviceAddr))
                {
                    return;
                }

                int mode = comboBoxImOpMode.SelectedIndex + 1;
                iso15693ImOp.blockNum = 0;
                if (mode == 2)
                {
                    int i = 0;
                    Byte[] addr = new Byte[1];
                    string[] addrList = textBoxImOpBlockAddr.Text.Split('-');
                    for (i = 0; i < 8 && i < addrList.Length; i++)
                    {
                        if (GetHexInput(addrList[i], addr, 1) <= 0)
                        {
                            return;
                        }
                        else
                        {
                            iso15693ImOp.blockAddr[iso15693ImOp.blockNum++] = addr[0];
                        }
                    }
                    if (iso15693ImOp.blockNum == 0)
                    {
                        MessageBox.Show(res.GetString("String56"));
                        return;
                    }
                    else if (iso15693ImOp.blockNum > 8)
                    {
                        MessageBox.Show(res.GetString("String57"));
                        return;
                    }
                    iso15693ImOp.mode = hfReaderDll.HFREADER_ISO15693_IM_MODE_RBLOCK;
                }
                else
                {
                    iso15693ImOp.mode = hfReaderDll.HFREADER_ISO15693_IM_MODE_RUID;
                }

                imOpAnt = (Byte)comboBoxImOpAnt.SelectedIndex;
                if (comboBoxImOpAnt.Text.IndexOf("ANT") < 0)
                {
                    int i = 0;
                    Byte[] addr = new Byte[1];
                    string[] addrList = comboBoxImOpAntAddr.Text.Split('-');
                    iso15693ImOp.antNum = 0;
                    for (i = 0; i < addrList.Length; i++)
                    {
                        if (GetHexInput(addrList[i], addr, 1) <= 0)
                        {
                            return;
                        }
                        else
                        {
                            iso15693ImOp.antAddr[iso15693ImOp.antNum++] = addr[0];
                        }
                    }
                    if (iso15693ImOp.antNum < 2)
                    {
                        MessageBox.Show(res.GetString("String62"));
                        return;
                    }
                }
                else
                {
                    iso15693ImOp.antNum = 1;
                    iso15693ImOp.antAddr[0] = imOpAnt;
                }

                comboBoxImOpAnt.Enabled = false;
                comboBoxImOpMode.Enabled = false;
                textBoxImOpBlockAddr.Enabled = false;
                comboBoxImOpAntAddr.Enabled = false;

                imOpTagNum = 0;
                imOpTestNum = 0;
                imOpTestOkNum = 0;
                this.fatherForm.Enabled = false;
                this.textBoxImTagInfo.Text = "";
                imOpTagMode = (Byte)iso15693ImOp.mode;
                buttonImOpStart.Text = res.GetString("String58");
            }
            else
            {
                imOpTagMode = 0x00;

                buttonImOpStart.Text = res.GetString("String61");
                comboBoxImOpMode_SelectedIndexChanged(null, null);

                comboBoxImOpAnt.Enabled = true;
                comboBoxImOpMode.Enabled = true;
                this.fatherForm.Enabled = true;
                comboBoxImOpAnt_SelectedIndexChanged(null, null);
            }
        }

        private void comboBoxImOpMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxImOpMode.SelectedIndex == 0)
            {
                textBoxImOpBlockAddr.Enabled = false;
            }
            else
            {
                textBoxImOpBlockAddr.Enabled = true;
            }
        }

        private void buttonSetScanAnts_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];
            Byte ant = 0;

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (checkBoxGateAnt1.Checked)
            {
                ant |= 0x01;
            }
            if (checkBoxGateAnt2.Checked)
            {
                ant |= 0x02;
            }
            if (checkBoxGateAnt3.Checked)
            {
                ant |= 0x04;
            }
            if (checkBoxGateAnt4.Checked)
            {
                ant |= 0x08;
            }
            if (checkBoxGateAnt5.Checked)
            {
                ant |= 0x10;
            }
            if (checkBoxGateAnt6.Checked)
            {
                ant |= 0x20;
            }
            if (checkBoxGateAnt7.Checked)
            {
                ant |= 0x40;
            }
            if (checkBoxGateAnt8.Checked)
            {
                ant |= 0x80;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = 0;
            rlt = hfReaderDll.iso15693SetScanAnts(serialDevice, addrArray[0], addrArray[1], ant, ref pResult, sendBuffer, rcvBuffer);

            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String63"));
            DisplaySendInf(sendBuffer, res.GetString("String64"));
        }

        private void buttonSetGateMode_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];
            Byte mode = 0;

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            mode = (Byte)comboBoxEnableGateMode.SelectedIndex;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = 0;
            rlt = hfReaderDll.iso15693EnableGateMode(serialDevice, addrArray[0], addrArray[1], mode, ref pResult, sendBuffer, rcvBuffer);

            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String65"));
            DisplaySendInf(sendBuffer, res.GetString("String66"));
        }

        private void buttonStartRcvGateAlarmUid_Click(object sender, EventArgs e)
        {
            if (buttonStartRcvGateAlarmUid.Text == res.GetString("String67"))
            {
                this.fatherForm.Enabled = false;
                this.textBoxGateAlarmUid.Text = "";
                buttonStartRcvGateAlarmUid.Text = res.GetString("String38");
                gateAlarmMode = 1;
            }
            else
            {
                gateAlarmMode = 0x00;
                this.fatherForm.Enabled = true;
                buttonStartRcvGateAlarmUid.Text = res.GetString("String67");
            }
        }

        private void comboBoxImOpAnt_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxImOpAnt.Text.IndexOf("ANT") < 0)
            {
                comboBoxImOpAntAddr.Enabled = true;
            }
            else
            {
                comboBoxImOpAntAddr.Enabled = false;
            }
        }
    }
}