using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace RFIDStation
{
    public partial class updateSystem : Form
    {
        public int serialDevice = -1;
        private int hHFREADERDLLModule = 0;

        public delegate void Delegate(object obj);

        private Thread threadUpdate = null;
        private int fileSize = 0;
        private int scanDevNum = 0;
        private int flashSectorNum = 0;
        private int flashStartAddr = 0;
        private byte[] fileInfo = new byte[1024 * 1024];
        private int cpuType = 0;

        public const int DEV_SCAN_NUM = 128;
        public const int DEV_DL_SIZE = 512;
        public const int DEV_STM32F4_FLASH_ADDR_START = 0x08004000;
        public const int DEV_STM32F1_FLASH_ADDR_START = 0x08004000;
        public const int DEV_STM32F1_FLASH_SECTOR_SIZE = 0x400;
        public const int DEV_STM32F1_FLASH_SECTOR_MSK = 0x3FF;
        public const int DEV_STM32F4_FLASH_SECTOR_NUM = 11;
        public int[] DEV_STM32F4_FLASH_SECTOR_SIZE = { 16 * 1024, 16 * 1024, 16 * 1024, 64 * 1024, 128 * 1024, 128 * 1024, 128 * 1024, 128 * 1024, 128 * 1024, 128 * 1024, 128 * 1024 };
        public uint[] DEV_STM32F4_FLASH_SECTOR_ADDR = { 0x08, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38, 0x40, 0x48, 0x50, 0x58, 0x60 };

        public updateSystem()
        {
            InitializeComponent();

            /*
            hHFREADERDLLModule = 0;
            hHFREADERDLLModule = hfReaderDll.LoadLibrary("Boot.dll");

            if (hHFREADERDLLModule <= 0)
            {
                MessageBox.Show("װ��Boot.dll�ļ�ʧ�ܣ���ȷ��Boot.dll�ļ��Ƿ����");
                System.Environment.Exit(0);
            }
            */

            comboBoxCpuType.SelectedIndex = 1;
            this.progressBarUpdate.Step = 1;
            this.progressBarUpdate.Value = 0;

            fileSize = 0;
        }

        public void DisableUpdate()
        {
            this.buttonUpdate.Enabled = false;
            serialDevice = -1;
        }

        private void updateSystem_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (fileSize > 0)
            {
                MessageBox.Show("����δ��ɣ������ĵȴ�");
                e.Cancel = true;
            }
            else
            {
                Dispose();
                Close();
            }
        }

        private void UpdateInfo(object obj)
        {
            if (this.progressBarUpdate.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateInfo);
                this.progressBarUpdate.Invoke(d, obj);
            }
            else
            {
                int step = 0;   //0-scan, 1-erase, 2-down
                int state = 0;  //0-start, 1-ing, 2-end
                int value = 0;
                String s = obj.ToString();

                step = Convert.ToInt32(s.Substring(0, 1));
                state = Convert.ToInt32(s.Substring(1, 1));
                value = Convert.ToInt32(s.Substring(2, s.Length - 2));
                if (step == 0)
                {
                    if (state == 0)
                    {
                        this.progressBarUpdate.Value = 0;
                        this.progressBarUpdate.Maximum = value;
                        labelProgress.Text = "��Ѱ��";
                    }
                    else if (state == 1)
                    {
                        this.progressBarUpdate.Value = value;
                    }
                    else if (state == 2)
                    {
                        if (value > 0)
                        {
                            MessageBox.Show("��Ѱ�豸ʧ��");
                        }
                    }
                }
                //����
                if (step == 1)
                {
                    if (state == 0)
                    {
                        this.progressBarUpdate.Value = 0;
                        this.progressBarUpdate.Maximum = value;
                        labelProgress.Text = "������";
                    }
                    else if (state == 1)
                    {
                        this.progressBarUpdate.Value = value;
                    }
                    else if (state == 2)
                    {
                        if (value > 0)
                        {
                            MessageBox.Show("��������ʧ��");
                        }
                    }
                }
                //����
                if (step == 2)
                {
                    if (state == 0)
                    {
                        this.progressBarUpdate.Value = 0;
                        this.progressBarUpdate.Maximum = value;
                        labelProgress.Text = "���أ�";
                    }
                    else if (state == 1)
                    {
                        this.progressBarUpdate.Value = value;
                    }
                    else if (state == 2)
                    {
                        if (value > 0)
                        {
                            MessageBox.Show("����ʧ��");
                        }
                    }
                }

                if (step == 3)
                {
                    if (value == 0)
                    {
                        labelProgress.Text = "���ȣ�";
                        MessageBox.Show("���³ɹ����븴λϵͳ");
                    }
                    comboBoxCpuType.Enabled = true;
                    buttonUpdate.Enabled = true;
                }
            }
        }

        private void update()
        {
            if (true)
            {
                updateByNet();
                return;
            }
            int rlt = 0;
            int step = 0;   //0-scan, 1-erase, 2-down
            int state = 0;  //0-start, 1-ing, 2-end
            int value = 0;
            bool b = true;
            UpdateJumpButtonState(false);
            if (b)
            {
                //��ʼѰ���豸
                step = 0;
                state = 0;
                value = scanDevNum;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //��Ѱ
                state = 1;
                value = 0;
                while (scanDevNum > 0)
                {
                    // System.Diagnostics.Debugger.Log(0, null, "111111111\r\n");
                    rlt = hfReaderDll.Boot_Reset(serialDevice, 0, 0xFFFF);
                    //  System.Diagnostics.Debugger.Log(0, null, "11111xxxxxxx\r\n");
                    Thread.Sleep(200);
                    if (rlt > 0)
                    {
                        //     System.Diagnostics.Debugger.Log(0, null, "1111122222\r\n");
                        rlt = hfReaderDll.Boot_Start(serialDevice, 0, 0xFFFF);
                        //      System.Diagnostics.Debugger.Log(0, null, "22222222\r\n");
                        if (rlt > 0)
                        {
                            //     System.Diagnostics.Debugger.Log(0, null, "444444444\r\n");
                            break;
                        }
                    }

                    scanDevNum--;
                    value++;
                    //    System.Diagnostics.Debugger.Log(0, null, "3333333333\r\n");
                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                }
                //����
                state = 2;
                if (scanDevNum > 0)
                {
                    value = 0;
                }
                else
                {
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            if (b)
            {
                //��ʼ�����豸
                step = 1;
                state = 0;
                value = flashSectorNum;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //erase
                state = 1;
                value = 0;
                while (value < flashSectorNum)
                {
                    if (cpuType == 1)
                    {
                        rlt = hfReaderDll.Boot_Erase(serialDevice, 0, 0xFFFF, DEV_STM32F4_FLASH_SECTOR_ADDR[value]);
                    }
                    else
                    {
                        rlt = hfReaderDll.Boot_Erase(serialDevice, 0, 0xFFFF, (uint)value);
                    }
                    if (rlt <= 0)
                    {
                        break;
                    }
                    value++;
                    Thread.Sleep(100);
                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                }
                //����
                state = 2;
                if (value == flashSectorNum)
                {
                    value = 0;
                }
                else
                {
                    //����ʧ��
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            if (b)
            {
                int size = 0;
                Byte[] dl = new Byte[DEV_DL_SIZE];

                int[] programAddr = new int[fileSize / DEV_DL_SIZE + 1];
                int[] programSize = new int[fileSize / DEV_DL_SIZE + 1];
                int dlNum = 0, dlIndex = 0;

                //��ʼ����
                step = 2;
                state = 0;
                value = fileSize;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //dl
                state = 1;
                value = 0;

                while (value < fileSize)
                {
                    if (value + DEV_DL_SIZE < fileSize)
                    {
                        size = DEV_DL_SIZE;
                    }
                    else
                    {
                        size = fileSize - value;
                    }
                    programAddr[dlNum] = value;
                    programSize[dlNum] = size;
                    dlNum++;
                    value += size;
                }
                dlIndex = dlNum - 1;
                //���������һ������
                value = 0;
                while (dlIndex >= 0)
                {
                    Array.Copy(fileInfo, programAddr[dlIndex], dl, 0, programSize[dlIndex]);
                    rlt = hfReaderDll.Boot_Download(serialDevice, 0, 0xFFFF, 0x01, (uint)(flashStartAddr + programAddr[dlIndex]), (uint)programSize[dlIndex], dl);
                    if (rlt <= 0)
                    {
                        break;
                    }
                    else
                    {
                        value += programSize[dlIndex];
                        dlIndex--;
                    }

                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                    Thread.Sleep(100);
                }
                //����
                state = 2;
                if (dlIndex == -1)
                {
                    value = 0;
                    hfReaderDll.Boot_End2(serialDevice, 0, 0xFFFF);
                }
                else
                {
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            {
                //����
                step = 3;
                state = 0;
                if (b)
                {
                    value = 0;
                }
                else
                {
                    value = 1;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());

                fileSize = 0;
            }

            UpdateJumpButtonState(true);
        }

        private void updateByNet()
        {
            int rlt = 0;
            int step = 0;   //0-scan, 1-erase, 2-down
            int state = 0;  //0-start, 1-ing, 2-end
            int value = 0;
            bool b = true;
            UpdateJumpButtonState(false);
            if (b)
            {
                //��ʼѰ���豸
                step = 0;
                state = 0;
                value = scanDevNum;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //��Ѱ
                state = 1;
                value = 0;
                while (scanDevNum > 0)
                {
                    // System.Diagnostics.Debugger.Log(0, null, "111111111\r\n");
                    rlt = hfReaderDll.Boot_Reset(serialDevice, 0, 0xFFFF);
                    //  System.Diagnostics.Debugger.Log(0, null, "11111xxxxxxx\r\n");
                    Thread.Sleep(200);
                    if (rlt > 0)
                    {
                        //     System.Diagnostics.Debugger.Log(0, null, "1111122222\r\n");
                        rlt = hfReaderDll.Boot_Start(serialDevice, 0, 0xFFFF);
                        //      System.Diagnostics.Debugger.Log(0, null, "22222222\r\n");
                        if (rlt > 0)
                        {
                            //     System.Diagnostics.Debugger.Log(0, null, "444444444\r\n");
                            break;
                        }
                    }

                    scanDevNum--;
                    value++;
                    //    System.Diagnostics.Debugger.Log(0, null, "3333333333\r\n");
                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                }
                //����
                state = 2;
                if (scanDevNum > 0)
                {
                    value = 0;
                }
                else
                {
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            if (b)
            {
                //��ʼ�����豸
                step = 1;
                state = 0;
                value = flashSectorNum;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //erase
                state = 1;
                value = 0;
                while (value < flashSectorNum)
                {
                    if (cpuType == 1)
                    {
                        rlt = hfReaderDll.Boot_Erase(serialDevice, 0, 0xFFFF, DEV_STM32F4_FLASH_SECTOR_ADDR[value]);
                    }
                    else
                    {
                        rlt = hfReaderDll.Boot_Erase(serialDevice, 0, 0xFFFF, (uint)value);
                    }
                    if (rlt <= 0)
                    {
                        break;
                    }
                    value++;
                    Thread.Sleep(50);
                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                }
                //����
                state = 2;
                if (value == flashSectorNum)
                {
                    value = 0;
                }
                else
                {
                    //����ʧ��
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            if (b)
            {
                int size = 0;
                Byte[] dl = new Byte[DEV_DL_SIZE];

                int[] programAddr = new int[fileSize / DEV_DL_SIZE + 1];
                int[] programSize = new int[fileSize / DEV_DL_SIZE + 1];
                int dlNum = 0, dlIndex = 0;

                //��ʼ����
                step = 2;
                state = 0;
                value = fileSize;
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                //dl
                state = 1;
                value = 0;

                while (value < fileSize)
                {
                    if (value + DEV_DL_SIZE < fileSize)
                    {
                        size = DEV_DL_SIZE;
                    }
                    else
                    {
                        size = fileSize - value;
                    }
                    programAddr[dlNum] = value;
                    programSize[dlNum] = size;
                    dlNum++;
                    value += size;
                }
                dlIndex = dlNum - 1;
                //���������һ������
                value = 0;
                while (dlIndex >= 0)
                {
                    Array.Copy(fileInfo, programAddr[dlIndex], dl, 0, programSize[dlIndex]);
                    rlt = hfReaderDll.Boot_Download(serialDevice, 0, 0xFFFF, 0x01, (uint)(flashStartAddr + programAddr[dlIndex]), (uint)programSize[dlIndex], dl);
                    if (rlt <= 0)
                    {
                        break;
                    }
                    else
                    {
                        value += programSize[dlIndex];
                        dlIndex--;
                    }

                    UpdateInfo(step.ToString() + state.ToString() + value.ToString());
                    Thread.Sleep(100);
                }
                //����
                state = 2;
                if (dlIndex == -1)
                {
                    value = 0;
                    hfReaderDll.Boot_End2(serialDevice, 0, 0xFFFF);
                }
                else
                {
                    value = 1;
                    b = false;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());
            }

            {
                //����
                step = 3;
                state = 0;
                if (b)
                {
                    value = 0;
                }
                else
                {
                    value = 1;
                }
                UpdateInfo(step.ToString() + state.ToString() + value.ToString());

                fileSize = 0;
            }

            UpdateJumpButtonState(true);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (serialDevice == 0 || serialDevice == -1)
            {
                MessageBox.Show("��ȷ�ϴ����Ƿ���������");
                return;
            }
            textBoxFilePath.Text = "";

            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Title = "��";
            fileDialog.Filter = "BIN|*.bin|�����ļ�|*.*";
            fileDialog.RestoreDirectory = true;
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = fileDialog.FileName;

                FileStream stream = File.OpenRead(fileDialog.FileName);
                if (stream.Length > fileInfo.Length)
                {
                    MessageBox.Show("�ļ�����Flash���ȣ���ȷ���ļ��Ƿ���ȷ");
                    return;
                }
                else
                {
                    fileSize = stream.Read(fileInfo, 0, (int)stream.Length);
                    if (fileSize > 0)
                    {
                        if (MessageBox.Show("ȷ������ϵͳ��", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int i = 0;
                            textBoxFilePath.Text = fileName;

                            int size = 0;
                            //stm32f4
                            if (comboBoxCpuType.SelectedIndex == 1)
                            {
                                for (i = 0; i < DEV_STM32F4_FLASH_SECTOR_NUM; i++)
                                {
                                    size += DEV_STM32F4_FLASH_SECTOR_SIZE[i];
                                    if (size > fileSize)
                                    {
                                        break;
                                    }
                                }
                                flashStartAddr = DEV_STM32F4_FLASH_ADDR_START;
                                flashSectorNum = i + 1;
                            }
                            else
                            {
                                flashStartAddr = DEV_STM32F1_FLASH_ADDR_START;
                                flashSectorNum = fileSize / DEV_STM32F1_FLASH_SECTOR_SIZE;
                                size = fileSize & DEV_STM32F1_FLASH_SECTOR_MSK;
                                if (size > 0)
                                {
                                    flashSectorNum += 1;
                                }
                            }

                            scanDevNum = DEV_SCAN_NUM;

                            comboBoxCpuType.Enabled = false;
                            buttonUpdate.Enabled = false;
                            cpuType = comboBoxCpuType.SelectedIndex;

                            threadUpdate = new Thread(update);
                            threadUpdate.IsBackground = true;
                            threadUpdate.Start();
                        }
                        else
                        {
                            fileSize = 0;
                        }
                    }
                    else
                    {
                        stream.Close();
                    }
                }
            }
        }

        private void UpdateJumpButtonState(object obj)
        {
            if (this.buttonJump.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateJumpButtonState);
                this.buttonJump.Invoke(d, obj);
            }
            else
            {
                buttonJump.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void buttonJump_Click(object sender, EventArgs e)
        {
            int rlt = hfReaderDll.Boot_End2(serialDevice, 0, 0xFFFF);
            if (rlt > 0)
            {
                MessageBox.Show("��ת�ɹ�");
            }
            else
            {
                MessageBox.Show("��תʧ��");
            }
        }
    }
}