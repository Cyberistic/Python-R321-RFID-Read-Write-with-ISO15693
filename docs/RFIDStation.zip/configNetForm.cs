﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace RFIDStation
{
    public partial class configNetForm : Form
    {
        public delegate void Delegate(object obj);

        private int deviceNum = 0;
        private bool bScaning = false;
        private Thread scanThread;
        private Byte[,] deviceParams = new Byte[256, 255];
        private string[] deviceIpAddr = new string[256];
        private int selectedDeviceIndex = -1;

        public configNetForm()
        {
            InitializeComponent();
            comboBoxNetMode.SelectedIndex = 0;
            comboBoxBr.SelectedIndex = 0;
        }

        private bool TxScanCmd()
        {
            bool b = false;
            IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
            UdpClient localUdpClient = new UdpClient(localUdpPoint);
            IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);
            byte[] cmdScan = { 0xFF, 0x01, 0x01, 0x02 };
            try
            {
                int len = localUdpClient.Send(cmdScan, cmdScan.Length, deviceUdpPoint);
                if (len == cmdScan.Length)
                {
                    b = true;
                }
            }
            catch (Exception e)
            {
            }

            return b;
        }

        private byte[] RxScanResult(ref string remoteAddr)
        {
            byte[] recvData = null;
            remoteAddr = "";

            IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
            UdpClient localUdpClient = new UdpClient(localUdpPoint);
            IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);
            try
            {
                recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    remoteAddr = deviceUdpPoint.Address.ToString();
                }
            }
            catch (Exception e)
            {
            }

            return recvData;
        }

        private void UpdateSetParamsButtonText(object obj)
        {
            if (this.buttonSetParams.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateSetParamsButtonText);
                this.buttonSetParams.Invoke(d, obj);
            }
            else
            {
                this.buttonSetParams.Text = obj.ToString();
            }
        }

        private void UpdateScanButtonText(object obj)
        {
            if (this.buttonScan.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateScanButtonText);
                this.buttonScan.Invoke(d, obj);
            }
            else
            {
                this.buttonScan.Text = obj.ToString();
            }
        }

        private void UpdateConfigButtonState(object obj)
        {
            if (this.buttonSetParams.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateConfigButtonState);
                this.buttonSetParams.Invoke(d, obj);
            }
            else
            {
                this.buttonSetParams.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void UpdateDeviceBoxState(object obj)
        {
            if (this.groupBoxDevice.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateDeviceBoxState);
                this.groupBoxDevice.Invoke(d, obj);
            }
            else
            {
                this.groupBoxDevice.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void UpdateParamsBoxState(object obj)
        {
            if (this.groupBoxParams.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateParamsBoxState);
                this.groupBoxParams.Invoke(d, obj);
            }
            else
            {
                this.groupBoxParams.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void UpdateDeviceInfo(object obj)
        {
            if (this.listViewDevice.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateDeviceInfo);
                this.listViewDevice.Invoke(d, obj);
            }
            else
            {
                string[] sl = obj.ToString().Split(' ');
                ListViewItem lvi = new ListViewItem(sl[0]);
                lvi.SubItems.Add(sl[1]);
                listViewDevice.Items.Add(lvi);
            }
        }

        private void ScanDevice()
        {
            UpdateDeviceBoxState(false);
            UpdateParamsBoxState(false);
            UpdateConfigButtonState(false);

            UdpClient localUdpClient = null;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                byte[] cmdScan = { 0xFF, 0x01, 0x01, 0x02 };
                localUdpClient.Send(cmdScan, cmdScan.Length, deviceUdpPoint);
                while (bScaning)
                {
                    byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                    if (recvData != null)
                    {
                        deviceIpAddr[deviceNum] = deviceUdpPoint.Address.ToString();
                        for (int i = 0; i < recvData.Length; i++)
                        {
                            deviceParams[deviceNum, i] = recvData[i];
                        }
                        string sl0 = "", sl1 = "";
                        sl0 = deviceIpAddr[deviceNum];
                        sl1 += deviceParams[deviceNum, 9].ToString("X").PadLeft(2, '0') + ":";
                        sl1 += deviceParams[deviceNum, 10].ToString("X").PadLeft(2, '0') + ":";
                        sl1 += deviceParams[deviceNum, 11].ToString("X").PadLeft(2, '0') + ":";
                        sl1 += deviceParams[deviceNum, 12].ToString("X").PadLeft(2, '0') + ":";
                        sl1 += deviceParams[deviceNum, 13].ToString("X").PadLeft(2, '0') + ":";
                        sl1 += deviceParams[deviceNum, 14].ToString("X").PadLeft(2, '0');
                        deviceNum++;
                        UpdateDeviceInfo(sl0 + " " + sl1);
                    }
                }
                localUdpClient.Close();
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }
            }
            UpdateDeviceBoxState(true);
            UpdateParamsBoxState(true);
            UpdateConfigButtonState(true);
            UpdateScanButtonText("开始搜索");
            bScaning = false;
            if (scanThread != null)
            {
                scanThread.Abort();
            }
            scanThread = null;
        }

        //开始搜索
        private void buttonScan_Click(object sender, EventArgs e)
        {
            if (bScaning == false)
            {
                deviceNum = 0;
                listViewDevice.Items.Clear();

                UpdateScanButtonText("停止搜索");
                bScaning = true;
                scanThread = new Thread(new ThreadStart(ScanDevice));
                scanThread.IsBackground = true;
                scanThread.Start();
            }
            else
            {
                bScaning = false;
            }
        }

        private void ReadDeviceInfo(int index)
        {
            byte[] txCmd = { 0xFF, 0x13, 0x03, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x41 };
            byte chk = 0;
            int i = 0;

            selectedDeviceIndex = index;
            for (i = 0; i < 6; i++)
            {
                txCmd[3 + i] = deviceParams[index, 9 + i];
            }
            for (i = 0; i < 20; i++)
            {
                chk += txCmd[1 + i];
            }
            txCmd[21] = chk;

            UdpClient localUdpClient = null;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                localUdpClient.Send(txCmd, txCmd.Length, deviceUdpPoint);
                byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    textBoxLocalIp.Text = recvData[12].ToString() + "." + recvData[11].ToString() + "." + recvData[10].ToString() + "." + recvData[9].ToString();
                    textBoxGateway.Text = recvData[16].ToString() + "." + recvData[15].ToString() + "." + recvData[14].ToString() + "." + recvData[13].ToString();
                    textBoxSubNetMask.Text = recvData[20].ToString() + "." + recvData[19].ToString() + "." + recvData[18].ToString() + "." + recvData[17].ToString();

                    int br = recvData[67 + 0] + recvData[67 + 1] * 256 + recvData[67 + 2] * 256 * 256;
                    if (br == 9600)
                    {
                        comboBoxBr.SelectedIndex = 0;
                    }
                    else if (br == 115200)
                    {
                        comboBoxBr.SelectedIndex = 2;
                    }
                    else
                    {
                        comboBoxBr.SelectedIndex = 1;
                    }
                    textBoxLocalPort.Text = (recvData[67 + 12] + recvData[67 + 13] * 256).ToString();
                    textBoxRemotePort.Text = (recvData[67 + 14] + recvData[67 + 15] * 256).ToString();
                    //textBoxRemoteIp.Text = recvData[67 + 19].ToString() + "." + recvData[67 + 18].ToString() + "." + recvData[67 + 17].ToString() + "." + recvData[67 + 16].ToString();
                    int asicLen = 0;
                    for (i = 0; i < 256; i++)
                    {
                        if (recvData[67 + 16 + i] != 0)
                        {
                            asicLen++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    byte[] asicBuf = new byte[asicLen];
                    for (i = 0; i < asicLen; i++)
                    {
                        asicBuf[i] = recvData[67 + 16 + i];
                    }
                    System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
                    textBoxRemoteIp.Text = asciiEncoding.GetString(asicBuf);
                    comboBoxNetMode.SelectedIndex = recvData[67 + 51];
                }

                localUdpClient.Close();
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }
            }
        }

        private bool ResetDeviceNet(int index)
        {
            UdpClient localUdpClient = null;
            int i = 0;
            bool b = false;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                byte[] txCmd = { 0xFF, 0x13, 0x02, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x0, 0x40 };
                for (i = 0; i < 6; i++)
                {
                    txCmd[3 + i] = deviceParams[index, 9 + i];  //mac
                }
                byte chk = 0;
                for (i = 0; i < 20; i++)
                {
                    chk += txCmd[1 + i];
                }
                txCmd[21] = chk;
                localUdpClient.Send(txCmd, txCmd.Length, deviceUdpPoint);
                byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    if (recvData.Length == 4 && recvData[3] == (byte)'K')
                    {
                        b = true;
                    }
                }

                localUdpClient.Close();
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }
            }
            return b;
        }

        //listview
        private void listViewDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            int num = listViewDevice.SelectedItems.Count;
            if (num == 1)
            {
                ListViewItem lvi = listViewDevice.SelectedItems[0];
                if (lvi != null)
                {
                    int index = listViewDevice.Items.IndexOf(lvi);
                    if (index >= 0 && index < deviceNum)
                    {
                        ReadDeviceInfo(index);
                    }
                    else
                    {
                        MessageBox.Show("设备不存在列表中");
                    }
                }
            }
        }

        //comboBox
        private void comboBoxNetMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxNetMode.SelectedIndex == 0 || comboBoxNetMode.SelectedIndex == 1)
            {
                textBoxRemoteIp.Enabled = true;
                textBoxRemotePort.Enabled = true;
            }
            else
            {
                textBoxRemoteIp.Enabled = false;
                textBoxRemotePort.Enabled = false;
            }
        }

        private bool ConfigBaseParams(int index, byte[] ipAddr, byte[] gwAddr, byte[] subnetAddr)
        {
            bool b = false;
            int i = 0;
            UdpClient localUdpClient = null;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                byte[] txCmd = {0xFF, 0x56, 0x05, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA,
                                  0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x61, 0x64, 0x6D,
                                  0x69, 0x6E, 0x00, 0x95, 0x63, 0x03, 0x80, 0x00, 0x00,
                                  0x50, 0x00, 0x00, 0x07, 0x00, 0xA8, 0xC0, 0x01, 0x00,
                                  0xA8, 0xC0, 0x00, 0xFF, 0xFF, 0xFF, (Byte)'A', (Byte)'n', (Byte)'y',
                                  (Byte)'I', (Byte)'D', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                  0x00, 0x00, 0x00, 0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E,
                                  0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x00, 0x01,
                                  0x00, 0x80, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA, 0x00,
                                  0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x59};

                for (i = 0; i < 6; i++)
                {
                    txCmd[3 + i] = deviceParams[index, 9 + i];  //mac
                }
                for (i = 0; i < 4; i++)
                {
                    txCmd[3 + 6 + 12 + 9 + i] = ipAddr[i];
                }
                for (i = 0; i < 4; i++)
                {
                    txCmd[3 + 6 + 12 + 13 + i] = gwAddr[i];
                }
                for (i = 0; i < 4; i++)
                {
                    txCmd[3 + 6 + 12 + 17 + i] = subnetAddr[i];
                }

                for (i = 0; i < 6; i++)
                {
                    txCmd[3 + 6 + 12 + 53 + i] = deviceParams[index, 9 + i];  //mac
                }
                for (i = 0; i < 4; i++) //dns
                {
                    txCmd[3 + 6 + 12 + 59 + i] = gwAddr[i];
                }
                byte chk = 0;
                for (i = 0; i < 67 + 12 + 6 + 2; i++)
                {
                    chk += txCmd[1 + i];
                }
                txCmd[3 + 6 + 12 + 67] = chk;

                localUdpClient.Send(txCmd, txCmd.Length, deviceUdpPoint);

                byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    if (recvData.Length == 4 && recvData[3] == (byte)'K')
                    {
                        b = true;
                    }
                }
                localUdpClient.Close();
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }
            }

            return b;
        }

        private bool ConfigUartParams(int index, int br, int localPort, int remortPort, byte[] remortAddr, int mode)
        {
            bool b = false;
            int i = 0;
            UdpClient localUdpClient = null;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(IPAddress.Any, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                byte[] txCmd = {0xFF, 0x52, 0x06, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x00, 0xC2, 0x01, 0x00,
                                0x08, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x8C, 0x4E, 0x2A, 0x20, 0x31, 0x39, 0x32, 0x2E, 0x31, 0x36, 0x38, 0x2E, 0x31, 0x2E, 0x31, 0x33, 0x33,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x85, 0x01, 0xA8, 0xC0, 0x01, 0x03, 0x00, 0x04,
                                0x10, 0x0E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16};

                for (i = 0; i < 6; i++)
                {
                    txCmd[3 + i] = deviceParams[index, 9 + i];  //mac
                }
                txCmd[3 + 6 + 12 + 0] = (byte)((br >> 0) & 0xFF);
                txCmd[3 + 6 + 12 + 1] = (byte)((br >> 8) & 0xFF);
                txCmd[3 + 6 + 12 + 2] = (byte)((br >> 16) & 0xFF);
                txCmd[3 + 6 + 12 + 3] = (byte)((br >> 24) & 0xFF);

                txCmd[3 + 6 + 12 + 12 + 0] = (byte)((localPort >> 0) & 0xFF);
                txCmd[3 + 6 + 12 + 12 + 1] = (byte)((localPort >> 8) & 0xFF);

                txCmd[3 + 6 + 12 + 14 + 0] = (byte)((remortPort >> 0) & 0xFF);
                txCmd[3 + 6 + 12 + 14 + 1] = (byte)((remortPort >> 8) & 0xFF);

                byte[] remortAddrBuffer = new byte[30];
                string s = remortAddr[3].ToString() + "." + remortAddr[2].ToString() + "." + remortAddr[1].ToString() + "." + remortAddr[0].ToString();
                byte[] bytetest = System.Text.Encoding.Default.GetBytes(s);
                Array.Copy(bytetest, remortAddrBuffer, s.Length);
                Array.Copy(remortAddrBuffer, 0, txCmd, 3 + 6 + 12 + 16, 30);

                txCmd[3 + 6 + 12 + 51] = (byte)(mode);

                byte chk = 0;
                for (i = 0; i < 63 + 12 + 6 + 2; i++)
                {
                    chk += txCmd[1 + i];
                }
                txCmd[3 + 6 + 12 + 63] = chk;

                localUdpClient.Send(txCmd, txCmd.Length, deviceUdpPoint);

                byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    if (recvData.Length == 4 && recvData[3] == (byte)'K')
                    {
                        b = true;
                    }
                }
                localUdpClient.Close();
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }
            }

            return b;
        }

        public bool GetDecInput(String s, Byte[] buffer, int start, int len)
        {
            int i = 0;
            long l = 0;
            if (s.Length == 0 || len > 8)
            {
                MessageBox.Show("数据长度错误");
                return false;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9'))
                {
                    MessageBox.Show("请以10进制格式输入数据");
                    return false;
                }
            }
            l = Convert.ToInt64(s);
            if (l > (1 << (len * 8)))
            {
                MessageBox.Show("数据超长");
                return false;
            }
            for (i = 0; i < len; i++)
            {
                buffer[i + start] = (Byte)((l >> (i * 8)) & 0xFF);
            }

            return true;
        }

        public bool GetIpInput(String s, Byte[] buffer, int start)
        {
            int i = 0;
            string[] ipList = s.Split('.');
            if (s.Length == 4)
            {
                MessageBox.Show("长度错误");
                return false;
            }
            if (ipList.Length != 4)
            {
                MessageBox.Show("IP格式错误");
                return false;
            }
            for (i = 0; i < 4; i++)
            {
                if (GetDecInput(ipList[4 - i - 1], buffer, start + i, 1) == false)
                {
                    return false;
                }
            }

            return true;
        }

        //配置参数
        private void buttonSetParams_Click(object sender, EventArgs e)
        {
            if (selectedDeviceIndex < 0)
            {
                MessageBox.Show("请选择设备");
            }
            else
            {
                byte[] ipAddr = new byte[4];
                byte[] gwAddr = new byte[4];
                byte[] subnetAddr = new byte[4];
                byte[] remoteIpAddr = new byte[4];

                if (GetIpInput(textBoxLocalIp.Text, ipAddr, 0) && GetIpInput(textBoxGateway.Text, gwAddr, 0) && GetIpInput(textBoxSubNetMask.Text, subnetAddr, 0) && GetIpInput(textBoxRemoteIp.Text, remoteIpAddr, 0))
                {
                    if (ConfigBaseParams(selectedDeviceIndex, ipAddr, gwAddr, subnetAddr))
                    {
                        int remotePort = 0, localPort = 0, br = 38400;
                        remotePort = Convert.ToInt32(textBoxRemotePort.Text);
                        localPort = Convert.ToInt32(textBoxLocalPort.Text);
                        /*if(comboBoxBr.SelectedIndex == 0)
                        {
                            br = 9600;
                        }
                        else if(comboBoxBr.SelectedIndex == 2)
                        {
                            br = 115200;
                        }*/
                        comboBoxBr.SelectedIndex = 2;
                        br = 115200;
                        if (ConfigUartParams(selectedDeviceIndex, br, localPort, remotePort, remoteIpAddr, comboBoxNetMode.SelectedIndex))
                        {
                            if (ResetDeviceNet(selectedDeviceIndex))
                            {
                                MessageBox.Show("配置设备成功");
                            }
                            else
                            {
                                MessageBox.Show("复位设备错误");
                            }
                        }
                        else
                        {
                            MessageBox.Show("配置串口参数错误");
                        }
                    }
                    else
                    {
                        MessageBox.Show("配置基础参数错误");
                    }
                }
                else
                {
                    MessageBox.Show("IP地址输入错误");
                }
            }
        }

        //恢复默认
        private void buttonDefault_Click(object sender, EventArgs e)
        {
            comboBoxBr.SelectedIndex = 2;
            comboBoxNetMode.SelectedIndex = 3;
            textBoxRemotePort.Text = "10001";
            textBoxRemoteIp.Text = "192.168.1.1";
            textBoxLocalIp.Text = "192.168.1.7";
            textBoxLocalPort.Text = "10001";
            textBoxSubNetMask.Text = "255.255.255.0";
            buttonSetParams_Click(null, null);
        }

        private void configNetForm_Load(object sender, EventArgs e)
        {
        }
    }
}