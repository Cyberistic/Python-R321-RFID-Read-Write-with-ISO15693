using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RFIDStation
{
    public partial class felica : Form
    {
        public RFIDStation fatherForm;
        private int serialDevice;                   //�����豸
        public bool bOperatingSerial;
        public delegate void Delegate(object obj);

        public felica()
        {
            InitializeComponent();

            serialDevice = -1;
            bOperatingSerial = false;
        }

        public void EnableFelica(int h)
        {
            serialDevice = h;

            this.tabControlFelicaTagOp.Enabled = true;
            buttonReadFelicaTags.Enabled = true;
        }

        public void DisableFelica()
        {
            buttonReadFelicaTags.Enabled = false;
            this.tabControlFelicaTagOp.Enabled = false;
            serialDevice = -1;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxFelicaInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxFelicaInf.Invoke(d, obj);

            }
            else
            {
                this.textBoxFelicaInf.Text = obj.ToString();
            }
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxFelicaInf.Text = "<�����ɹ�>\r\n\r\n" + this.textBoxFelicaInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxFelicaInf.Text = "<����ʧ�ܣ�����������豸��֧�ָ�����>\r\n\r\n" + this.textBoxFelicaInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxFelicaInf.Text = "<����ʧ�ܣ���ǩ����Ӧ>\r\n\r\n" + this.textBoxFelicaInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxFelicaInf.Text = "<����ʧ�ܣ���ǩ��Ӧ֡У�����>\r\n\r\n" + this.textBoxFelicaInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxFelicaInf.Text = "<����ʧ�ܣ���ǩ����>\r\n\r\n" + this.textBoxFelicaInf.Text;
                }
                else
                {
                    this.textBoxFelicaInf.Text = "<����ʧ��>\r\n\r\n" + this.textBoxFelicaInf.Text;
                }
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxFelicaInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            String s = cmdNmae;

            {
                for (i = 0; i < len; i++)
                {
                    s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxFelicaInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;
            String s = cmdNmae;
            if (pRcvBuf[2] > 0)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n<ͨ��ʧ��>\r\n";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show("���ݳ��ȴ���");
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }


        private bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            b = fatherForm.GetDeviceAddr(addArray);
            return b;
        }

        private void buttonReadFelicaTags_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte mode = 0;

            FELICA_UIDPARAM pUid = new FELICA_UIDPARAM();
            pUid.uid = new Byte[hfReaderDll.HFREADER_FELICA_UID_LEN * hfReaderDll.HFREADER_FELICA_UID_MAX_NUM];
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            mode = hfReaderDll.HFREADER_READ_UID_NORMAL;
            textBoxSelectedFelicaUid.Text = "";


            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.felicaGetUID(serialDevice, addrArray[0], addrArray[1], mode, ref pUid, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pUid.result);

                if (pUid.num > 0)
                {
                    int i = 0, j = 0;
                    String s;
                    for (i = 0; i < pUid.num; i++)
                    {
                        s = "";
                        for (j = 0; j < hfReaderDll.HFREADER_FELICA_UID_LEN; j++)
                        {
                            s += pUid.uid[i * hfReaderDll.HFREADER_FELICA_UID_LEN + j].ToString("X").PadLeft(2, '0');
                        }
                        textBoxSelectedFelicaUid.Text = s;
                    }
                }

            }
            DisplayRcvInf(rcvBuffer, "��ѯ���ڱ�ǩ����<<");
            DisplaySendInf(sendBuffer, "��ѯ���ڱ�ǩ>>");
        }

        private void buttonClearFelicaInfo_Click(object sender, EventArgs e)
        {
            this.textBoxFelicaInf.Text = "";
        }

        private void buttonDtu_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }

            ushort[] addrArray = new ushort[2];
            Byte[] rxLen = new Byte[1];

            FELICA_DTU pDtu = new FELICA_DTU();
            pDtu.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pDtu.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxDtuRxLen.Text, rxLen, 1) <= 0)
            {
                return;
            }
            pDtu.rxLen = rxLen[0];

            pDtu.txLen = (uint)(GetHexInput(this.textBoxDtuTx.Text, pDtu.txFrame));

            pDtu.timeout = Convert.ToUInt32(this.textBoxDtuTime.Text, 10);

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.felicaDtu(serialDevice, addrArray[0], addrArray[1], ref pDtu, sendBuffer, rcvBuffer);
            bOperatingSerial = false;

            if (rlt > 0)
            {
                if (pDtu.result.flag == 0)
                {
                    string s = "";
                    for (uint i = 0; i < pDtu.rxLen; i++)
                    {
                        s += pDtu.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxDtuRx.Text = s;
                    this.textBoxDtuRxLen.Text = pDtu.rxLen.ToString("X").PadLeft(2, '0');
                }
                DisplayOpResult(pDtu.result);
            }
            DisplayRcvInf(rcvBuffer, "͸������<<");
            DisplaySendInf(sendBuffer, "͸��>>");
        }

        private void buttonDtuTxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuTx.Text = "";
        }

        private void buttonDtuRxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuRx.Text = "";
        }
    }
}