namespace RFIDStation
{
    partial class ISO14443A
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ISO14443A));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonClearInfo = new System.Windows.Forms.Button();
            this.textBoxInf = new System.Windows.Forms.TextBox();
            this.tabControlISO14443ATagOp = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBoxGetUid = new System.Windows.Forms.GroupBox();
            this.buttonHalt = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.radioButtonRequestTagIdle = new System.Windows.Forms.RadioButton();
            this.radioButtonRequestTagAll = new System.Windows.Forms.RadioButton();
            this.textBoxRemainTagNum = new System.Windows.Forms.TextBox();
            this.textBoxReadTagNum = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonClearListBox = new System.Windows.Forms.Button();
            this.buttonReadTags = new System.Windows.Forms.Button();
            this.listBoxUID = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBoxBlockAddr = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBoxAuth = new System.Windows.Forms.CheckBox();
            this.comboBoxBlockKeyType = new System.Windows.Forms.ComboBox();
            this.textBoxBlockKey = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonClearWriteInfo = new System.Windows.Forms.Button();
            this.textBoxWBlockNum = new System.Windows.Forms.TextBox();
            this.buttonWriteMBlock = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxWMBlockData = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonClearReadInfo = new System.Windows.Forms.Button();
            this.textBoxRBlockNum = new System.Windows.Forms.TextBox();
            this.buttonReadMBlock = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxRMBlockData = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBoxRestoreAddr = new System.Windows.Forms.TextBox();
            this.buttonRestoreValue = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxRestoreValue = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBoxTransAddr = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxOpValue = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.buttonDecValue = new System.Windows.Forms.Button();
            this.buttonIncValue = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxBackupAddr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonReadValue = new System.Windows.Forms.Button();
            this.buttonWriteValue = new System.Windows.Forms.Button();
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxValueAddr = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.comboBoxValueKeyType = new System.Windows.Forms.ComboBox();
            this.textBoxValueKey = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.textBoxWM0Num = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.buttonClearWriteM0 = new System.Windows.Forms.Button();
            this.textBoxWM0Addr = new System.Windows.Forms.TextBox();
            this.buttonWriteM0 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBoxWM0BlockData = new System.Windows.Forms.TextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBoxRM0Num = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.buttonClearReadM0 = new System.Windows.Forms.Button();
            this.textBoxRM0Addr = new System.Windows.Forms.TextBox();
            this.buttonReadM0 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxRM0BlockData = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.textBoxUltralightKey = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.buttonAuthUltralightC = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.comboBoxEsamSelBr = new System.Windows.Forms.ComboBox();
            this.buttonSelEsamBr = new System.Windows.Forms.Button();
            this.textBoxPps = new System.Windows.Forms.TextBox();
            this.buttonEsamPps = new System.Windows.Forms.Button();
            this.buttonCtrEsamClear = new System.Windows.Forms.Button();
            this.textBoxCtrlEsamRsp = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.comboBoxEsamState = new System.Windows.Forms.ComboBox();
            this.comboBoxEsamIndex = new System.Windows.Forms.ComboBox();
            this.buttonCtrlEsam = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.buttonRatsClear = new System.Windows.Forms.Button();
            this.textBoxRatsRsp = new System.Windows.Forms.TextBox();
            this.buttonRatsPsam = new System.Windows.Forms.Button();
            this.textBoxApduTxLen = new System.Windows.Forms.TextBox();
            this.textBoxApduRxLen = new System.Windows.Forms.TextBox();
            this.buttonApduRxClear = new System.Windows.Forms.Button();
            this.buttonApduTxClear = new System.Windows.Forms.Button();
            this.buttonDsel = new System.Windows.Forms.Button();
            this.textBoxApduRx = new System.Windows.Forms.TextBox();
            this.textBoxApduTx = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.comboBoxApduIndex = new System.Windows.Forms.ComboBox();
            this.buttonApdu = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.buttonDtuAddBcc = new System.Windows.Forms.Button();
            this.buttonDtuAddCrc = new System.Windows.Forms.Button();
            this.textBoxDtuRxBit = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBoxDtuTxBit = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBoxDtuRxLen = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxDtuTime = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.buttonDtuRxClear = new System.Windows.Forms.Button();
            this.buttonDtuTxClear = new System.Windows.Forms.Button();
            this.textBoxDtuRx = new System.Windows.Forms.TextBox();
            this.textBoxDtuTx = new System.Windows.Forms.TextBox();
            this.buttonDtu = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.checkBoxImNormalMode = new System.Windows.Forms.CheckBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.textBoxImBlock = new System.Windows.Forms.TextBox();
            this.textBoxImInfo = new System.Windows.Forms.TextBox();
            this.buttonImClearInfo = new System.Windows.Forms.Button();
            this.checkBoxImOpContinue = new System.Windows.Forms.CheckBox();
            this.textBoxImOpDelay = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.buttonImStart = new System.Windows.Forms.Button();
            this.numericUpDownAntNum = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.comboBoxOpMode = new System.Windows.Forms.ComboBox();
            this.textBoxOpTimeout = new System.Windows.Forms.TextBox();
            this.textBoxAntWorkTime = new System.Windows.Forms.TextBox();
            this.numericUpDownBlockNum = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownBlockAddr = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonErrTypeRsp = new System.Windows.Forms.RadioButton();
            this.radioButtonErrTypeTag = new System.Windows.Forms.RadioButton();
            this.radioButtonErrTypeOK = new System.Windows.Forms.RadioButton();
            this.radioButtonErrTypeCrc = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButtonOpTagRltOpFail = new System.Windows.Forms.RadioButton();
            this.radioButtonOpTagRltOpOK = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCfgRltReset = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxOpTagRltDestAddr = new System.Windows.Forms.TextBox();
            this.textBoxOpTagRltSrcAddr = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.checkBoxUidEnable = new System.Windows.Forms.CheckBox();
            this.textBoxSelectedISO14443AUID = new System.Windows.Forms.TextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.textBoxWriteM0Num = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.buttonClearM0WBlock = new System.Windows.Forms.Button();
            this.textBoxWriteM0Addr = new System.Windows.Forms.TextBox();
            this.buttonWriteM0Block = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBoxWriteM0Block = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.textBoxReadM0Num = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.buttonClearM0RBlock = new System.Windows.Forms.Button();
            this.textBoxReadM0Addr = new System.Windows.Forms.TextBox();
            this.buttonReadM0Block = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.textBoxReadM0Block = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.tabControlISO14443ATagOp.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBoxGetUid.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAntNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBlockNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBlockAddr)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.buttonClearInfo);
            this.groupBox2.Controls.Add(this.textBoxInf);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // buttonClearInfo
            // 
            resources.ApplyResources(this.buttonClearInfo, "buttonClearInfo");
            this.buttonClearInfo.Name = "buttonClearInfo";
            this.buttonClearInfo.UseVisualStyleBackColor = true;
            this.buttonClearInfo.Click += new System.EventHandler(this.buttonClearInfo_Click);
            // 
            // textBoxInf
            // 
            resources.ApplyResources(this.textBoxInf, "textBoxInf");
            this.textBoxInf.Name = "textBoxInf";
            // 
            // tabControlISO14443ATagOp
            // 
            resources.ApplyResources(this.tabControlISO14443ATagOp, "tabControlISO14443ATagOp");
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage1);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage2);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage3);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage4);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage6);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage7);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage8);
            this.tabControlISO14443ATagOp.Controls.Add(this.tabPage5);
            this.tabControlISO14443ATagOp.Name = "tabControlISO14443ATagOp";
            this.tabControlISO14443ATagOp.SelectedIndex = 0;
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Controls.Add(this.groupBoxGetUid);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBoxGetUid
            // 
            resources.ApplyResources(this.groupBoxGetUid, "groupBoxGetUid");
            this.groupBoxGetUid.Controls.Add(this.buttonHalt);
            this.groupBoxGetUid.Controls.Add(this.label15);
            this.groupBoxGetUid.Controls.Add(this.panel13);
            this.groupBoxGetUid.Controls.Add(this.textBoxRemainTagNum);
            this.groupBoxGetUid.Controls.Add(this.textBoxReadTagNum);
            this.groupBoxGetUid.Controls.Add(this.label14);
            this.groupBoxGetUid.Controls.Add(this.label13);
            this.groupBoxGetUid.Controls.Add(this.buttonClearListBox);
            this.groupBoxGetUid.Controls.Add(this.buttonReadTags);
            this.groupBoxGetUid.Controls.Add(this.listBoxUID);
            this.groupBoxGetUid.Name = "groupBoxGetUid";
            this.groupBoxGetUid.TabStop = false;
            // 
            // buttonHalt
            // 
            resources.ApplyResources(this.buttonHalt, "buttonHalt");
            this.buttonHalt.Name = "buttonHalt";
            this.buttonHalt.UseVisualStyleBackColor = true;
            this.buttonHalt.Click += new System.EventHandler(this.buttonHalt_Click);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // panel13
            // 
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.radioButtonRequestTagIdle);
            this.panel13.Controls.Add(this.radioButtonRequestTagAll);
            this.panel13.Name = "panel13";
            // 
            // panel14
            // 
            resources.ApplyResources(this.panel14, "panel14");
            this.panel14.Name = "panel14";
            // 
            // radioButtonRequestTagIdle
            // 
            resources.ApplyResources(this.radioButtonRequestTagIdle, "radioButtonRequestTagIdle");
            this.radioButtonRequestTagIdle.Checked = true;
            this.radioButtonRequestTagIdle.Name = "radioButtonRequestTagIdle";
            this.radioButtonRequestTagIdle.TabStop = true;
            this.radioButtonRequestTagIdle.UseVisualStyleBackColor = true;
            // 
            // radioButtonRequestTagAll
            // 
            resources.ApplyResources(this.radioButtonRequestTagAll, "radioButtonRequestTagAll");
            this.radioButtonRequestTagAll.Name = "radioButtonRequestTagAll";
            this.radioButtonRequestTagAll.UseVisualStyleBackColor = true;
            // 
            // textBoxRemainTagNum
            // 
            resources.ApplyResources(this.textBoxRemainTagNum, "textBoxRemainTagNum");
            this.textBoxRemainTagNum.Name = "textBoxRemainTagNum";
            // 
            // textBoxReadTagNum
            // 
            resources.ApplyResources(this.textBoxReadTagNum, "textBoxReadTagNum");
            this.textBoxReadTagNum.Name = "textBoxReadTagNum";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // buttonClearListBox
            // 
            resources.ApplyResources(this.buttonClearListBox, "buttonClearListBox");
            this.buttonClearListBox.Name = "buttonClearListBox";
            this.buttonClearListBox.UseVisualStyleBackColor = true;
            this.buttonClearListBox.Click += new System.EventHandler(this.buttonClearListBox_Click);
            // 
            // buttonReadTags
            // 
            resources.ApplyResources(this.buttonReadTags, "buttonReadTags");
            this.buttonReadTags.Name = "buttonReadTags";
            this.buttonReadTags.UseVisualStyleBackColor = true;
            this.buttonReadTags.Click += new System.EventHandler(this.buttonReadTags_Click);
            // 
            // listBoxUID
            // 
            resources.ApplyResources(this.listBoxUID, "listBoxUID");
            this.listBoxUID.FormattingEnabled = true;
            this.listBoxUID.Name = "listBoxUID";
            this.listBoxUID.SelectedIndexChanged += new System.EventHandler(this.listBoxUID_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Controls.Add(this.groupBox4);
            this.groupBox10.Controls.Add(this.groupBox1);
            this.groupBox10.Controls.Add(this.groupBox5);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // groupBox4
            // 
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Controls.Add(this.textBoxBlockAddr);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.checkBoxAuth);
            this.groupBox4.Controls.Add(this.comboBoxBlockKeyType);
            this.groupBox4.Controls.Add(this.textBoxBlockKey);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // textBoxBlockAddr
            // 
            resources.ApplyResources(this.textBoxBlockAddr, "textBoxBlockAddr");
            this.textBoxBlockAddr.Name = "textBoxBlockAddr";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // checkBoxAuth
            // 
            resources.ApplyResources(this.checkBoxAuth, "checkBoxAuth");
            this.checkBoxAuth.Checked = true;
            this.checkBoxAuth.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAuth.Name = "checkBoxAuth";
            this.checkBoxAuth.UseVisualStyleBackColor = true;
            this.checkBoxAuth.CheckedChanged += new System.EventHandler(this.checkBoxAuth_CheckedChanged);
            // 
            // comboBoxBlockKeyType
            // 
            resources.ApplyResources(this.comboBoxBlockKeyType, "comboBoxBlockKeyType");
            this.comboBoxBlockKeyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBlockKeyType.FormattingEnabled = true;
            this.comboBoxBlockKeyType.Items.AddRange(new object[] {
            resources.GetString("comboBoxBlockKeyType.Items"),
            resources.GetString("comboBoxBlockKeyType.Items1")});
            this.comboBoxBlockKeyType.Name = "comboBoxBlockKeyType";
            // 
            // textBoxBlockKey
            // 
            resources.ApplyResources(this.textBoxBlockKey, "textBoxBlockKey");
            this.textBoxBlockKey.Name = "textBoxBlockKey";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.buttonClearWriteInfo);
            this.groupBox1.Controls.Add(this.textBoxWBlockNum);
            this.groupBox1.Controls.Add(this.buttonWriteMBlock);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxWMBlockData);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // buttonClearWriteInfo
            // 
            resources.ApplyResources(this.buttonClearWriteInfo, "buttonClearWriteInfo");
            this.buttonClearWriteInfo.Name = "buttonClearWriteInfo";
            this.buttonClearWriteInfo.UseVisualStyleBackColor = true;
            this.buttonClearWriteInfo.Click += new System.EventHandler(this.buttonClearWriteInfo_Click);
            // 
            // textBoxWBlockNum
            // 
            resources.ApplyResources(this.textBoxWBlockNum, "textBoxWBlockNum");
            this.textBoxWBlockNum.Name = "textBoxWBlockNum";
            // 
            // buttonWriteMBlock
            // 
            resources.ApplyResources(this.buttonWriteMBlock, "buttonWriteMBlock");
            this.buttonWriteMBlock.Name = "buttonWriteMBlock";
            this.buttonWriteMBlock.UseVisualStyleBackColor = true;
            this.buttonWriteMBlock.Click += new System.EventHandler(this.buttonWriteMBlock_Click);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // textBoxWMBlockData
            // 
            resources.ApplyResources(this.textBoxWMBlockData, "textBoxWMBlockData");
            this.textBoxWMBlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWMBlockData.Name = "textBoxWMBlockData";
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.buttonClearReadInfo);
            this.groupBox5.Controls.Add(this.textBoxRBlockNum);
            this.groupBox5.Controls.Add(this.buttonReadMBlock);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.textBoxRMBlockData);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // buttonClearReadInfo
            // 
            resources.ApplyResources(this.buttonClearReadInfo, "buttonClearReadInfo");
            this.buttonClearReadInfo.Name = "buttonClearReadInfo";
            this.buttonClearReadInfo.UseVisualStyleBackColor = true;
            this.buttonClearReadInfo.Click += new System.EventHandler(this.buttonClearReadInfo_Click);
            // 
            // textBoxRBlockNum
            // 
            resources.ApplyResources(this.textBoxRBlockNum, "textBoxRBlockNum");
            this.textBoxRBlockNum.Name = "textBoxRBlockNum";
            // 
            // buttonReadMBlock
            // 
            resources.ApplyResources(this.buttonReadMBlock, "buttonReadMBlock");
            this.buttonReadMBlock.Name = "buttonReadMBlock";
            this.buttonReadMBlock.UseVisualStyleBackColor = true;
            this.buttonReadMBlock.Click += new System.EventHandler(this.buttonReadMBlock_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // textBoxRMBlockData
            // 
            resources.ApplyResources(this.textBoxRMBlockData, "textBoxRMBlockData");
            this.textBoxRMBlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxRMBlockData.Name = "textBoxRMBlockData";
            // 
            // tabPage3
            // 
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.groupBox12);
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // groupBox12
            // 
            resources.ApplyResources(this.groupBox12, "groupBox12");
            this.groupBox12.Controls.Add(this.textBoxRestoreAddr);
            this.groupBox12.Controls.Add(this.buttonRestoreValue);
            this.groupBox12.Controls.Add(this.label24);
            this.groupBox12.Controls.Add(this.textBoxRestoreValue);
            this.groupBox12.Controls.Add(this.label30);
            this.groupBox12.Controls.Add(this.label31);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.TabStop = false;
            // 
            // textBoxRestoreAddr
            // 
            resources.ApplyResources(this.textBoxRestoreAddr, "textBoxRestoreAddr");
            this.textBoxRestoreAddr.Name = "textBoxRestoreAddr";
            // 
            // buttonRestoreValue
            // 
            resources.ApplyResources(this.buttonRestoreValue, "buttonRestoreValue");
            this.buttonRestoreValue.Name = "buttonRestoreValue";
            this.buttonRestoreValue.UseVisualStyleBackColor = true;
            this.buttonRestoreValue.Click += new System.EventHandler(this.buttonRestoreValue_Click);
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label24.Name = "label24";
            // 
            // textBoxRestoreValue
            // 
            resources.ApplyResources(this.textBoxRestoreValue, "textBoxRestoreValue");
            this.textBoxRestoreValue.Name = "textBoxRestoreValue";
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // groupBox9
            // 
            resources.ApplyResources(this.groupBox9, "groupBox9");
            this.groupBox9.Controls.Add(this.textBoxTransAddr);
            this.groupBox9.Controls.Add(this.label23);
            this.groupBox9.Controls.Add(this.textBoxOpValue);
            this.groupBox9.Controls.Add(this.label25);
            this.groupBox9.Controls.Add(this.buttonDecValue);
            this.groupBox9.Controls.Add(this.buttonIncValue);
            this.groupBox9.Controls.Add(this.label26);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.TabStop = false;
            // 
            // textBoxTransAddr
            // 
            resources.ApplyResources(this.textBoxTransAddr, "textBoxTransAddr");
            this.textBoxTransAddr.Name = "textBoxTransAddr";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.Name = "label23";
            // 
            // textBoxOpValue
            // 
            resources.ApplyResources(this.textBoxOpValue, "textBoxOpValue");
            this.textBoxOpValue.Name = "textBoxOpValue";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // buttonDecValue
            // 
            resources.ApplyResources(this.buttonDecValue, "buttonDecValue");
            this.buttonDecValue.Name = "buttonDecValue";
            this.buttonDecValue.UseVisualStyleBackColor = true;
            this.buttonDecValue.Click += new System.EventHandler(this.buttonDecValue_Click);
            // 
            // buttonIncValue
            // 
            resources.ApplyResources(this.buttonIncValue, "buttonIncValue");
            this.buttonIncValue.Name = "buttonIncValue";
            this.buttonIncValue.UseVisualStyleBackColor = true;
            this.buttonIncValue.Click += new System.EventHandler(this.buttonIncValue_Click);
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // groupBox8
            // 
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Controls.Add(this.textBoxBackupAddr);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.buttonReadValue);
            this.groupBox8.Controls.Add(this.buttonWriteValue);
            this.groupBox8.Controls.Add(this.textBoxValue);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.label22);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // textBoxBackupAddr
            // 
            resources.ApplyResources(this.textBoxBackupAddr, "textBoxBackupAddr");
            this.textBoxBackupAddr.Name = "textBoxBackupAddr";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Name = "label11";
            // 
            // buttonReadValue
            // 
            resources.ApplyResources(this.buttonReadValue, "buttonReadValue");
            this.buttonReadValue.Name = "buttonReadValue";
            this.buttonReadValue.UseVisualStyleBackColor = true;
            this.buttonReadValue.Click += new System.EventHandler(this.buttonReadValue_Click);
            // 
            // buttonWriteValue
            // 
            resources.ApplyResources(this.buttonWriteValue, "buttonWriteValue");
            this.buttonWriteValue.Name = "buttonWriteValue";
            this.buttonWriteValue.UseVisualStyleBackColor = true;
            this.buttonWriteValue.Click += new System.EventHandler(this.buttonWriteValue_Click);
            // 
            // textBoxValue
            // 
            resources.ApplyResources(this.textBoxValue, "textBoxValue");
            this.textBoxValue.Name = "textBoxValue";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // groupBox7
            // 
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Controls.Add(this.textBoxValueAddr);
            this.groupBox7.Controls.Add(this.label4);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.checkBox1);
            this.groupBox7.Controls.Add(this.comboBoxValueKeyType);
            this.groupBox7.Controls.Add(this.textBoxValueKey);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // textBoxValueAddr
            // 
            resources.ApplyResources(this.textBoxValueAddr, "textBoxValueAddr");
            this.textBoxValueAddr.Name = "textBoxValueAddr";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // comboBoxValueKeyType
            // 
            resources.ApplyResources(this.comboBoxValueKeyType, "comboBoxValueKeyType");
            this.comboBoxValueKeyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxValueKeyType.FormattingEnabled = true;
            this.comboBoxValueKeyType.Items.AddRange(new object[] {
            resources.GetString("comboBoxValueKeyType.Items"),
            resources.GetString("comboBoxValueKeyType.Items1")});
            this.comboBoxValueKeyType.Name = "comboBoxValueKeyType";
            // 
            // textBoxValueKey
            // 
            resources.ApplyResources(this.textBoxValueKey, "textBoxValueKey");
            this.textBoxValueKey.Name = "textBoxValueKey";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // tabPage4
            // 
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Controls.Add(this.groupBox14);
            this.tabPage4.Controls.Add(this.groupBox15);
            this.tabPage4.Controls.Add(this.groupBox16);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            resources.ApplyResources(this.groupBox14, "groupBox14");
            this.groupBox14.Controls.Add(this.textBoxWM0Num);
            this.groupBox14.Controls.Add(this.label36);
            this.groupBox14.Controls.Add(this.buttonClearWriteM0);
            this.groupBox14.Controls.Add(this.textBoxWM0Addr);
            this.groupBox14.Controls.Add(this.buttonWriteM0);
            this.groupBox14.Controls.Add(this.label37);
            this.groupBox14.Controls.Add(this.label38);
            this.groupBox14.Controls.Add(this.textBoxWM0BlockData);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.TabStop = false;
            // 
            // textBoxWM0Num
            // 
            this.textBoxWM0Num.AcceptsReturn = true;
            resources.ApplyResources(this.textBoxWM0Num, "textBoxWM0Num");
            this.textBoxWM0Num.Name = "textBoxWM0Num";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            // 
            // buttonClearWriteM0
            // 
            resources.ApplyResources(this.buttonClearWriteM0, "buttonClearWriteM0");
            this.buttonClearWriteM0.Name = "buttonClearWriteM0";
            this.buttonClearWriteM0.UseVisualStyleBackColor = true;
            this.buttonClearWriteM0.Click += new System.EventHandler(this.buttonClearWriteM0_Click);
            // 
            // textBoxWM0Addr
            // 
            this.textBoxWM0Addr.AcceptsReturn = true;
            resources.ApplyResources(this.textBoxWM0Addr, "textBoxWM0Addr");
            this.textBoxWM0Addr.Name = "textBoxWM0Addr";
            // 
            // buttonWriteM0
            // 
            resources.ApplyResources(this.buttonWriteM0, "buttonWriteM0");
            this.buttonWriteM0.Name = "buttonWriteM0";
            this.buttonWriteM0.UseVisualStyleBackColor = true;
            this.buttonWriteM0.Click += new System.EventHandler(this.buttonWriteM0_Click);
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.Name = "label38";
            // 
            // textBoxWM0BlockData
            // 
            this.textBoxWM0BlockData.AcceptsTab = true;
            resources.ApplyResources(this.textBoxWM0BlockData, "textBoxWM0BlockData");
            this.textBoxWM0BlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWM0BlockData.Name = "textBoxWM0BlockData";
            // 
            // groupBox15
            // 
            resources.ApplyResources(this.groupBox15, "groupBox15");
            this.groupBox15.Controls.Add(this.textBoxRM0Num);
            this.groupBox15.Controls.Add(this.label39);
            this.groupBox15.Controls.Add(this.buttonClearReadM0);
            this.groupBox15.Controls.Add(this.textBoxRM0Addr);
            this.groupBox15.Controls.Add(this.buttonReadM0);
            this.groupBox15.Controls.Add(this.label40);
            this.groupBox15.Controls.Add(this.label41);
            this.groupBox15.Controls.Add(this.textBoxRM0BlockData);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.TabStop = false;
            // 
            // textBoxRM0Num
            // 
            resources.ApplyResources(this.textBoxRM0Num, "textBoxRM0Num");
            this.textBoxRM0Num.Name = "textBoxRM0Num";
            // 
            // label39
            // 
            resources.ApplyResources(this.label39, "label39");
            this.label39.Name = "label39";
            // 
            // buttonClearReadM0
            // 
            resources.ApplyResources(this.buttonClearReadM0, "buttonClearReadM0");
            this.buttonClearReadM0.Name = "buttonClearReadM0";
            this.buttonClearReadM0.UseVisualStyleBackColor = true;
            this.buttonClearReadM0.Click += new System.EventHandler(this.buttonClearReadM0_Click);
            // 
            // textBoxRM0Addr
            // 
            resources.ApplyResources(this.textBoxRM0Addr, "textBoxRM0Addr");
            this.textBoxRM0Addr.Name = "textBoxRM0Addr";
            // 
            // buttonReadM0
            // 
            resources.ApplyResources(this.buttonReadM0, "buttonReadM0");
            this.buttonReadM0.Name = "buttonReadM0";
            this.buttonReadM0.UseVisualStyleBackColor = true;
            this.buttonReadM0.Click += new System.EventHandler(this.buttonReadM0_Click);
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.Name = "label40";
            // 
            // label41
            // 
            resources.ApplyResources(this.label41, "label41");
            this.label41.Name = "label41";
            // 
            // textBoxRM0BlockData
            // 
            this.textBoxRM0BlockData.AcceptsTab = true;
            resources.ApplyResources(this.textBoxRM0BlockData, "textBoxRM0BlockData");
            this.textBoxRM0BlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxRM0BlockData.Name = "textBoxRM0BlockData";
            // 
            // groupBox16
            // 
            resources.ApplyResources(this.groupBox16, "groupBox16");
            this.groupBox16.Controls.Add(this.textBoxUltralightKey);
            this.groupBox16.Controls.Add(this.label51);
            this.groupBox16.Controls.Add(this.buttonAuthUltralightC);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.TabStop = false;
            // 
            // textBoxUltralightKey
            // 
            resources.ApplyResources(this.textBoxUltralightKey, "textBoxUltralightKey");
            this.textBoxUltralightKey.Name = "textBoxUltralightKey";
            // 
            // label51
            // 
            resources.ApplyResources(this.label51, "label51");
            this.label51.Name = "label51";
            // 
            // buttonAuthUltralightC
            // 
            resources.ApplyResources(this.buttonAuthUltralightC, "buttonAuthUltralightC");
            this.buttonAuthUltralightC.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.buttonAuthUltralightC.Name = "buttonAuthUltralightC";
            this.buttonAuthUltralightC.UseVisualStyleBackColor = true;
            this.buttonAuthUltralightC.Click += new System.EventHandler(this.buttonAuthUltralightC_Click);
            // 
            // tabPage6
            // 
            resources.ApplyResources(this.tabPage6, "tabPage6");
            this.tabPage6.Controls.Add(this.groupBox24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            resources.ApplyResources(this.groupBox24, "groupBox24");
            this.groupBox24.Controls.Add(this.comboBoxEsamSelBr);
            this.groupBox24.Controls.Add(this.buttonSelEsamBr);
            this.groupBox24.Controls.Add(this.textBoxPps);
            this.groupBox24.Controls.Add(this.buttonEsamPps);
            this.groupBox24.Controls.Add(this.buttonCtrEsamClear);
            this.groupBox24.Controls.Add(this.textBoxCtrlEsamRsp);
            this.groupBox24.Controls.Add(this.label53);
            this.groupBox24.Controls.Add(this.label54);
            this.groupBox24.Controls.Add(this.comboBoxEsamState);
            this.groupBox24.Controls.Add(this.comboBoxEsamIndex);
            this.groupBox24.Controls.Add(this.buttonCtrlEsam);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.TabStop = false;
            // 
            // comboBoxEsamSelBr
            // 
            resources.ApplyResources(this.comboBoxEsamSelBr, "comboBoxEsamSelBr");
            this.comboBoxEsamSelBr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEsamSelBr.FormattingEnabled = true;
            this.comboBoxEsamSelBr.Items.AddRange(new object[] {
            resources.GetString("comboBoxEsamSelBr.Items"),
            resources.GetString("comboBoxEsamSelBr.Items1")});
            this.comboBoxEsamSelBr.Name = "comboBoxEsamSelBr";
            // 
            // buttonSelEsamBr
            // 
            resources.ApplyResources(this.buttonSelEsamBr, "buttonSelEsamBr");
            this.buttonSelEsamBr.Name = "buttonSelEsamBr";
            this.buttonSelEsamBr.UseVisualStyleBackColor = true;
            this.buttonSelEsamBr.Click += new System.EventHandler(this.buttonSelEsamBr_Click);
            // 
            // textBoxPps
            // 
            resources.ApplyResources(this.textBoxPps, "textBoxPps");
            this.textBoxPps.Name = "textBoxPps";
            // 
            // buttonEsamPps
            // 
            resources.ApplyResources(this.buttonEsamPps, "buttonEsamPps");
            this.buttonEsamPps.Name = "buttonEsamPps";
            this.buttonEsamPps.UseVisualStyleBackColor = true;
            this.buttonEsamPps.Click += new System.EventHandler(this.buttonEsamPps_Click);
            // 
            // buttonCtrEsamClear
            // 
            resources.ApplyResources(this.buttonCtrEsamClear, "buttonCtrEsamClear");
            this.buttonCtrEsamClear.Name = "buttonCtrEsamClear";
            this.buttonCtrEsamClear.UseVisualStyleBackColor = true;
            this.buttonCtrEsamClear.Click += new System.EventHandler(this.buttonCtrEsamClear_Click);
            // 
            // textBoxCtrlEsamRsp
            // 
            resources.ApplyResources(this.textBoxCtrlEsamRsp, "textBoxCtrlEsamRsp");
            this.textBoxCtrlEsamRsp.Name = "textBoxCtrlEsamRsp";
            // 
            // label53
            // 
            resources.ApplyResources(this.label53, "label53");
            this.label53.Name = "label53";
            // 
            // label54
            // 
            resources.ApplyResources(this.label54, "label54");
            this.label54.Name = "label54";
            // 
            // comboBoxEsamState
            // 
            resources.ApplyResources(this.comboBoxEsamState, "comboBoxEsamState");
            this.comboBoxEsamState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEsamState.FormattingEnabled = true;
            this.comboBoxEsamState.Items.AddRange(new object[] {
            resources.GetString("comboBoxEsamState.Items"),
            resources.GetString("comboBoxEsamState.Items1"),
            resources.GetString("comboBoxEsamState.Items2")});
            this.comboBoxEsamState.Name = "comboBoxEsamState";
            // 
            // comboBoxEsamIndex
            // 
            resources.ApplyResources(this.comboBoxEsamIndex, "comboBoxEsamIndex");
            this.comboBoxEsamIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEsamIndex.FormattingEnabled = true;
            this.comboBoxEsamIndex.Items.AddRange(new object[] {
            resources.GetString("comboBoxEsamIndex.Items"),
            resources.GetString("comboBoxEsamIndex.Items1")});
            this.comboBoxEsamIndex.Name = "comboBoxEsamIndex";
            // 
            // buttonCtrlEsam
            // 
            resources.ApplyResources(this.buttonCtrlEsam, "buttonCtrlEsam");
            this.buttonCtrlEsam.Name = "buttonCtrlEsam";
            this.buttonCtrlEsam.UseVisualStyleBackColor = true;
            this.buttonCtrlEsam.Click += new System.EventHandler(this.buttonCtrlEsam_Click);
            // 
            // tabPage7
            // 
            resources.ApplyResources(this.tabPage7, "tabPage7");
            this.tabPage7.Controls.Add(this.buttonRatsClear);
            this.tabPage7.Controls.Add(this.textBoxRatsRsp);
            this.tabPage7.Controls.Add(this.buttonRatsPsam);
            this.tabPage7.Controls.Add(this.textBoxApduTxLen);
            this.tabPage7.Controls.Add(this.textBoxApduRxLen);
            this.tabPage7.Controls.Add(this.buttonApduRxClear);
            this.tabPage7.Controls.Add(this.buttonApduTxClear);
            this.tabPage7.Controls.Add(this.buttonDsel);
            this.tabPage7.Controls.Add(this.textBoxApduRx);
            this.tabPage7.Controls.Add(this.textBoxApduTx);
            this.tabPage7.Controls.Add(this.label55);
            this.tabPage7.Controls.Add(this.comboBoxApduIndex);
            this.tabPage7.Controls.Add(this.buttonApdu);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // buttonRatsClear
            // 
            resources.ApplyResources(this.buttonRatsClear, "buttonRatsClear");
            this.buttonRatsClear.Name = "buttonRatsClear";
            this.buttonRatsClear.UseVisualStyleBackColor = true;
            this.buttonRatsClear.Click += new System.EventHandler(this.buttonRatsClear_Click);
            // 
            // textBoxRatsRsp
            // 
            resources.ApplyResources(this.textBoxRatsRsp, "textBoxRatsRsp");
            this.textBoxRatsRsp.Name = "textBoxRatsRsp";
            // 
            // buttonRatsPsam
            // 
            resources.ApplyResources(this.buttonRatsPsam, "buttonRatsPsam");
            this.buttonRatsPsam.Name = "buttonRatsPsam";
            this.buttonRatsPsam.UseVisualStyleBackColor = true;
            this.buttonRatsPsam.Click += new System.EventHandler(this.buttonRatsPsam_Click);
            // 
            // textBoxApduTxLen
            // 
            resources.ApplyResources(this.textBoxApduTxLen, "textBoxApduTxLen");
            this.textBoxApduTxLen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxApduTxLen.Name = "textBoxApduTxLen";
            // 
            // textBoxApduRxLen
            // 
            resources.ApplyResources(this.textBoxApduRxLen, "textBoxApduRxLen");
            this.textBoxApduRxLen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxApduRxLen.Name = "textBoxApduRxLen";
            // 
            // buttonApduRxClear
            // 
            resources.ApplyResources(this.buttonApduRxClear, "buttonApduRxClear");
            this.buttonApduRxClear.Name = "buttonApduRxClear";
            this.buttonApduRxClear.UseVisualStyleBackColor = true;
            this.buttonApduRxClear.Click += new System.EventHandler(this.buttonApduRxClear_Click);
            // 
            // buttonApduTxClear
            // 
            resources.ApplyResources(this.buttonApduTxClear, "buttonApduTxClear");
            this.buttonApduTxClear.Name = "buttonApduTxClear";
            this.buttonApduTxClear.UseVisualStyleBackColor = true;
            this.buttonApduTxClear.Click += new System.EventHandler(this.buttonApduTxClear_Click);
            // 
            // buttonDsel
            // 
            resources.ApplyResources(this.buttonDsel, "buttonDsel");
            this.buttonDsel.Name = "buttonDsel";
            this.buttonDsel.UseVisualStyleBackColor = true;
            this.buttonDsel.Click += new System.EventHandler(this.buttonDsel_Click);
            // 
            // textBoxApduRx
            // 
            resources.ApplyResources(this.textBoxApduRx, "textBoxApduRx");
            this.textBoxApduRx.Name = "textBoxApduRx";
            // 
            // textBoxApduTx
            // 
            resources.ApplyResources(this.textBoxApduTx, "textBoxApduTx");
            this.textBoxApduTx.Name = "textBoxApduTx";
            // 
            // label55
            // 
            resources.ApplyResources(this.label55, "label55");
            this.label55.Name = "label55";
            // 
            // comboBoxApduIndex
            // 
            resources.ApplyResources(this.comboBoxApduIndex, "comboBoxApduIndex");
            this.comboBoxApduIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxApduIndex.FormattingEnabled = true;
            this.comboBoxApduIndex.Items.AddRange(new object[] {
            resources.GetString("comboBoxApduIndex.Items"),
            resources.GetString("comboBoxApduIndex.Items1"),
            resources.GetString("comboBoxApduIndex.Items2")});
            this.comboBoxApduIndex.Name = "comboBoxApduIndex";
            // 
            // buttonApdu
            // 
            resources.ApplyResources(this.buttonApdu, "buttonApdu");
            this.buttonApdu.Name = "buttonApdu";
            this.buttonApdu.UseVisualStyleBackColor = true;
            this.buttonApdu.Click += new System.EventHandler(this.buttonApdu_Click);
            // 
            // tabPage8
            // 
            resources.ApplyResources(this.tabPage8, "tabPage8");
            this.tabPage8.Controls.Add(this.buttonDtuAddBcc);
            this.tabPage8.Controls.Add(this.buttonDtuAddCrc);
            this.tabPage8.Controls.Add(this.textBoxDtuRxBit);
            this.tabPage8.Controls.Add(this.label62);
            this.tabPage8.Controls.Add(this.textBoxDtuTxBit);
            this.tabPage8.Controls.Add(this.label61);
            this.tabPage8.Controls.Add(this.textBoxDtuRxLen);
            this.tabPage8.Controls.Add(this.label56);
            this.tabPage8.Controls.Add(this.label57);
            this.tabPage8.Controls.Add(this.textBoxDtuTime);
            this.tabPage8.Controls.Add(this.label58);
            this.tabPage8.Controls.Add(this.label59);
            this.tabPage8.Controls.Add(this.label60);
            this.tabPage8.Controls.Add(this.buttonDtuRxClear);
            this.tabPage8.Controls.Add(this.buttonDtuTxClear);
            this.tabPage8.Controls.Add(this.textBoxDtuRx);
            this.tabPage8.Controls.Add(this.textBoxDtuTx);
            this.tabPage8.Controls.Add(this.buttonDtu);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // buttonDtuAddBcc
            // 
            resources.ApplyResources(this.buttonDtuAddBcc, "buttonDtuAddBcc");
            this.buttonDtuAddBcc.Name = "buttonDtuAddBcc";
            this.buttonDtuAddBcc.UseVisualStyleBackColor = true;
            this.buttonDtuAddBcc.Click += new System.EventHandler(this.buttonDtuAddSum_Click);
            // 
            // buttonDtuAddCrc
            // 
            resources.ApplyResources(this.buttonDtuAddCrc, "buttonDtuAddCrc");
            this.buttonDtuAddCrc.Name = "buttonDtuAddCrc";
            this.buttonDtuAddCrc.UseVisualStyleBackColor = true;
            this.buttonDtuAddCrc.Click += new System.EventHandler(this.buttonDtuAddCrc_Click);
            // 
            // textBoxDtuRxBit
            // 
            resources.ApplyResources(this.textBoxDtuRxBit, "textBoxDtuRxBit");
            this.textBoxDtuRxBit.Name = "textBoxDtuRxBit";
            // 
            // label62
            // 
            resources.ApplyResources(this.label62, "label62");
            this.label62.Name = "label62";
            // 
            // textBoxDtuTxBit
            // 
            resources.ApplyResources(this.textBoxDtuTxBit, "textBoxDtuTxBit");
            this.textBoxDtuTxBit.Name = "textBoxDtuTxBit";
            // 
            // label61
            // 
            resources.ApplyResources(this.label61, "label61");
            this.label61.Name = "label61";
            // 
            // textBoxDtuRxLen
            // 
            resources.ApplyResources(this.textBoxDtuRxLen, "textBoxDtuRxLen");
            this.textBoxDtuRxLen.Name = "textBoxDtuRxLen";
            // 
            // label56
            // 
            resources.ApplyResources(this.label56, "label56");
            this.label56.Name = "label56";
            // 
            // label57
            // 
            resources.ApplyResources(this.label57, "label57");
            this.label57.Name = "label57";
            // 
            // textBoxDtuTime
            // 
            resources.ApplyResources(this.textBoxDtuTime, "textBoxDtuTime");
            this.textBoxDtuTime.Name = "textBoxDtuTime";
            // 
            // label58
            // 
            resources.ApplyResources(this.label58, "label58");
            this.label58.Name = "label58";
            // 
            // label59
            // 
            resources.ApplyResources(this.label59, "label59");
            this.label59.Name = "label59";
            // 
            // label60
            // 
            resources.ApplyResources(this.label60, "label60");
            this.label60.Name = "label60";
            // 
            // buttonDtuRxClear
            // 
            resources.ApplyResources(this.buttonDtuRxClear, "buttonDtuRxClear");
            this.buttonDtuRxClear.Name = "buttonDtuRxClear";
            this.buttonDtuRxClear.UseVisualStyleBackColor = true;
            this.buttonDtuRxClear.Click += new System.EventHandler(this.buttonDtuRxClear_Click);
            // 
            // buttonDtuTxClear
            // 
            resources.ApplyResources(this.buttonDtuTxClear, "buttonDtuTxClear");
            this.buttonDtuTxClear.Name = "buttonDtuTxClear";
            this.buttonDtuTxClear.UseVisualStyleBackColor = true;
            this.buttonDtuTxClear.Click += new System.EventHandler(this.buttonDtuTxClear_Click);
            // 
            // textBoxDtuRx
            // 
            resources.ApplyResources(this.textBoxDtuRx, "textBoxDtuRx");
            this.textBoxDtuRx.Name = "textBoxDtuRx";
            // 
            // textBoxDtuTx
            // 
            resources.ApplyResources(this.textBoxDtuTx, "textBoxDtuTx");
            this.textBoxDtuTx.Name = "textBoxDtuTx";
            // 
            // buttonDtu
            // 
            resources.ApplyResources(this.buttonDtu, "buttonDtu");
            this.buttonDtu.Name = "buttonDtu";
            this.buttonDtu.UseVisualStyleBackColor = true;
            this.buttonDtu.Click += new System.EventHandler(this.buttonDtu_Click);
            // 
            // tabPage5
            // 
            resources.ApplyResources(this.tabPage5, "tabPage5");
            this.tabPage5.Controls.Add(this.checkBoxImNormalMode);
            this.tabPage5.Controls.Add(this.label76);
            this.tabPage5.Controls.Add(this.label75);
            this.tabPage5.Controls.Add(this.textBoxImBlock);
            this.tabPage5.Controls.Add(this.textBoxImInfo);
            this.tabPage5.Controls.Add(this.buttonImClearInfo);
            this.tabPage5.Controls.Add(this.checkBoxImOpContinue);
            this.tabPage5.Controls.Add(this.textBoxImOpDelay);
            this.tabPage5.Controls.Add(this.label74);
            this.tabPage5.Controls.Add(this.buttonImStart);
            this.tabPage5.Controls.Add(this.numericUpDownAntNum);
            this.tabPage5.Controls.Add(this.label73);
            this.tabPage5.Controls.Add(this.comboBoxOpMode);
            this.tabPage5.Controls.Add(this.textBoxOpTimeout);
            this.tabPage5.Controls.Add(this.textBoxAntWorkTime);
            this.tabPage5.Controls.Add(this.numericUpDownBlockNum);
            this.tabPage5.Controls.Add(this.numericUpDownBlockAddr);
            this.tabPage5.Controls.Add(this.label52);
            this.tabPage5.Controls.Add(this.label63);
            this.tabPage5.Controls.Add(this.label70);
            this.tabPage5.Controls.Add(this.label71);
            this.tabPage5.Controls.Add(this.label72);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // checkBoxImNormalMode
            // 
            resources.ApplyResources(this.checkBoxImNormalMode, "checkBoxImNormalMode");
            this.checkBoxImNormalMode.Name = "checkBoxImNormalMode";
            this.checkBoxImNormalMode.UseVisualStyleBackColor = true;
            // 
            // label76
            // 
            resources.ApplyResources(this.label76, "label76");
            this.label76.Name = "label76";
            // 
            // label75
            // 
            resources.ApplyResources(this.label75, "label75");
            this.label75.Name = "label75";
            // 
            // textBoxImBlock
            // 
            resources.ApplyResources(this.textBoxImBlock, "textBoxImBlock");
            this.textBoxImBlock.Name = "textBoxImBlock";
            // 
            // textBoxImInfo
            // 
            resources.ApplyResources(this.textBoxImInfo, "textBoxImInfo");
            this.textBoxImInfo.Name = "textBoxImInfo";
            // 
            // buttonImClearInfo
            // 
            resources.ApplyResources(this.buttonImClearInfo, "buttonImClearInfo");
            this.buttonImClearInfo.Name = "buttonImClearInfo";
            this.buttonImClearInfo.UseVisualStyleBackColor = true;
            this.buttonImClearInfo.Click += new System.EventHandler(this.buttonImClearInfo_Click);
            // 
            // checkBoxImOpContinue
            // 
            resources.ApplyResources(this.checkBoxImOpContinue, "checkBoxImOpContinue");
            this.checkBoxImOpContinue.Name = "checkBoxImOpContinue";
            this.checkBoxImOpContinue.UseVisualStyleBackColor = true;
            // 
            // textBoxImOpDelay
            // 
            resources.ApplyResources(this.textBoxImOpDelay, "textBoxImOpDelay");
            this.textBoxImOpDelay.Name = "textBoxImOpDelay";
            // 
            // label74
            // 
            resources.ApplyResources(this.label74, "label74");
            this.label74.Name = "label74";
            // 
            // buttonImStart
            // 
            resources.ApplyResources(this.buttonImStart, "buttonImStart");
            this.buttonImStart.Name = "buttonImStart";
            this.buttonImStart.UseVisualStyleBackColor = true;
            this.buttonImStart.Click += new System.EventHandler(this.buttonImStart_Click);
            // 
            // numericUpDownAntNum
            // 
            resources.ApplyResources(this.numericUpDownAntNum, "numericUpDownAntNum");
            this.numericUpDownAntNum.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDownAntNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAntNum.Name = "numericUpDownAntNum";
            this.numericUpDownAntNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label73
            // 
            resources.ApplyResources(this.label73, "label73");
            this.label73.Name = "label73";
            // 
            // comboBoxOpMode
            // 
            resources.ApplyResources(this.comboBoxOpMode, "comboBoxOpMode");
            this.comboBoxOpMode.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.comboBoxOpMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOpMode.FormattingEnabled = true;
            this.comboBoxOpMode.Items.AddRange(new object[] {
            resources.GetString("comboBoxOpMode.Items"),
            resources.GetString("comboBoxOpMode.Items1"),
            resources.GetString("comboBoxOpMode.Items2")});
            this.comboBoxOpMode.Name = "comboBoxOpMode";
            // 
            // textBoxOpTimeout
            // 
            resources.ApplyResources(this.textBoxOpTimeout, "textBoxOpTimeout");
            this.textBoxOpTimeout.Name = "textBoxOpTimeout";
            // 
            // textBoxAntWorkTime
            // 
            resources.ApplyResources(this.textBoxAntWorkTime, "textBoxAntWorkTime");
            this.textBoxAntWorkTime.Name = "textBoxAntWorkTime";
            // 
            // numericUpDownBlockNum
            // 
            resources.ApplyResources(this.numericUpDownBlockNum, "numericUpDownBlockNum");
            this.numericUpDownBlockNum.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownBlockNum.Name = "numericUpDownBlockNum";
            // 
            // numericUpDownBlockAddr
            // 
            resources.ApplyResources(this.numericUpDownBlockAddr, "numericUpDownBlockAddr");
            this.numericUpDownBlockAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownBlockAddr.Name = "numericUpDownBlockAddr";
            // 
            // label52
            // 
            resources.ApplyResources(this.label52, "label52");
            this.label52.Name = "label52";
            // 
            // label63
            // 
            resources.ApplyResources(this.label63, "label63");
            this.label63.Name = "label63";
            // 
            // label70
            // 
            resources.ApplyResources(this.label70, "label70");
            this.label70.Name = "label70";
            // 
            // label71
            // 
            resources.ApplyResources(this.label71, "label71");
            this.label71.Name = "label71";
            // 
            // label72
            // 
            resources.ApplyResources(this.label72, "label72");
            this.label72.Name = "label72";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.radioButtonErrTypeRsp);
            this.panel2.Controls.Add(this.radioButtonErrTypeTag);
            this.panel2.Controls.Add(this.radioButtonErrTypeOK);
            this.panel2.Controls.Add(this.radioButtonErrTypeCrc);
            this.panel2.Name = "panel2";
            // 
            // radioButtonErrTypeRsp
            // 
            resources.ApplyResources(this.radioButtonErrTypeRsp, "radioButtonErrTypeRsp");
            this.radioButtonErrTypeRsp.Name = "radioButtonErrTypeRsp";
            this.radioButtonErrTypeRsp.UseVisualStyleBackColor = true;
            // 
            // radioButtonErrTypeTag
            // 
            resources.ApplyResources(this.radioButtonErrTypeTag, "radioButtonErrTypeTag");
            this.radioButtonErrTypeTag.Name = "radioButtonErrTypeTag";
            this.radioButtonErrTypeTag.UseVisualStyleBackColor = true;
            // 
            // radioButtonErrTypeOK
            // 
            resources.ApplyResources(this.radioButtonErrTypeOK, "radioButtonErrTypeOK");
            this.radioButtonErrTypeOK.Name = "radioButtonErrTypeOK";
            this.radioButtonErrTypeOK.UseVisualStyleBackColor = true;
            // 
            // radioButtonErrTypeCrc
            // 
            resources.ApplyResources(this.radioButtonErrTypeCrc, "radioButtonErrTypeCrc");
            this.radioButtonErrTypeCrc.Name = "radioButtonErrTypeCrc";
            this.radioButtonErrTypeCrc.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.radioButtonOpTagRltOpFail);
            this.panel1.Controls.Add(this.radioButtonOpTagRltOpOK);
            this.panel1.Name = "panel1";
            // 
            // radioButtonOpTagRltOpFail
            // 
            resources.ApplyResources(this.radioButtonOpTagRltOpFail, "radioButtonOpTagRltOpFail");
            this.radioButtonOpTagRltOpFail.Name = "radioButtonOpTagRltOpFail";
            this.radioButtonOpTagRltOpFail.UseVisualStyleBackColor = true;
            // 
            // radioButtonOpTagRltOpOK
            // 
            resources.ApplyResources(this.radioButtonOpTagRltOpOK, "radioButtonOpTagRltOpOK");
            this.radioButtonOpTagRltOpOK.Name = "radioButtonOpTagRltOpOK";
            this.radioButtonOpTagRltOpOK.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // buttonCfgRltReset
            // 
            resources.ApplyResources(this.buttonCfgRltReset, "buttonCfgRltReset");
            this.buttonCfgRltReset.Name = "buttonCfgRltReset";
            this.buttonCfgRltReset.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // textBoxOpTagRltDestAddr
            // 
            resources.ApplyResources(this.textBoxOpTagRltDestAddr, "textBoxOpTagRltDestAddr");
            this.textBoxOpTagRltDestAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxOpTagRltDestAddr.Name = "textBoxOpTagRltDestAddr";
            // 
            // textBoxOpTagRltSrcAddr
            // 
            this.textBoxOpTagRltSrcAddr.AcceptsTab = true;
            resources.ApplyResources(this.textBoxOpTagRltSrcAddr, "textBoxOpTagRltSrcAddr");
            this.textBoxOpTagRltSrcAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxOpTagRltSrcAddr.Name = "textBoxOpTagRltSrcAddr";
            // 
            // groupBox13
            // 
            resources.ApplyResources(this.groupBox13, "groupBox13");
            this.groupBox13.Controls.Add(this.checkBoxUidEnable);
            this.groupBox13.Controls.Add(this.textBoxSelectedISO14443AUID);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.TabStop = false;
            // 
            // checkBoxUidEnable
            // 
            resources.ApplyResources(this.checkBoxUidEnable, "checkBoxUidEnable");
            this.checkBoxUidEnable.Name = "checkBoxUidEnable";
            this.checkBoxUidEnable.UseVisualStyleBackColor = true;
            this.checkBoxUidEnable.CheckedChanged += new System.EventHandler(this.checkBoxUidEnable_CheckedChanged);
            // 
            // textBoxSelectedISO14443AUID
            // 
            resources.ApplyResources(this.textBoxSelectedISO14443AUID, "textBoxSelectedISO14443AUID");
            this.textBoxSelectedISO14443AUID.Name = "textBoxSelectedISO14443AUID";
            // 
            // groupBox20
            // 
            resources.ApplyResources(this.groupBox20, "groupBox20");
            this.groupBox20.Controls.Add(this.textBoxWriteM0Num);
            this.groupBox20.Controls.Add(this.label44);
            this.groupBox20.Controls.Add(this.buttonClearM0WBlock);
            this.groupBox20.Controls.Add(this.textBoxWriteM0Addr);
            this.groupBox20.Controls.Add(this.buttonWriteM0Block);
            this.groupBox20.Controls.Add(this.label46);
            this.groupBox20.Controls.Add(this.label47);
            this.groupBox20.Controls.Add(this.textBoxWriteM0Block);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.TabStop = false;
            // 
            // textBoxWriteM0Num
            // 
            this.textBoxWriteM0Num.AcceptsReturn = true;
            resources.ApplyResources(this.textBoxWriteM0Num, "textBoxWriteM0Num");
            this.textBoxWriteM0Num.Name = "textBoxWriteM0Num";
            // 
            // label44
            // 
            resources.ApplyResources(this.label44, "label44");
            this.label44.Name = "label44";
            // 
            // buttonClearM0WBlock
            // 
            resources.ApplyResources(this.buttonClearM0WBlock, "buttonClearM0WBlock");
            this.buttonClearM0WBlock.Name = "buttonClearM0WBlock";
            this.buttonClearM0WBlock.UseVisualStyleBackColor = true;
            // 
            // textBoxWriteM0Addr
            // 
            this.textBoxWriteM0Addr.AcceptsReturn = true;
            resources.ApplyResources(this.textBoxWriteM0Addr, "textBoxWriteM0Addr");
            this.textBoxWriteM0Addr.Name = "textBoxWriteM0Addr";
            // 
            // buttonWriteM0Block
            // 
            resources.ApplyResources(this.buttonWriteM0Block, "buttonWriteM0Block");
            this.buttonWriteM0Block.Name = "buttonWriteM0Block";
            this.buttonWriteM0Block.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            resources.ApplyResources(this.label46, "label46");
            this.label46.Name = "label46";
            // 
            // label47
            // 
            resources.ApplyResources(this.label47, "label47");
            this.label47.Name = "label47";
            // 
            // textBoxWriteM0Block
            // 
            this.textBoxWriteM0Block.AcceptsTab = true;
            resources.ApplyResources(this.textBoxWriteM0Block, "textBoxWriteM0Block");
            this.textBoxWriteM0Block.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWriteM0Block.Name = "textBoxWriteM0Block";
            // 
            // groupBox21
            // 
            resources.ApplyResources(this.groupBox21, "groupBox21");
            this.groupBox21.Controls.Add(this.textBoxReadM0Num);
            this.groupBox21.Controls.Add(this.label43);
            this.groupBox21.Controls.Add(this.buttonClearM0RBlock);
            this.groupBox21.Controls.Add(this.textBoxReadM0Addr);
            this.groupBox21.Controls.Add(this.buttonReadM0Block);
            this.groupBox21.Controls.Add(this.label48);
            this.groupBox21.Controls.Add(this.label49);
            this.groupBox21.Controls.Add(this.textBoxReadM0Block);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.TabStop = false;
            // 
            // textBoxReadM0Num
            // 
            resources.ApplyResources(this.textBoxReadM0Num, "textBoxReadM0Num");
            this.textBoxReadM0Num.Name = "textBoxReadM0Num";
            // 
            // label43
            // 
            resources.ApplyResources(this.label43, "label43");
            this.label43.Name = "label43";
            // 
            // buttonClearM0RBlock
            // 
            resources.ApplyResources(this.buttonClearM0RBlock, "buttonClearM0RBlock");
            this.buttonClearM0RBlock.Name = "buttonClearM0RBlock";
            this.buttonClearM0RBlock.UseVisualStyleBackColor = true;
            // 
            // textBoxReadM0Addr
            // 
            resources.ApplyResources(this.textBoxReadM0Addr, "textBoxReadM0Addr");
            this.textBoxReadM0Addr.Name = "textBoxReadM0Addr";
            // 
            // buttonReadM0Block
            // 
            resources.ApplyResources(this.buttonReadM0Block, "buttonReadM0Block");
            this.buttonReadM0Block.Name = "buttonReadM0Block";
            this.buttonReadM0Block.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            resources.ApplyResources(this.label48, "label48");
            this.label48.Name = "label48";
            // 
            // label49
            // 
            resources.ApplyResources(this.label49, "label49");
            this.label49.Name = "label49";
            // 
            // textBoxReadM0Block
            // 
            resources.ApplyResources(this.textBoxReadM0Block, "textBoxReadM0Block");
            this.textBoxReadM0Block.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxReadM0Block.Name = "textBoxReadM0Block";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // label42
            // 
            resources.ApplyResources(this.label42, "label42");
            this.label42.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label42.Name = "label42";
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            // 
            // label45
            // 
            resources.ApplyResources(this.label45, "label45");
            this.label45.Name = "label45";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            resources.ApplyResources(this.label50, "label50");
            this.label50.Name = "label50";
            // 
            // ISO14443A
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.tabControlISO14443ATagOp);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ISO14443A";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ISO14443A_FormClosing);
            this.Load += new System.EventHandler(this.ISO14443A_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControlISO14443ATagOp.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBoxGetUid.ResumeLayout(false);
            this.groupBoxGetUid.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAntNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBlockNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBlockAddr)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxInf;
        private System.Windows.Forms.TabControl tabControlISO14443ATagOp;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBoxGetUid;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.RadioButton radioButtonRequestTagIdle;
        private System.Windows.Forms.RadioButton radioButtonRequestTagAll;
        private System.Windows.Forms.TextBox textBoxRemainTagNum;
        private System.Windows.Forms.TextBox textBoxReadTagNum;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonClearListBox;
        private System.Windows.Forms.Button buttonReadTags;
        private System.Windows.Forms.ListBox listBoxUID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonWriteMBlock;
        private System.Windows.Forms.Button buttonReadMBlock;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxRMBlockData;
        private System.Windows.Forms.CheckBox checkBoxAuth;
        private System.Windows.Forms.TextBox textBoxBlockKey;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBoxBlockKeyType;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxWMBlockData;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBoxValueKeyType;
        private System.Windows.Forms.TextBox textBoxValueKey;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buttonWriteValue;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxOpValue;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button buttonDecValue;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonReadValue;
        private System.Windows.Forms.TextBox textBoxValue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxRestoreValue;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button buttonIncValue;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button buttonRestoreValue;
        private System.Windows.Forms.TextBox textBoxBlockAddr;
        private System.Windows.Forms.TextBox textBoxWBlockNum;
        private System.Windows.Forms.TextBox textBoxRBlockNum;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButtonErrTypeRsp;
        private System.Windows.Forms.RadioButton radioButtonErrTypeTag;
        private System.Windows.Forms.RadioButton radioButtonErrTypeOK;
        private System.Windows.Forms.RadioButton radioButtonErrTypeCrc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButtonOpTagRltOpFail;
        private System.Windows.Forms.RadioButton radioButtonOpTagRltOpOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCfgRltReset;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxOpTagRltDestAddr;
        private System.Windows.Forms.TextBox textBoxOpTagRltSrcAddr;
        private System.Windows.Forms.TextBox textBoxValueAddr;
        private System.Windows.Forms.TextBox textBoxBackupAddr;
        private System.Windows.Forms.TextBox textBoxRestoreAddr;
        private System.Windows.Forms.TextBox textBoxTransAddr;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBoxSelectedISO14443AUID;
        private System.Windows.Forms.Button buttonClearReadInfo;
        private System.Windows.Forms.Button buttonClearWriteInfo;
        private System.Windows.Forms.Button buttonClearInfo;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox textBoxWriteM0Num;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button buttonClearM0WBlock;
        private System.Windows.Forms.TextBox textBoxWriteM0Addr;
        private System.Windows.Forms.Button buttonWriteM0Block;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBoxWriteM0Block;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox textBoxReadM0Num;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button buttonClearM0RBlock;
        private System.Windows.Forms.TextBox textBoxReadM0Addr;
        private System.Windows.Forms.Button buttonReadM0Block;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBoxReadM0Block;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.CheckBox checkBoxUidEnable;
        private System.Windows.Forms.Button buttonHalt;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button buttonCtrEsamClear;
        private System.Windows.Forms.TextBox textBoxCtrlEsamRsp;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox comboBoxEsamState;
        private System.Windows.Forms.ComboBox comboBoxEsamIndex;
        private System.Windows.Forms.Button buttonCtrlEsam;
        private System.Windows.Forms.Button buttonApduRxClear;
        private System.Windows.Forms.Button buttonApduTxClear;
        private System.Windows.Forms.Button buttonDsel;
        private System.Windows.Forms.TextBox textBoxApduRx;
        private System.Windows.Forms.TextBox textBoxApduTx;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox comboBoxApduIndex;
        private System.Windows.Forms.Button buttonApdu;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox textBoxDtuRxLen;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxDtuTime;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Button buttonDtuRxClear;
        private System.Windows.Forms.Button buttonDtuTxClear;
        private System.Windows.Forms.TextBox textBoxDtuRx;
        private System.Windows.Forms.TextBox textBoxDtuTx;
        private System.Windows.Forms.Button buttonDtu;
        private System.Windows.Forms.TextBox textBoxDtuTxBit;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBoxDtuRxBit;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button buttonDtuAddBcc;
        private System.Windows.Forms.Button buttonDtuAddCrc;
        private System.Windows.Forms.TextBox textBoxApduTxLen;
        private System.Windows.Forms.TextBox textBoxApduRxLen;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBoxUltralightKey;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox textBoxWM0Num;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button buttonClearWriteM0;
        private System.Windows.Forms.TextBox textBoxWM0Addr;
        private System.Windows.Forms.Button buttonWriteM0;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBoxWM0BlockData;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox textBoxRM0Num;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button buttonClearReadM0;
        private System.Windows.Forms.TextBox textBoxRM0Addr;
        private System.Windows.Forms.Button buttonReadM0;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxRM0BlockData;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button buttonAuthUltralightC;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.NumericUpDown numericUpDownAntNum;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox comboBoxOpMode;
        private System.Windows.Forms.TextBox textBoxOpTimeout;
        private System.Windows.Forms.TextBox textBoxAntWorkTime;
        private System.Windows.Forms.NumericUpDown numericUpDownBlockNum;
        private System.Windows.Forms.NumericUpDown numericUpDownBlockAddr;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button buttonRatsClear;
        private System.Windows.Forms.TextBox textBoxRatsRsp;
        private System.Windows.Forms.Button buttonRatsPsam;
        private System.Windows.Forms.Button buttonImStart;
        private System.Windows.Forms.TextBox textBoxImOpDelay;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.CheckBox checkBoxImOpContinue;
        private System.Windows.Forms.Button buttonImClearInfo;
        private System.Windows.Forms.TextBox textBoxImInfo;
        private System.Windows.Forms.TextBox textBoxImBlock;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button buttonEsamPps;
        private System.Windows.Forms.TextBox textBoxPps;
        private System.Windows.Forms.Button buttonSelEsamBr;
        private System.Windows.Forms.ComboBox comboBoxEsamSelBr;
        private System.Windows.Forms.CheckBox checkBoxImNormalMode;
        private System.Windows.Forms.Label label26;
    }
}