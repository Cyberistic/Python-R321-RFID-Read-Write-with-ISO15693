using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Resources;

namespace RFIDStation
{
    public partial class ISO14443A : Form
    {
        ResourceManager res = new ResourceManager(typeof(ISO14443A));
        public RFIDStation fatherForm;
        private int serialDevice;                   //�����豸
        public static Thread receiveFrameThread = null;
        public bool bOperatingSerial;

        public delegate void Delegate(object obj);

        public int imOpTagMode = 0;
        public int imOpTagTimes = 0;
        public int imOpTagOkTimes = 0;
        public int imOpComErrTimes = 0;
        public int imOpCmpErrTimes = 0;
        public string imOpUidCompare = "";

        public ISO14443A_IMPARAM imParams;

        FileStream testInfoStream = null;
        StreamWriter testInfoWriter = null;

        public ISO14443A()
        {
            InitializeComponent();
            this.comboBoxEsamSelBr.SelectedIndex = 0;
            this.comboBoxBlockKeyType.SelectedIndex = 0;
            this.comboBoxValueKeyType.SelectedIndex = 0;
            serialDevice = -1;
            bOperatingSerial = false;
            comboBoxOpMode.SelectedIndex = 0;

            imParams = new ISO14443A_IMPARAM();
            imParams.block = new byte[1024];
            imParams.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxInf.Text = res.GetString("Opsuccess") + "\r\n\r\n" + this.textBoxInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxInf.Text = res.GetString("Operror1") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxInf.Text = res.GetString("Operror2") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxInf.Text = res.GetString("Operror3") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxInf.Text = res.GetString("Operror4") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else
                {
                    this.textBoxInf.Text = res.GetString("Operror5") + "\r\n\r\n" + this.textBoxInf.Text;
                }
            }
        }

        public void EnableIso14443a(int h)
        {
            serialDevice = h;

            receiveFrameThread = new Thread(new ThreadStart(ReceiveFrame));
            receiveFrameThread.IsBackground = true;
            receiveFrameThread.Start();

            this.tabControlISO14443ATagOp.Enabled = true;
        }

        public void DisableIso14443a()
        {
            if (receiveFrameThread != null)
            {
                receiveFrameThread.Abort();
            }

            this.tabControlISO14443ATagOp.Enabled = false;
            serialDevice = -1;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxInf.Invoke(d, obj);
            }
            else
            {
                this.textBoxInf.Text = obj.ToString();
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            String s = cmdNmae;

            {
                for (i = 0; i < len; i++)
                {
                    s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;

            String s = cmdNmae;
            if (pRcvBuf[2] > 0)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n<ͨ��ʧ��>\r\n";
            }
            s += "\r\n";

            AddDisplayInfo(s + text);
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show(res.GetString("LengthError"));
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("HexError"));
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("LengthError"));
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        private bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            b = fatherForm.GetDeviceAddr(addArray);
            return b;
        }

        private bool GetUid(ref ISO14443A_UID uid)
        {
            Byte[] buffer = new Byte[255];

            String s = this.textBoxSelectedISO14443AUID.Text;
            String[] list = new String[255];
            list = s.Split(' ');

            if (GetHexInput(list[0], buffer, 2) <= 0)
            {
                return false;
            }
            else
            {
                uid.type = (ushort)(buffer[0] * 256 + buffer[1]);
            }

            if (GetHexInput(list[1], buffer, 1) <= 0)
            {
                return false;
            }
            else
            {
                uid.len = buffer[0];
                if (uid.len > 10)
                {
                    return false;
                }
            }

            if (GetHexInput(list[2], buffer, (int)(uid.len)) <= 0)
            {
                return false;
            }
            else
            {
                int i = 0;
                for (i = 0; i < uid.len; i++)
                {
                    uid.uid[i] = buffer[i];
                }
            }

            return true;
        }

        private void buttonReadTags_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte mode = 0;

            ISO14443A_UIDPARAM pUid = new ISO14443A_UIDPARAM();
            pUid.uid = new ISO14443A_UID[hfReaderDll.HFREADER_ISO14443A_UID_MAX_NUM];
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            if (this.checkBoxUidEnable.Checked)
            {
                if (this.radioButtonRequestTagIdle.Checked)
                {
                    mode = hfReaderDll.HFREADER_READ_UID_NORMAL;
                }
                else
                {
                    mode = hfReaderDll.HFREADER_READ_UID_REPEAT;
                }
            }
            else
            {
                if (this.radioButtonRequestTagIdle.Checked)
                {
                    mode = hfReaderDll.HFREADER_READ_UID_NORMAL;
                }
                else
                {
                    mode = hfReaderDll.HFREADER_READ_UID_REPEAT;
                }
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AGetUID(serialDevice, addrArray[0], addrArray[1], mode, ref pUid, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pUid.result);
                if (pUid.num > 0)
                {
                    int i = 0, j = 0;
                    String s = "";
                    for (i = (int)(pUid.uid[0].len - 1); i >= 0; i--)
                    {
                        s += pUid.uid[0].uid[i].ToString("X").PadLeft(4, '0');
                    }
                    if (pUid.uid[0].len == 4)
                    {
                        s += "00000000";
                    }
                    else if (pUid.uid[0].len == 7)
                    {
                        s += "0000";
                    }
                    for (i = 0; i < pUid.num; i++)
                    {
                        s = "";
                        s += pUid.uid[i].type.ToString("X").PadLeft(4, '0');
                        s += " ";
                        s += pUid.uid[i].len.ToString("X").PadLeft(2, '0');
                        s += " ";
                        for (j = 0; j < pUid.uid[i].len; j++)
                        {
                            s += pUid.uid[i].uid[j].ToString("X").PadLeft(2, '0');
                        }
                        if (this.listBoxUID.FindString(s) < 0)
                        {
                            this.listBoxUID.Items.Add(s);
                        }
                    }
                    this.textBoxReadTagNum.Text = this.listBoxUID.Items.Count.ToString("X").PadLeft(2, '0');
                    this.textBoxRemainTagNum.Text = pUid.remainNum.ToString("X").PadLeft(2, '0');
                }
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String1"));
            DisplaySendInf(sendBuffer, res.GetString("String2"));
        }

        private void buttonClearListBox_Click(object sender, EventArgs e)
        {
            this.textBoxReadTagNum.Text = "00";
            this.textBoxRemainTagNum.Text = "00";
            this.listBoxUID.Items.Clear();
        }

        private void buttonReadMBlock_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            ushort[] addrArray = new ushort[2];

            ISO14443A_BLOCKPARAM pBlock = new ISO14443A_BLOCKPARAM();

            pBlock.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK * hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX];
            pBlock.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] blockNum = new Byte[1];
            Byte[] blockAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pBlock.uid))
                {
                    return;
                }
            }
            else
            {
                pBlock.uid.len = 0;
            }

            if (GetHexInput(this.textBoxBlockAddr.Text, blockAddr, 1) <= 0)
            {
                return;
            }
            pBlock.addr = blockAddr[0];

            if (GetHexInput(this.textBoxRBlockNum.Text, blockNum, 1) <= 0)
            {
                return;
            }
            pBlock.num = blockNum[0];

            if (pBlock.num > hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX)
            {
                MessageBox.Show(res.GetString("String3")+ hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX.ToString("X").PadLeft(2, '0') + "Page");
                pBlock.num = hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX;
                this.textBoxRBlockNum.Text = hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX.ToString("X").PadLeft(2, '0');
            }

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxBlockKeyType.SelectedIndex == 0)
                {
                    pBlock.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pBlock.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxBlockKey.Text, pBlock.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pBlock.keyType = 0x00;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthReadM1Block(serialDevice, addrArray[0], addrArray[1], ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pBlock.result.flag == 0)
                {
                    String s = "";
                    int j = 0;
                    int i = 0;
                    for (j = 0; j < pBlock.num; j++)
                    {
                        for (i = 0; i < hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK; i++)
                        {
                            s += pBlock.block[j * hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK + i].ToString("X").PadLeft(2, '0');
                        }
                        s += "\r\n";
                    }
                    this.textBoxRMBlockData.Text = s;
                }

                DisplayOpResult(pBlock.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String4"));
            DisplaySendInf(sendBuffer, res.GetString("String4"));
        }

        private void buttonClearReadInfo_Click(object sender, EventArgs e)
        {
            this.textBoxRMBlockData.Text = "";
        }

        private void buttonWriteMBlock_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_BLOCKPARAM pBlock = new ISO14443A_BLOCKPARAM();

            pBlock.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK * hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX];
            pBlock.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] data = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] blockNum = new Byte[1];
            Byte[] blockAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pBlock.uid))
                {
                    return;
                }
            }
            else
            {
                pBlock.uid.len = 0;
            }

            if (GetHexInput(this.textBoxBlockAddr.Text, blockAddr, 1) <= 0)
            {
                return;
            }
            pBlock.addr = blockAddr[0];

            if (GetHexInput(this.textBoxWBlockNum.Text, blockNum, 1) <= 0)
            {
                return;
            }
            pBlock.num = blockNum[0];

            if (pBlock.num > hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX)
            {
                MessageBox.Show(res.GetString("String3") + hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX.ToString("X").PadLeft(2, '0') + "��");
                pBlock.num = hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX;
                this.textBoxWBlockNum.Text = hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX.ToString("X").PadLeft(2, '0');
            }

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxBlockKeyType.SelectedIndex == 0)
                {
                    pBlock.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pBlock.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxBlockKey.Text, pBlock.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pBlock.keyType = 0x00;
            }

            String s = this.textBoxWMBlockData.Text;
            String[] dataString = new String[32];
            dataString = s.Split('\n');
            if (blockNum[0] > dataString.Length)
            {
                MessageBox.Show(res.GetString("String6"));
                return;
            }
            else
            {
                int j = 0;
                int i = 0;
                for (i = 0; i < blockNum[0]; i++)
                {
                    int pos = dataString[i].IndexOf('\r');
                    if (pos >= 0)
                    {
                        dataString[i] = dataString[i].Remove(pos);
                    }

                    s = dataString[i];

                    if (GetHexInput(s, data, hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK) <= 0)
                    {
                        return;
                    }
                    else
                    {
                        for (j = 0; j < hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK; j++)
                        {
                            pBlock.block[i * hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK + j] = data[j];
                        }
                    }
                }
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthWriteM1Block(serialDevice, addrArray[0], addrArray[1], ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pBlock.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String7"));
            DisplaySendInf(sendBuffer, res.GetString("String8"));
        }

        private void buttonClearWriteInfo_Click(object sender, EventArgs e)
        {
            this.textBoxWMBlockData.Text = "";
        }

        private void buttonReadValue_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_VALUEPARAM pValue = new ISO14443A_VALUEPARAM();

            pValue.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pValue.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            //            Byte[] transAddr = new Byte[1];
            Byte[] valueAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pValue.uid))
                {
                    return;
                }
            }
            else
            {
                pValue.uid.len = 0;
            }

            if (GetHexInput(this.textBoxValueAddr.Text, valueAddr, 1) <= 0)
            {
                return;
            }
            pValue.blockAddr = valueAddr[0];

            //             if (GetHexInput(this.textBoxBackupAddr.Text, transAddr, 1) <= 0)
            //             {
            //                 return;
            //             }
            //             pValue.transAddr = transAddr[0];

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxValueKeyType.SelectedIndex == 0)
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxValueKey.Text, pValue.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pValue.keyType = 0x00;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthReadM1Value(serialDevice, addrArray[0], addrArray[1], ref pValue, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pValue.result.flag == 0)
                {
                    String s = "";
                    s = pValue.value.ToString();
                    this.textBoxValue.Text = s;
                    s = pValue.transAddr.ToString("X").PadLeft(2, '0');
                    this.textBoxBackupAddr.Text = s;
                }

                DisplayOpResult(pValue.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String9"));
            DisplaySendInf(sendBuffer, res.GetString("String10"));
        }

        private void buttonWriteValue_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_VALUEPARAM pValue = new ISO14443A_VALUEPARAM();

            pValue.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pValue.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] transAddr = new Byte[1];
            Byte[] valueAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pValue.uid))
                {
                    return;
                }
            }
            else
            {
                pValue.uid.len = 0;
            }

            if (GetHexInput(this.textBoxValueAddr.Text, valueAddr, 1) <= 0)
            {
                return;
            }
            pValue.blockAddr = valueAddr[0];

            if (GetHexInput(this.textBoxBackupAddr.Text, transAddr, 1) <= 0)
            {
                return;
            }
            pValue.transAddr = transAddr[0];

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxValueKeyType.SelectedIndex == 0)
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxValueKey.Text, pValue.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pValue.keyType = 0x00;
            }

            pValue.value = Convert.ToInt32(this.textBoxValue.Text, 10);

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthWriteM1Value(serialDevice, addrArray[0], addrArray[1], ref pValue, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pValue.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String11"));
            DisplaySendInf(sendBuffer, res.GetString("String12"));
        }

        private void buttonDecValue_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_VALUEPARAM pValue = new ISO14443A_VALUEPARAM();

            pValue.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pValue.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] transAddr = new Byte[1];
            Byte[] valueAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pValue.uid))
                {
                    return;
                }
            }
            else
            {
                pValue.uid.len = 0;
            }

            if (GetHexInput(this.textBoxValueAddr.Text, valueAddr, 1) <= 0)
            {
                return;
            }
            pValue.blockAddr = valueAddr[0];

            if (GetHexInput(this.textBoxTransAddr.Text, transAddr, 1) <= 0)
            {
                return;
            }
            pValue.transAddr = transAddr[0];

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxValueKeyType.SelectedIndex == 0)
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxValueKey.Text, pValue.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pValue.keyType = 0x00;
            }

            pValue.value = Convert.ToInt32(this.textBoxOpValue.Text, 10);

            pValue.opCode = 0xC0; //��ֵ������

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthOpM1Value(serialDevice, addrArray[0], addrArray[1], ref pValue, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pValue.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String13"));
            DisplaySendInf(sendBuffer, res.GetString("String14"));
        }

        private void buttonIncValue_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_VALUEPARAM pValue = new ISO14443A_VALUEPARAM();

            pValue.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pValue.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] transAddr = new Byte[1];
            Byte[] valueAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pValue.uid))
                {
                    return;
                }
            }
            else
            {
                pValue.uid.len = 0;
            }

            if (GetHexInput(this.textBoxValueAddr.Text, valueAddr, 1) <= 0)
            {
                return;
            }
            pValue.blockAddr = valueAddr[0];

            if (GetHexInput(this.textBoxTransAddr.Text, transAddr, 1) <= 0)
            {
                return;
            }
            pValue.transAddr = transAddr[0];

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxValueKeyType.SelectedIndex == 0)
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxValueKey.Text, pValue.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pValue.keyType = 0x00;
            }

            pValue.value = Convert.ToInt32(this.textBoxOpValue.Text, 10);

            pValue.opCode = 0xC1; //��ֵ������

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthOpM1Value(serialDevice, addrArray[0], addrArray[1], ref pValue, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pValue.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String15"));
            DisplaySendInf(sendBuffer, res.GetString("String16"));
        }

        private void buttonRestoreValue_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_VALUEPARAM pValue = new ISO14443A_VALUEPARAM();

            pValue.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pValue.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] transAddr = new Byte[1];
            Byte[] valueAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pValue.uid))
                {
                    return;
                }
            }
            else
            {
                pValue.uid.len = 0;
            }

            if (GetHexInput(this.textBoxValueAddr.Text, valueAddr, 1) <= 0)
            {
                return;
            }
            pValue.blockAddr = valueAddr[0];

            if (GetHexInput(this.textBoxRestoreAddr.Text, transAddr, 1) <= 0)
            {
                return;
            }
            pValue.transAddr = transAddr[0];

            if (this.checkBoxAuth.Checked)
            {
                if (this.comboBoxValueKeyType.SelectedIndex == 0)
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_A;
                }
                else
                {
                    pValue.keyType = hfReaderDll.HFREADER_ISO14443A_KEY_B;
                }

                if (GetHexInput(this.textBoxValueKey.Text, pValue.key, hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY) <= 0)
                {
                    return;
                }
            }
            else
            {
                pValue.keyType = 0x00;
            }

            pValue.value = Convert.ToInt32(this.textBoxRestoreValue.Text, 10);

            pValue.opCode = 0xC2; //ת��ֵ������

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthOpM1Value(serialDevice, addrArray[0], addrArray[1], ref pValue, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pValue.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String17"));
            DisplaySendInf(sendBuffer, res.GetString("String18"));
        }

        private void ISO14443A_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (testInfoWriter != null)
            {
                testInfoWriter.Close();
                testInfoWriter = null;
            }
            if (testInfoStream != null)
            {
                testInfoStream.Close();
                testInfoStream = null;
            }

            Dispose();
            Close();
        }

        private void listBoxUID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listBoxUID.SelectedItem != null)
            {
                this.textBoxSelectedISO14443AUID.Text = this.listBoxUID.SelectedItem.ToString();
            }
        }

        private void buttonClearInfo_Click(object sender, EventArgs e)
        {
            this.textBoxInf.Text = "";
        }

        private void checkBoxAuth_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBoxAuth.Checked)
            {
                this.comboBoxBlockKeyType.Enabled = true;
                this.textBoxBlockKey.Enabled = true;
            }
            else
            {
                this.comboBoxBlockKeyType.Enabled = false;
                this.textBoxBlockKey.Enabled = false;
            }
        }

        private void buttonAuthUltralightC_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();

            Byte[] key = new Byte[hfReaderDll.HFREADER_ISO14443A_M0U2KEY_LEN];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] blockNum = new Byte[1];
            Byte[] blockAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxUltralightKey.Text, key, hfReaderDll.HFREADER_ISO14443A_M0U2KEY_LEN) <= 0)
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AAuthUltralightC(serialDevice, addrArray[0], addrArray[1], key, ref pResult, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String19"));
            DisplaySendInf(sendBuffer, res.GetString("String20"));
        }

        private void buttonReadM0_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_BLOCKPARAM pBlock = new ISO14443A_BLOCKPARAM();

            pBlock.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK * hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX];
            pBlock.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] blockNum = new Byte[1];
            Byte[] blockAddr = new Byte[1];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pBlock.uid))
                {
                    return;
                }
            }
            else
            {
                pBlock.uid.len = 0;
            }

            /* if (GetHexInput(this.textBoxRM0Addr.Text, blockAddr, 1) <= 0)
             {
                 return;
             }
             pBlock.addr = blockAddr[0];

             if (GetHexInput(this.textBoxRM0Num.Text, blockNum, 1) <= 0)
             {
                 return;
             }*/
            GetHexInput(this.textBoxRM0Addr.Text, blockAddr, textBoxRM0Addr.Text.Length);
            pBlock.num = blockNum[0];

            if (pBlock.num > hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX)
            {
                MessageBox.Show(res.GetString("String3") + hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX.ToString("X").PadLeft(2, '0') + "Page");
                pBlock.num = hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX;
                this.textBoxRM0Num.Text = hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX.ToString("X").PadLeft(2, '0');
            }

            pBlock.keyType = 0x00;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AReadM0Block(serialDevice, addrArray[0], addrArray[1], ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pBlock.result.flag == 0)
                {
                    String s = "";
                    int j = 0;
                    int i = 0;
                    for (j = 0; j < pBlock.num; j++)
                    {
                        for (i = 0; i < hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK; i++)
                        {
                            s += pBlock.block[j * hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK + i].ToString("X").PadLeft(2, '0');
                        }
                        s += "\r\n";
                    }
                    this.textBoxRM0BlockData.Text = s;
                }

                DisplayOpResult(pBlock.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String21"));
            DisplaySendInf(sendBuffer, res.GetString("String22"));
        }

        private void buttonClearReadM0_Click(object sender, EventArgs e)
        {
            this.textBoxRM0BlockData.Text = "";
        }

        private void buttonWriteM0_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_BLOCKPARAM pBlock = new ISO14443A_BLOCKPARAM();

            pBlock.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pBlock.block = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1BLOCK * hfReaderDll.HFREADER_ISO14443A_M1BLOCKNUM_MAX];
            pBlock.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            Byte[] blockNum = new Byte[1];
            Byte[] blockAddr = new Byte[1];

            Byte[] data = new Byte[16];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pBlock.uid))
                {
                    return;
                }
            }
            else
            {
                pBlock.uid.len = 0;
            }

            if (GetHexInput(this.textBoxWM0Addr.Text, blockAddr, 1) <= 0)
            {
                return;
            }
            pBlock.addr = blockAddr[0];

            if (GetHexInput(this.textBoxWM0Num.Text, blockNum, 1) <= 0)
            {
                return;
            }
            pBlock.num = blockNum[0];
            if (pBlock.num > hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX)
            {
                MessageBox.Show(res.GetString("String3") + hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX.ToString("X").PadLeft(2, '0') + "Page");
                pBlock.num = hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX;
                this.textBoxWM0Num.Text = hfReaderDll.HFREADER_ISO14443A_MOBLOCKNUM_MAX.ToString("X").PadLeft(2, '0');
            }

            String s = this.textBoxWM0BlockData.Text;
            String[] dataString = new String[64];
            dataString = s.Split('\n');
            if (blockNum[0] > dataString.Length)
            {
                MessageBox.Show(res.GetString("String6"));
                return;
            }
            else
            {
                int j = 0;
                int i = 0;
                for (i = 0; i < blockNum[0]; i++)
                {
                    int pos = dataString[i].IndexOf('\r');
                    if (pos >= 0)
                    {
                        dataString[i] = dataString[i].Remove(pos);
                    }

                    s = dataString[i];

                    if (GetHexInput(s, data, hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK) <= 0)
                    {
                        return;
                    }
                    else
                    {
                        for (j = 0; j < hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK; j++)
                        {
                            pBlock.block[i * hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK + j] = data[j];
                        }
                    }
                }
            }

            pBlock.keyType = 0x00;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AWriteM0Block(serialDevice, addrArray[0], addrArray[1], ref pBlock, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pBlock.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String23"));
            DisplaySendInf(sendBuffer, res.GetString("String24"));
        }

        private void buttonClearWriteM0_Click(object sender, EventArgs e)
        {
            this.textBoxWM0BlockData.Text = "";
        }

        public void CtrlUidEnalbe(bool b)
        {
            this.checkBoxUidEnable.Checked = b;
            this.textBoxSelectedISO14443AUID.Enabled = b;
            if (b)
            {
                this.radioButtonRequestTagIdle.Text = res.GetString("String25");
                this.radioButtonRequestTagAll.Text = res.GetString("String26");
            }
            else
            {
                this.radioButtonRequestTagIdle.Text = "IDLE";
                this.radioButtonRequestTagAll.Text = "All";
            }
        }

        private void checkBoxUidEnable_CheckedChanged(object sender, EventArgs e)
        {
            this.textBoxSelectedISO14443AUID.Enabled = this.checkBoxUidEnable.Checked;
        }

        private void buttonHalt_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_OPPARAM pInfo = new ISO14443A_OPPARAM();
            pInfo.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pInfo.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pInfo.uid))
                {
                    return;
                }
            }
            else
            {
                pInfo.uid.len = 0;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443AHalt(serialDevice, addrArray[0], addrArray[1], ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pInfo.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String27"));
            DisplaySendInf(sendBuffer, res.GetString("String28"));
        }

        private void buttonRatsClear_Click(object sender, EventArgs e)
        {
            this.textBoxRatsRsp.Text = "";
        }

        private void buttonRatsPsam_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_OPPARAM pInfo = new ISO14443A_OPPARAM();
            pInfo.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pInfo.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pInfo.uid))
                {
                    return;
                }
            }
            else
            {
                pInfo.uid.len = 0;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443ARats(serialDevice, addrArray[0], addrArray[1], ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pInfo.result.flag == 0)
                {
                    String s = "";
                    int i = 0;
                    for (i = 0; i < pInfo.rxLen; i++)
                    {
                        s += pInfo.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxRatsRsp.Text = s;
                }

                DisplayOpResult(pInfo.result);
            }
            DisplayRcvInf(rcvBuffer,res.GetString("String29"));
            DisplaySendInf(sendBuffer, res.GetString("String30"));
        }

        private void buttonEsamPps_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            ushort[] addrArray = new ushort[2];
            uint[] txPpsInfoLen = new uint[1];
            Byte[] ppsInfo = new Byte[256];
            int index = 0;
            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            index = this.comboBoxEsamIndex.SelectedIndex + 1;
            txPpsInfoLen[0] = (uint)GetHexInput(textBoxPps.Text, ppsInfo);
            textBoxPps.Text = "";

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443APps(serialDevice, 0x0000, addrArray[1], (Byte)index, txPpsInfoLen, ppsInfo, ref pResult, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pResult.flag == 0)
                {
                    String s = "";
                    int i = 0;
                    for (i = 0; i < txPpsInfoLen[0]; i++)
                    {
                        s += ppsInfo[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxPps.Text = s;
                }

                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String31"));
            DisplaySendInf(sendBuffer, res.GetString("String32"));
        }

        private void buttonSelEsamBr_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            ushort[] addrArray = new ushort[2];
            int index = 0;
            int esamBr = 0;
            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            index = this.comboBoxEsamIndex.SelectedIndex + 1;
            esamBr = this.comboBoxEsamSelBr.SelectedIndex;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443ASelEsamBr(serialDevice, 0x0000, addrArray[1], (Byte)index, (Byte)esamBr, ref pResult, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String33"));
            DisplaySendInf(sendBuffer, res.GetString("String34"));
        }

        private void buttonCtrlEsam_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_OPPARAM pInfo = new ISO14443A_OPPARAM();
            pInfo.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pInfo.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            int index = 0, state = 0;

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pInfo.uid))
                {
                    return;
                }
            }
            else
            {
                pInfo.uid.len = 0;
            }

            index = this.comboBoxEsamIndex.SelectedIndex + 1;
            state = this.comboBoxEsamState.SelectedIndex;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443ACtrlEsam(serialDevice, addrArray[0], addrArray[1], (Byte)(index), (Byte)(state), ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pInfo.result.flag == 0)
                {
                    String s = "";
                    int i = 0;
                    for (i = 0; i < pInfo.rxLen; i++)
                    {
                        s += pInfo.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxCtrlEsamRsp.Text = s;
                }

                DisplayOpResult(pInfo.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String35"));
            DisplaySendInf(sendBuffer, res.GetString("String36"));
        }

        private void buttonCtrEsamClear_Click(object sender, EventArgs e)
        {
            this.textBoxCtrlEsamRsp.Text = "";
        }

        private void buttonApduTxClear_Click(object sender, EventArgs e)
        {
            this.textBoxApduTx.Text = "";
            this.textBoxApduTxLen.Text = "00";
        }

        private void buttonApduRxClear_Click(object sender, EventArgs e)
        {
            this.textBoxApduRx.Text = "";
            this.textBoxApduRxLen.Text = "00";
        }

        private void buttonApdu_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_OPPARAM pInfo = new ISO14443A_OPPARAM();
            pInfo.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pInfo.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            int index = 0;

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pInfo.uid))
                {
                    return;
                }
            }
            else
            {
                pInfo.uid.len = 0;
            }

            pInfo.txLen = (uint)(GetHexInput(this.textBoxApduTx.Text, pInfo.txFrame));
            if (pInfo.txLen == 0)
            {
                MessageBox.Show(res.GetString("String37"));
                return;
            }

            index = this.comboBoxApduIndex.SelectedIndex;

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            this.textBoxApduTxLen.Text = pInfo.txLen.ToString("X").PadLeft(2, '0');
            int rlt = hfReaderDll.iso14443AApdu(serialDevice, addrArray[0], addrArray[1], (Byte)(index), ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pInfo.result.flag == 0)
                {
                    String s = "";
                    int i = 0;
                    for (i = 0; i < pInfo.rxLen; i++)
                    {
                        s += pInfo.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxApduRx.Text = s;
                    this.textBoxApduRxLen.Text = pInfo.rxLen.ToString("X").PadLeft(2, '0');
                }

                DisplayOpResult(pInfo.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String38"));
            DisplaySendInf(sendBuffer, res.GetString("String39"));
        }

        private void buttonDsel_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }
            ushort[] addrArray = new ushort[2];

            ISO14443A_OPPARAM pInfo = new ISO14443A_OPPARAM();
            pInfo.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pInfo.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pInfo.key = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_M1_KEY];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            while (bOperatingSerial) ;
            bOperatingSerial = true;

            int rlt = hfReaderDll.iso14443ADsel(serialDevice, addrArray[0], addrArray[1], ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pInfo.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String40"));
            DisplaySendInf(sendBuffer, res.GetString("String41"));
        }

        private void buttonDtuTxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuTx.Text = "";
        }

        private void buttonDtuRxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuRx.Text = "";
        }

        private void buttonDtu_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            ushort[] addrArray = new ushort[2];
            Byte[] rxLen = new Byte[1];
            Byte[] txBit = new Byte[1];
            Byte[] rxBit = new Byte[1];

            ISO14443A_DTU pDtu = new ISO14443A_DTU();
            pDtu.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];
            pDtu.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pDtu.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (this.checkBoxUidEnable.Checked)
            {
                if (!GetUid(ref pDtu.uid))
                {
                    return;
                }
            }
            else
            {
                pDtu.uid.len = 0;
            }

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxDtuRxLen.Text, rxLen, 1) <= 0)
            {
                return;
            }
            pDtu.rxLen = rxLen[0];

            if (GetHexInput(this.textBoxDtuRxBit.Text, rxBit, 1) <= 0)
            {
                return;
            }
            pDtu.rxBit = rxBit[0];

            if (GetHexInput(this.textBoxDtuTxBit.Text, txBit, 1) <= 0)
            {
                return;
            }
            pDtu.txBit = txBit[0];

            pDtu.txLen = (uint)(GetHexInput(this.textBoxDtuTx.Text, pDtu.txFrame));

            pDtu.timeout = Convert.ToUInt32(this.textBoxDtuTime.Text, 10);

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443ADtu(serialDevice, addrArray[0], addrArray[1], ref pDtu, sendBuffer, rcvBuffer);
            bOperatingSerial = false;

            if (rlt > 0)
            {
                if (pDtu.result.flag == 0)
                {
                    string s = "";
                    for (uint i = 0; i < pDtu.rxLen; i++)
                    {
                        s += pDtu.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxDtuRx.Text = s;
                    this.textBoxDtuRxBit.Text = pDtu.rxBit.ToString("X").PadLeft(2, '0');
                }
                DisplayOpResult(pDtu.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String42"));
            DisplaySendInf(sendBuffer, res.GetString("String43"));
        }

        private const int POLYNOMIAL = 0x8408;
        private const int PRESET_VALUE = 0x6363;
        private int calCrc(byte[] pFrame, int len)
        {
            int crc = 0;
            int temp = 0;
            int i = 0, j = 0;
            crc = PRESET_VALUE;
            for (i = 0; i < len; i++)
            {
                temp = (int)(pFrame[i]);
                temp &= 0xFF;
                crc = (crc ^ temp);
                crc &= 0xFFFF;
                for (j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) == 0x0001)
                    {
                        crc = (crc >> 1) ^ POLYNOMIAL;
                    }
                    else
                    {
                        crc = (crc >> 1);
                    }
                }
                crc &= 0xFFFF;
            }

            return crc;
        }

        private void buttonDtuAddCrc_Click(object sender, EventArgs e)
        {
            Byte[] frame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            int len = 0;
            int crc = 0;

            len = (GetHexInput(this.textBoxDtuTx.Text, frame));
            crc = (calCrc(frame, len)) & 0xFFFF;
            frame[len] = (Byte)((crc & 0xFF) & 0xFF);
            frame[len + 1] = (Byte)((crc >> 8) & 0xFF);

            string s = "";
            for (uint i = 0; i < len + 2; i++)
            {
                s += frame[i].ToString("X").PadLeft(2, '0');
            }
            this.textBoxDtuTx.Text = s;
        }

        private void buttonDtuAddSum_Click(object sender, EventArgs e)
        {
            Byte[] frame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            int len = 0;
            int sum = 0;
            uint i = 0;

            len = (GetHexInput(this.textBoxDtuTx.Text, frame));
            for (i = 0; i < len; i++)
            {
                sum += frame[i];
                sum &= 0xFF;
            }
            frame[len] = (byte)(sum);

            string s = "";
            for (i = 0; i < len + 1; i++)
            {
                s += frame[i].ToString("X").PadLeft(2, '0');
            }
            this.textBoxDtuTx.Text = s;
        }

        private void buttonImClearInfo_Click(object sender, EventArgs e)
        {
            this.textBoxImInfo.Text = "";
        }

        private void ReceiveFrame()
        {
            while (true)
            {
                if (serialDevice > 0 && (!bOperatingSerial))
                {
                    if (imOpTagMode == 2)
                    {
                        ushort[] addrArray = new ushort[2];

                        if (!GetDeviceAddr(addrArray))
                        {
                            return;
                        }
                        
                        imOperation(addrArray);

                        System.Threading.Thread.Sleep(Convert.ToInt32(textBoxImOpDelay.Text));
                    }
                    else if (imOpTagMode == 0x82)
                    {
                        ushort[] addrArray = new ushort[2];

                        if (!GetDeviceAddr(addrArray))
                        {
                            return;
                        }

                        imNormalOperation(addrArray);

                        System.Threading.Thread.Sleep(Convert.ToInt32(textBoxImOpDelay.Text));
                    }
                }
                System.Threading.Thread.Sleep(200);
            }
        }

        private void SaveTestInfo(string info)
        {
            if (testInfoWriter != null)
            {
                string timeStr = "";

                timeStr = DateTime.Now.ToLongTimeString() + "-" + DateTime.Now.Millisecond.ToString().PadLeft(3, '0');
                timeStr = timeStr.Replace('/', '-');
                timeStr = timeStr.Replace(':', '-');

                info = timeStr + ":" + info;

                testInfoWriter.BaseStream.Seek(0, SeekOrigin.End);
                testInfoWriter.Write(info);
                testInfoWriter.Flush();
            }
        }

        private void buttonImStart_Click(object sender, EventArgs e)
        {
            if (imOpTagMode > 0)
            {
                imOpTagMode = 0;
                this.buttonImStart.Text = res.GetString("String44");

                numericUpDownAntNum.Enabled = true;
                textBoxAntWorkTime.Enabled = true;

                comboBoxOpMode.Enabled = true;
                textBoxOpTimeout.Enabled = true;

                numericUpDownBlockAddr.Enabled = true;
                numericUpDownBlockNum.Enabled = true;

                textBoxImOpDelay.Enabled = true;
                checkBoxImOpContinue.Enabled = true;
            }
            else
            {
                if (serialDevice < 0)
                {
                    MessageBox.Show(res.GetString("Operror7"));
                    return;
                }
                ushort[] addrArray = new ushort[2];

                if (!GetDeviceAddr(addrArray))
                {
                    return;
                }

                imParams.antNum = Convert.ToUInt32(numericUpDownAntNum.Value);
                imParams.antWorkTime = Convert.ToUInt32(textBoxAntWorkTime.Text);

                imParams.opMode = (UInt32)comboBoxOpMode.SelectedIndex;
                imParams.opTimeout = Convert.ToUInt32(textBoxOpTimeout.Text);

                imParams.blockAddr = Convert.ToUInt32(numericUpDownBlockAddr.Value);
                imParams.blockNum = Convert.ToUInt32(numericUpDownBlockNum.Value);

                if (imParams.opMode == hfReaderDll.HFREADER_ISO14443A_IMMODE_WB)
                {
                    String s = textBoxImBlock.Text;
                    s = s.Replace("\r", "");
                    s = s.Replace("\n", "");

                    int l = GetHexInput(s, imParams.block, (int)imParams.blockNum * hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK);
                    if (l != imParams.blockNum * hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK)
                    {
                        MessageBox.Show(res.GetString("String45"));
                        return;
                    }
                }

                this.buttonImStart.Text = res.GetString("String46");
                numericUpDownAntNum.Enabled = false;
                textBoxAntWorkTime.Enabled = false;

                comboBoxOpMode.Enabled = false;
                textBoxOpTimeout.Enabled = false;

                numericUpDownBlockAddr.Enabled = false;
                numericUpDownBlockNum.Enabled = false;

                textBoxImOpDelay.Enabled = false;
                checkBoxImOpContinue.Enabled = false;

                imOpTagTimes = 0;
                imOpTagOkTimes = 0;
                imOpComErrTimes = 0;
                imOpCmpErrTimes = 0;
                imOpUidCompare = "";

                imOpTagMode = 1;
                if (checkBoxImOpContinue.Checked)
                {
                    string timeStr = "";

                    timeStr = DateTime.Now.ToShortDateString();
                    timeStr = timeStr.Replace('/', '-');
                    timeStr = timeStr.Replace(':', '-');

                    if (testInfoWriter != null)
                    {
                        testInfoWriter.Close();
                        testInfoWriter = null;
                    }
                    if (testInfoStream != null)
                    {
                        testInfoStream.Close();
                        testInfoStream = null;
                    }

                    string path = ".\\Log " + timeStr + ".txt";
                    testInfoStream = new FileStream(path, FileMode.OpenOrCreate);
                    if (testInfoStream == null)
                    {
                        MessageBox.Show("Fail to open test info.");
                    }
                    else
                    {
                        testInfoStream.Flush();
                        testInfoWriter = new StreamWriter(testInfoStream, System.Text.Encoding.GetEncoding("GB2312"));
                        testInfoWriter.BaseStream.Seek(0, SeekOrigin.End);

                        if (testInfoWriter == null)
                        {
                            MessageBox.Show("Fail to open test info.");
                        }
                    }


                    imOpTagMode = 2;
                    if (checkBoxImNormalMode.Checked)
                    {
                        imOpTagMode |= 0x80;
                    }
                }
                else
                {
                    if (checkBoxImNormalMode.Checked)
                    {
                        imNormalOperation(addrArray);
                    }
                    else
                    {
                        imOperation(addrArray);
                    }

                    numericUpDownAntNum.Enabled = true;
                    textBoxAntWorkTime.Enabled = true;

                    comboBoxOpMode.Enabled = true;
                    textBoxOpTimeout.Enabled = true;

                    numericUpDownBlockAddr.Enabled = true;
                    numericUpDownBlockNum.Enabled = true;

                    textBoxImOpDelay.Enabled = true;
                    checkBoxImOpContinue.Enabled = true;
                    this.buttonImStart.Text = res.GetString("String44");
                    imOpTagMode = 0;
                }
            }
        }

        private void AddImInfo(object obj)
        {
            if (this.textBoxImInfo.InvokeRequired)
            {
                Delegate d = new Delegate(AddImInfo);
                this.textBoxImInfo.Invoke(d, obj);
            }
            else
            {
                this.textBoxImInfo.Text = obj.ToString();// +textBoxImInfo.Text;
            }
        }

        private void AddImBlockInfo(object obj)
        {
            if (this.textBoxImBlock.InvokeRequired)
            {
                Delegate d = new Delegate(AddImBlockInfo);
                this.textBoxImBlock.Invoke(d, obj);
            }
            else
            {
                this.textBoxImBlock.Text = obj.ToString();
            }
        }

        private void DisplayImInfo(ref ISO14443A_IMINFO info)
        {
            ISO14443A_IMINFO im = new ISO14443A_IMINFO();
            im.antIndex = info.antIndex;
            im.blockIndex = info.blockIndex;
            im.noise = info.noise;
            im.signal = info.signal;
            im.sofLv = info.sofLv;
            im.tempr = info.tempr;
            im.paTempr = info.paTempr;
            im.uidLen = info.uidLen;

            string s = "";
            s += res.GetString("String47") + (im.antIndex + 1).ToString();
            s += res.GetString("String48") + im.noise.ToString() + "mv";
            s += res.GetString("String49") + im.signal.ToString() + "mv";
            s += res.GetString("String50") + im.paTempr.ToString() + res.GetString("String54");
            s += res.GetString("String51") + im.tempr.ToString() + res.GetString("String54");
            s += res.GetString("String52") + im.uidLen.ToString();
            s += res.GetString("String53") + im.blockIndex.ToString();

            AddDisplayInfo(s + "\r\n" + this.textBoxInf.Text);
        }

        public void imNormalOperation(ushort[] addrArray)
        {
            int i = 0;
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            string infoStr = "";
            int rlt = 0;

            AddDisplayInfo("");

            HFREADER_OPRESULT opResult = new HFREADER_OPRESULT();

            ISO14443A_UIDPARAM uidParams = new ISO14443A_UIDPARAM();
            uidParams.uid = new ISO14443A_UID[15];
            HFREADER_CONFIG pReaderConfig = new HFREADER_CONFIG();

            Byte WorkMode = 0;
            WorkMode |= hfReaderDll.HFREADER_CFG_TYPE_ISO14443A | hfReaderDll.HFREADER_CFG_WM_INVENTORY;
            pReaderConfig.workMode = WorkMode;
            pReaderConfig.cmdMode = hfReaderDll.HFREADER_CFG_INVENTORY_TRIGGER;
            pReaderConfig.uidSendMode = hfReaderDll.HFREADER_CFG_UID_POSITIVE;
            pReaderConfig.beepStatus = hfReaderDll.HFREADER_CFG_BUZZER_ENABLE;
            pReaderConfig.afiCtrl = hfReaderDll.HFREADER_CFG_AFI_DISABLE;
            pReaderConfig.tagStatus = hfReaderDll.HFREADER_CFG_TAG_NOQUIET;
            pReaderConfig.baudrate = hfReaderDll.HFREADER_CFG_BAUDRATE38400;
            pReaderConfig.afi = 0x00;
            pReaderConfig.readerAddr = (ushort)(addrArray[1]);

            imOpTagTimes++;

            if (imOpTagTimes == 1)
            {
                rlt = hfReaderDll.hfReaderSetConfig(serialDevice, addrArray[0], addrArray[1], ref pReaderConfig, null, null);
                if (rlt <= 0)
                {
                    infoStr += res.GetString("String55")+"\r\n";
                }
            }

            Stopwatch sw = new Stopwatch();
            sw.Start();
            rlt = hfReaderDll.hfReaderCtrlRf(serialDevice, addrArray[0], addrArray[1], hfReaderDll.HFREADER_RF_RESET, ref opResult, null, null);
            if (rlt <= 0)
            {
                infoStr += res.GetString("String56")+"\r\n";
            }
            else
            {
                infoStr += res.GetString("String57")+"\r\n";
                rlt = hfReaderDll.iso14443AGetUID(serialDevice, addrArray[0], addrArray[1], hfReaderDll.HFREADER_READ_UID_NORMAL, ref uidParams, null, null);
                if (rlt > 0)
                {
                    if (uidParams.num > 0)
                    {
                        if (uidParams.num == 1)
                        {
                            string uidStr = "";
                            uidStr = fatherForm.Hex2Str(uidParams.uid[0].uid, 0, (int)uidParams.uid[0].len);
                            if (imOpUidCompare == "")
                            {
                                imOpUidCompare = uidStr;
                            }
                            infoStr += res.GetString("String58") + uidStr + "\r\n";

                            if (uidStr == imOpUidCompare)
                            {
                                if (imParams.opMode == 0)   //ֻ��UID
                                {
                                    imOpTagOkTimes++;
                                }
                                else if (imParams.opMode == 1)   //�����ݿ�
                                {
                                    ISO14443A_BLOCKPARAM rBlockParams = new ISO14443A_BLOCKPARAM();
                                    rBlockParams.block = new Byte[13 * 16];
                                    rBlockParams.key = new Byte[6];
                                    rBlockParams.keyType = 0;
                                    rBlockParams.addr = imParams.blockAddr;
                                    rBlockParams.num = imParams.blockNum;

                                    rlt = hfReaderDll.iso14443AReadM0Block(serialDevice, addrArray[0], addrArray[1], ref rBlockParams, null, null);
                                    if (rlt > 0 && rBlockParams.result.flag == 0)
                                    {
                                        infoStr += res.GetString("String59") + fatherForm.Hex2Str(rBlockParams.block, 0, (int)(rBlockParams.num * 4)) + "\r\n";
                                        imOpTagOkTimes++;
                                    }
                                    else
                                    {
                                        infoStr += res.GetString("String60")+"\r\n";
                                    }
                                }
                                else if (imParams.opMode == 2)   //д���ݿ�
                                {
                                    Byte[] block = new Byte[imParams.blockNum * 4];
                                    Random r = new Random();
                                    ISO14443A_BLOCKPARAM blockParams = new ISO14443A_BLOCKPARAM();
                                    blockParams.block = new Byte[13 * 16];
                                    blockParams.key = new Byte[6];
                                    blockParams.keyType = 0;
                                    blockParams.addr = imParams.blockAddr;
                                    blockParams.num = imParams.blockNum;

                                    for (i = 0; i < imParams.blockNum; i++)
                                    {
                                        int t = 0;
                                        t = r.Next();
                                        block[i * 4 + 0] = (Byte)((t >> 0) & 0xFF);
                                        block[i * 4 + 1] = (Byte)((t >> 8) & 0xFF);
                                        block[i * 4 + 2] = (Byte)((t >> 16) & 0xFF);
                                        block[i * 4 + 3] = (Byte)((t >> 24) & 0xFF);
                                    }
                                    Array.Copy(block, blockParams.block, (int)(imParams.blockNum * 4));

                                    rlt = hfReaderDll.iso14443AWriteM0Block(serialDevice, addrArray[0], addrArray[1], ref blockParams, null, null);
                                    if (rlt > 0 && blockParams.result.flag == 0)
                                    {
                                        infoStr += res.GetString("String61") + fatherForm.Hex2Str(blockParams.block, 0, (int)(blockParams.num * 4)) + "\r\n";

                                        rlt = hfReaderDll.iso14443AReadM0Block(serialDevice, addrArray[0], addrArray[1], ref blockParams, null, null);
                                        if (rlt > 0 && blockParams.result.flag == 0)
                                        {
                                            infoStr += res.GetString("String62") + fatherForm.Hex2Str(blockParams.block, 0, (int)(blockParams.num * 4)) + "\r\n";
                                            for(i = 0; i < blockParams.num * 4; i++)
                                            {
                                                if(block[i] != blockParams.block[i])
                                                {
                                                    break;
                                                }
                                            }
                                            if (i == blockParams.num * 4)
                                            {
                                                infoStr += res.GetString("String63")+"\r\n";
                                                imOpTagOkTimes++;
                                            }
                                            else
                                            {
                                                infoStr += res.GetString("String64")+ "\r\n";
                                            }
                                        }
                                        else
                                        {
                                            infoStr += res.GetString("String60")+"\r\n";
                                        }
                                    }
                                    else
                                    {
                                        infoStr += res.GetString("String62")+"\r\n";
                                    }
                                }
                            }
                            else
                            {
                                imOpCmpErrTimes++;
                            }
                        }
                        else
                        {
                            infoStr += res.GetString("String65") + "\r\n";
                        }
                    }
                    else
                    {
                        infoStr += res.GetString("String66") + "\r\n";
                    }
                }
                else 
                {
                    infoStr += res.GetString("String67") + "\r\n";
                    imOpComErrTimes++;
                }
            }
            rlt = hfReaderDll.hfReaderCtrlRf(serialDevice, addrArray[0], addrArray[1], hfReaderDll.HFREADER_RF_CLOSE, ref opResult, null, null);
            if (rlt <= 0)
            {
                infoStr += res.GetString("String68") + "\r\n";
            }
            sw.Stop();

            infoStr += res.GetString("String69") + imOpTagTimes.ToString() +
                      res.GetString("String70") + imOpTagOkTimes.ToString() +
                      res.GetString("String71") + imOpCmpErrTimes.ToString() +
                      res.GetString("String72") + imOpComErrTimes.ToString() +
                     res.GetString("String73") + (imOpTagOkTimes * 100.0 / imOpTagTimes).ToString("F2") + "%";
            infoStr += res.GetString("String74") + sw.ElapsedMilliseconds.ToString("D") + "ms\r\n";
            AddImInfo(infoStr);
            if (imOpTagMode == 0x82)
            {
                if (testInfoWriter != null)
                {
                    SaveTestInfo(infoStr);
                }
            }
            //this.textBoxInf.Text = infoStr;
        }

        public void imOperation(ushort[] addrArray)
        {
            int i = 0;
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            string infoStr = "";
            int rlt = 0;

            hfReaderDll.imCallback = DisplayImInfo;
            AddDisplayInfo("");

            ISO14443A_IMPARAM imOperationParams = new ISO14443A_IMPARAM();
            imOperationParams.block = new byte[1024];
            imOperationParams.uid.uid = new Byte[hfReaderDll.HFREADER_ISO14443A_LEN_MAX_UID];

            imOperationParams.antNum = imParams.antNum;
            imOperationParams.antWorkTime = imParams.antWorkTime;

            imOperationParams.opMode = imParams.opMode;
            imOperationParams.opTimeout = imParams.opTimeout;

            imOperationParams.blockAddr = imParams.blockAddr;
            imOperationParams.blockNum = imParams.blockNum;

            Array.Copy(imParams.block, imOperationParams.block, 1024);

            imOpTagTimes++;

            Stopwatch sw = new Stopwatch();
            sw.Start();
            while (bOperatingSerial) ;
            bOperatingSerial = true;
            rlt = hfReaderDll.iso14443AImOperation(serialDevice, addrArray[0], addrArray[1], ref imOperationParams, hfReaderDll.imCallback, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            sw.Stop();
            if (rlt > 0)
            {
                if (imOperationParams.opMode == hfReaderDll.HFREADER_ISO14443A_IMMODE_UID)
                {
                    if (imOperationParams.uid.len > 0)
                    {
                        imOpTagOkTimes++;
                        infoStr = res.GetString("String75");
                        for (i = 0; i < imOperationParams.uid.len; i++)
                        {
                            infoStr += imOperationParams.uid.uid[i].ToString("X").PadLeft(2, '0');
                        }
                    }
                    else
                    {
                        infoStr = res.GetString("String76");
                    }
                }
                else if (imOperationParams.opMode == hfReaderDll.HFREADER_ISO14443A_IMMODE_RB)
                {
                    if (imOperationParams.uid.len > 0)
                    {
                        infoStr = res.GetString("String77");
                        for (i = 0; i < imOperationParams.uid.len; i++)
                        {
                            infoStr += imOperationParams.uid.uid[i].ToString("X").PadLeft(2, '0');
                        }

                        if (imParams.blockNum <= imOperationParams.blockNum)
                        {
                            imOpTagOkTimes++;
                            infoStr += res.GetString("String59");
                            int j = 0;
                            string blockStr = "";
                            for (i = 0; i < imOperationParams.blockNum; i++)
                            {
                                for (j = 0; j < hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK; j++)
                                {
                                    blockStr += imOperationParams.block[i * hfReaderDll.HFREADER_ISO14443A_LEN_M0BLOCK + j].ToString("X").PadLeft(2, '0');
                                }
                                if (((i & 0x03) == 0x03))
                                {
                                    blockStr += "\r\n";
                                }
                            }
                            //textBoxImBlock.Text = blockStr;
                            AddImBlockInfo(blockStr);
                        }
                        else
                        {
                            infoStr += res.GetString("String60");
                        }
                    }
                    else
                    {
                        infoStr = res.GetString("String78");
                    }
                }
                else if (imOperationParams.opMode == hfReaderDll.HFREADER_ISO14443A_IMMODE_WB)
                {
                    if (imOperationParams.uid.len > 0)
                    {
                        infoStr = res.GetString("String79");
                        for (i = 0; i < imOperationParams.uid.len; i++)
                        {
                            infoStr += imOperationParams.uid.uid[i].ToString("X").PadLeft(2, '0');
                        }

                        if (imParams.blockNum <= imOperationParams.blockNum)
                        {
                            imOpTagOkTimes++;
                            infoStr += res.GetString("String61");
                        }
                        else
                        {
                            infoStr += res.GetString("String62");
                        }
                    }
                    else
                    {
                        infoStr = res.GetString("String80");
                    }
                }
                //DisplayOpResult(ref imParams.result);
            }
            else if (rlt == 0)
            {
                infoStr = res.GetString("String81");
                //imOpComErrTimes++;
            }
            else
            {
                infoStr = res.GetString("String82");
            }
            if (sw.ElapsedMilliseconds > imOperationParams.opTimeout * 2)
            {
                imOpComErrTimes++;
            }
            
            infoStr += res.GetString("String69") + imOpTagTimes.ToString() +
                     res.GetString("String70") + imOpTagOkTimes.ToString() +
                     res.GetString("String72") + imOpComErrTimes.ToString() +
                    res.GetString("String73") + (imOpTagOkTimes * 100.0 / imOpTagTimes).ToString("F2") + "%";
            infoStr += res.GetString("String74") + sw.ElapsedMilliseconds.ToString("D") + "ms\r\n";
            AddImInfo(infoStr);
            if (imOpTagMode == 2)
            {
                if (testInfoWriter != null)
                {
                    SaveTestInfo(infoStr);
                }
            }
            String text = this.textBoxInf.Text;

            String s = res.GetString("String83");
            if (rlt > 0)
            {
                for (i = 0; i < rlt; i++)
                {
                    s += rcvBuffer[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }

            s += "\r\n\r\n";
            AddDisplayInfo(s + text);

            text = this.textBoxInf.Text;
            int len = sendBuffer[9] + sendBuffer[10] * 256 + 13;
            s = res.GetString("String84");
            {
                for (i = 0; i < len; i++)
                {
                    s += sendBuffer[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        private void ISO14443A_Load(object sender, EventArgs e)
        {
        }

        

        
    }
}