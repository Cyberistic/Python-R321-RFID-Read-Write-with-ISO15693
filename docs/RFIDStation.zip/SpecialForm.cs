﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RFIDStation
{
    public partial class SpecialForm : Form
    {
        public int serialDevice;                   //串口设备
        public bool bOperatingSerial;
        public delegate void Delegate(object obj);
        public RFIDStation fatherForm;

        public SpecialForm()
        {
            InitializeComponent();
            comboBoxAutoInventory.SelectedIndex = 0;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxInf.Invoke(d, obj);

            }
            else
            {
                this.textBoxInf.Text = obj.ToString();
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            if (pSendBuf[2] == 0)
            {
                len = 13 + pSendBuf[9] + pSendBuf[10] * 256;
            }
            String s = cmdNmae;
            for (i = 0; i < len; i++)
            {
                s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                s += " ";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxInf.Text = "<操作成功>\r\n\r\n" + this.textBoxInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxInf.Text = "<操作失败：参数错误或设备不支持该命令>\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxInf.Text = "<操作失败：标签无响应>\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxInf.Text = "<操作失败：标签响应帧校验错误>\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxInf.Text = "<操作失败：标签错误>\r\n\r\n" + this.textBoxInf.Text;
                }
                else
                {
                    this.textBoxInf.Text = "<操作失败>\r\n\r\n" + this.textBoxInf.Text;
                }
            }
        }

        //显示返回信息
        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;
            if (pRcvBuf[2] == 0)
            {
                len = 14 + pRcvBuf[10] + pRcvBuf[11] * 256;
            }
            String s = cmdNmae;
            if (pRcvBuf[0] == 0x7E && pRcvBuf[1] == 0x55)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n<通信失败>\r\n";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        private void buttonDirectStop_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("请先打开串口");
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!fatherForm.GetDeviceAddr(addrArray))
            {
                return;
            }

            bOperatingSerial = true;
            int rlt = hfReaderDll.hfReaderSetIm(serialDevice, addrArray[0], addrArray[1], Convert.ToByte(textBoxDirOpOverAntIdleNum.Text), (UInt16)(Convert.ToUInt16(textBoxDirOpOverTimeout.Text) / 5), sendBuffer, rcvBuffer);
            bOperatingSerial = false;

            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, "设置结束条件返回<<");
            DisplaySendInf(sendBuffer, "设置结束条件>>");
        }

        private void buttonClearInfo_Click(object sender, EventArgs e)
        {
            AddDisplayInfo("");
        }

        private void buttonAutoInventory_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("请先打开串口");
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            HFREADER_CONFIG pReaderConfig = new HFREADER_CONFIG();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!fatherForm.GetDeviceAddr(addrArray))
            {
                return;
            }
            bOperatingSerial = true;
            int rlt = hfReaderDll.hfReaderGetConfig(serialDevice, addrArray[0], addrArray[1], ref pReaderConfig, sendBuffer, rcvBuffer);
            DisplayOpResult(pReaderConfig.result);
            DisplayRcvInf(rcvBuffer, "获取读写器配置参数返回<<");
            DisplaySendInf(sendBuffer, "获取读写器配置参数>>");

            if (pReaderConfig.result.flag == 0)
            {
                if (comboBoxAutoInventory.SelectedIndex == 0)
                {
                    pReaderConfig.cmdMode = hfReaderDll.HFREADER_CFG_INVENTORY_AUTO;
                }
                else
                {
                    pReaderConfig.cmdMode = hfReaderDll.HFREADER_CFG_INVENTORY_TRIGGER;
                }
                rlt = hfReaderDll.hfReaderSetConfig(serialDevice, addrArray[0], addrArray[1], ref pReaderConfig, sendBuffer, rcvBuffer);
                DisplayOpResult(pReaderConfig.result);
                DisplayRcvInf(rcvBuffer, "设置读写器配置参数返回<<");
                DisplaySendInf(sendBuffer, "设置读写器配置参数>>");
            }
            bOperatingSerial = false;
        }

        private void buttonNoiseThr_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("请先打开串口");
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            Byte[] paramsBuf = new Byte[1024];
            HFREADER_OPRESULT result = new HFREADER_OPRESULT();
            result.flag = 1;

            if (!fatherForm.GetDeviceAddr(addrArray))
            {
                return;
            }
            int noiseThr = Convert.ToInt32(textBoxNoiseThr.Text);
            paramsBuf[0] = (Byte)((noiseThr >> 0) & 0xFF);
            paramsBuf[1] = (Byte)((noiseThr >> 8) & 0xFF);
            int txLen = hfReaderDll.hfReaderFormatFrame(addrArray[0], addrArray[1], 0x09, 0, 0, paramsBuf, 2, sendBuffer);
            int rlt = hfReaderDll.hfReaderTransFrame(serialDevice, sendBuffer, (uint)txLen);
            if (rlt > 0)
            {
                rlt = hfReaderDll.hfReaderReceiveFrame(serialDevice, rcvBuffer, 500);
                if (rlt > 0)
                {
                    result.flag = 0;
                }
            }

            DisplayOpResult(result);
            DisplayRcvInf(rcvBuffer, "设置天线噪声阈值返回<<");
            DisplaySendInf(sendBuffer, "设置天线噪声阈值>>");
        }
    }
}
