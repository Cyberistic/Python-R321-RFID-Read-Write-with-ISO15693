using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace RFIDStation
{
    public partial class NfcTools : Form
    {
        public delegate void Delegate(object obj);
        private int serialDevice;                   //�����豸
        public static Thread scanThread = null;
        public int nfcOpTagMode = 0;

        public NfcTools()
        {
            InitializeComponent();
            serialDevice = -1;
        }

        public void EnableNfc(int h)
        {
            serialDevice = h;

            this.tabControlNfcTools.Enabled = true;
        }

        public void DisableNfc()
        {
            this.tabControlNfcTools.Enabled = false;
            serialDevice = -1;

            if (scanThread != null)
            {
                scanThread.Abort();
            }
            Thread.Sleep(1000);
            nfcOpTagMode = 0;
        }

        private void nfcGetTagType()
        {
            Byte[] uid = new Byte[hfReaderDll.HFREADER_NFC_UID_LEN];
            Byte[] uidLen = new Byte[1];
            Byte[] info = new Byte[hfReaderDll.HFREADER_NFC_INFO_LEN];
            Byte[] type = new Byte[1];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            int rlt = hfReaderDll.nfcGetTagType(serialDevice, 0, 1, type, uidLen, uid, info, sendBuffer, rcvBuffer);
            if (rlt > 0)
            {
                if (type[0] > 0)
                {
                    string tagInfo = "";
                    string tagUid = "";
                    if (type[0] == 1) //type1
                    {
                        tagInfo += "NfcT1 ";
                        if (info[0] == 0x11)
                        {
                            tagInfo += "Topaz 96Bytes";
                        }
                        else if (info[0] == 0x12)
                        {
                            tagInfo += "Topaz 512Bytes";
                        }
                    }
                    else if (type[0] == 2) //type2
                    {
                        tagInfo += "NfcT2 ";
                        if (info[0] == 0x08)
                        {
                            tagInfo += "Mifare Ultralight";
                        }
                        else if (info[0] == 0x09)
                        {
                            tagInfo += "Mifare UltralightC";
                        }
                        else if (info[0] == 0x0A)
                        {
                            tagInfo += "Mifare NTag203";
                        }
                        else if (info[0] == 0x0B)
                        {
                            tagInfo += "Mifare NTag210";
                        }
                        else if (info[0] == 0x0E)
                        {
                            tagInfo += "Mifare NTag212";
                        }
                        else if (info[0] == 0x0F)
                        {
                            tagInfo += "Mifare NTag213";
                        }
                        else if (info[0] == 0x11)
                        {
                            tagInfo += "Mifare NTag215";
                        }
                        else if (info[0] == 0x13)
                        {
                            tagInfo += "Mifare NTag216";
                        }
                    }
                    else if (type[0] == 3) //type3
                    {
                        tagInfo += "NfcT3 Felica";
                    }
                    else if (type[0] == 0x4A) //type4
                    {
                        tagInfo += "NfcT4A ";
                        if (info[0] == 0x01)
                        {
                            tagInfo += "Mifare Classic Mini";
                        }
                        else if (info[0] == 0x02)
                        {
                            tagInfo += "Mifare Classic S50";
                        }
                        else if (info[0] == 0x03)
                        {
                            tagInfo += "Mifare Classic S70";
                        }
                        else if (info[0] == 0x04)
                        {
                            tagInfo += "IsoDep Mifare Plus ";
                            tagInfo += String.Format("{2} Sl{0} {1}K", info[1].ToString(), info[2].ToString(), info[3] == 1 ? "S" : "X");
                        }
                        else if (info[0] == 0x05)
                        {
                            tagInfo += "IsoDep Mifare DesFire ";
                            tagInfo += String.Format("{0}K{1}", (info[1] & 0x0F).ToString(), (info[1] & 0xF0) == 0x10 ? " Evi" : "");
                        }
                        else if (info[0] == 0x06)
                        {
                            tagInfo += "IsoDep";
                        }
                    }
                    else if (type[0] == 0x4B) //type4
                    {
                        tagInfo += "NfcT4B IsoDep";
                    }
                    else if (type[0] == 0x05) //type4
                    {
                        tagInfo += "NfcT5";
                    }


                    for (int i = 0; i < uidLen[0]; i++ )
                    {
                        tagUid += uid[i].ToString("X").PadLeft(2, '0');
                    }

                    AddUidInfo(tagUid);
                    AddTagInfo(tagInfo);
                }
                else
                {
                    AddUidInfo("");
                    AddTagInfo("No Rsp");
                }

                
            }
            else
            {
                AddUidInfo("");
                AddTagInfo("No Rsp");
            }
        }

        private void AddTagInfo(object obj)
        {
            if (this.textBoxTag.InvokeRequired)
            {
                Delegate d = new Delegate(AddTagInfo);
                this.textBoxTag.Invoke(d, obj);

            }
            else
            {
                this.textBoxTag.Text = obj.ToString();
            }
        }

        private void AddUidInfo(object obj)
        {
            if (this.textBoxTagUid.InvokeRequired)
            {
                Delegate d = new Delegate(AddUidInfo);
                this.textBoxTagUid.Invoke(d, obj);

            }
            else
            {
                this.textBoxTagUid.Text = obj.ToString();
            }
        }

        private void scan()
        {
            while (nfcOpTagMode == 2)
            {
                nfcGetTagType();
                System.Threading.Thread.Sleep(100);
            }
        }

        private void buttonGetTagType_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }
            if (nfcOpTagMode > 0)
            {
                if (nfcOpTagMode == 2)
                {
                    if (scanThread != null)
                    {
                        scanThread.Abort();
                    }
                    Thread.Sleep(1000);
                }
                nfcOpTagMode = 0;
                this.buttonGetTagType.Text = "Ѱ��";

                checkBoxNfcContinue.Enabled = true;

                
            }
            else
            {

                this.buttonGetTagType.Text = "ֹͣ";
                checkBoxNfcContinue.Enabled = false;

                nfcOpTagMode = 1;
                if (checkBoxNfcContinue.Checked)
                {
                    nfcOpTagMode = 2;

                    scanThread = new Thread(new ThreadStart(scan));
                    scanThread.IsBackground = true;
                    scanThread.Start();

                }
                else
                {
                    nfcGetTagType();

                    checkBoxNfcContinue.Enabled = true;
                    this.buttonGetTagType.Text = "Ѱ��";
                    nfcOpTagMode = 0;
                }
            }

            
        }

        private void NfcTools_FormClosing(object sender, FormClosingEventArgs e)
        {
            DisableNfc();
        }
    }
}