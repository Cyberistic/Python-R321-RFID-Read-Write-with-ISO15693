﻿namespace RFIDStation
{
    partial class SpecialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonClearInfo = new System.Windows.Forms.Button();
            this.textBoxInf = new System.Windows.Forms.TextBox();
            this.tabControlSpecial = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label69 = new System.Windows.Forms.Label();
            this.textBoxDirOpOverTimeout = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDirectStop = new System.Windows.Forms.Button();
            this.textBoxDirOpOverAntIdleNum = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxAutoInventory = new System.Windows.Forms.ComboBox();
            this.buttonAutoInventory = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNoiseThr = new System.Windows.Forms.TextBox();
            this.buttonNoiseThr = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.tabControlSpecial.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonClearInfo);
            this.groupBox2.Controls.Add(this.textBoxInf);
            this.groupBox2.Location = new System.Drawing.Point(2, 281);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(464, 252);
            this.groupBox2.TabIndex = 1034;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "输出";
            // 
            // buttonClearInfo
            // 
            this.buttonClearInfo.Location = new System.Drawing.Point(385, 10);
            this.buttonClearInfo.Name = "buttonClearInfo";
            this.buttonClearInfo.Size = new System.Drawing.Size(75, 23);
            this.buttonClearInfo.TabIndex = 9;
            this.buttonClearInfo.Text = "清空";
            this.buttonClearInfo.UseVisualStyleBackColor = true;
            this.buttonClearInfo.Click += new System.EventHandler(this.buttonClearInfo_Click);
            // 
            // textBoxInf
            // 
            this.textBoxInf.Location = new System.Drawing.Point(4, 35);
            this.textBoxInf.Multiline = true;
            this.textBoxInf.Name = "textBoxInf";
            this.textBoxInf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxInf.Size = new System.Drawing.Size(456, 211);
            this.textBoxInf.TabIndex = 7;
            // 
            // tabControlSpecial
            // 
            this.tabControlSpecial.Controls.Add(this.tabPage1);
            this.tabControlSpecial.Location = new System.Drawing.Point(2, 12);
            this.tabControlSpecial.Name = "tabControlSpecial";
            this.tabControlSpecial.SelectedIndex = 0;
            this.tabControlSpecial.Size = new System.Drawing.Size(464, 263);
            this.tabControlSpecial.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonNoiseThr);
            this.tabPage1.Controls.Add(this.textBoxNoiseThr);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.buttonAutoInventory);
            this.tabPage1.Controls.Add(this.comboBoxAutoInventory);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label49);
            this.tabPage1.Controls.Add(this.textBoxDirOpOverAntIdleNum);
            this.tabPage1.Controls.Add(this.buttonDirectStop);
            this.tabPage1.Controls.Add(this.label69);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBoxDirOpOverTimeout);
            this.tabPage1.Controls.Add(this.label62);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(456, 237);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "读写器控制";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(349, 10);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(29, 12);
            this.label69.TabIndex = 1030;
            this.label69.Text = "(ms)";
            // 
            // textBoxDirOpOverTimeout
            // 
            this.textBoxDirOpOverTimeout.AcceptsTab = true;
            this.textBoxDirOpOverTimeout.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBoxDirOpOverTimeout.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDirOpOverTimeout.Location = new System.Drawing.Point(299, 6);
            this.textBoxDirOpOverTimeout.MaxLength = 32;
            this.textBoxDirOpOverTimeout.Name = "textBoxDirOpOverTimeout";
            this.textBoxDirOpOverTimeout.Size = new System.Drawing.Size(48, 21);
            this.textBoxDirOpOverTimeout.TabIndex = 1028;
            this.textBoxDirOpOverTimeout.Text = "2000";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(244, 10);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(53, 12);
            this.label62.TabIndex = 1029;
            this.label62.Text = "超时时间";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(201, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1032;
            this.label1.Text = "(次)";
            // 
            // buttonDirectStop
            // 
            this.buttonDirectStop.Location = new System.Drawing.Point(388, 5);
            this.buttonDirectStop.Name = "buttonDirectStop";
            this.buttonDirectStop.Size = new System.Drawing.Size(62, 23);
            this.buttonDirectStop.TabIndex = 1031;
            this.buttonDirectStop.Text = "确定";
            this.buttonDirectStop.UseVisualStyleBackColor = true;
            this.buttonDirectStop.Click += new System.EventHandler(this.buttonDirectStop_Click);
            // 
            // textBoxDirOpOverAntIdleNum
            // 
            this.textBoxDirOpOverAntIdleNum.AcceptsTab = true;
            this.textBoxDirOpOverAntIdleNum.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBoxDirOpOverAntIdleNum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDirOpOverAntIdleNum.Location = new System.Drawing.Point(151, 6);
            this.textBoxDirOpOverAntIdleNum.MaxLength = 2;
            this.textBoxDirOpOverAntIdleNum.Name = "textBoxDirOpOverAntIdleNum";
            this.textBoxDirOpOverAntIdleNum.Size = new System.Drawing.Size(48, 21);
            this.textBoxDirOpOverAntIdleNum.TabIndex = 1027;
            this.textBoxDirOpOverAntIdleNum.Text = "5";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(97, 10);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(53, 12);
            this.label49.TabIndex = 1026;
            this.label49.Text = "盘点空闲";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 1033;
            this.label2.Text = "智能结束条件：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 1034;
            this.label3.Text = "自动盘点标签：";
            // 
            // comboBoxAutoInventory
            // 
            this.comboBoxAutoInventory.FormattingEnabled = true;
            this.comboBoxAutoInventory.Items.AddRange(new object[] {
            "使能",
            "禁止"});
            this.comboBoxAutoInventory.Location = new System.Drawing.Point(97, 31);
            this.comboBoxAutoInventory.Name = "comboBoxAutoInventory";
            this.comboBoxAutoInventory.Size = new System.Drawing.Size(282, 20);
            this.comboBoxAutoInventory.TabIndex = 1035;
            // 
            // buttonAutoInventory
            // 
            this.buttonAutoInventory.Location = new System.Drawing.Point(388, 30);
            this.buttonAutoInventory.Name = "buttonAutoInventory";
            this.buttonAutoInventory.Size = new System.Drawing.Size(62, 23);
            this.buttonAutoInventory.TabIndex = 1036;
            this.buttonAutoInventory.Text = "确定";
            this.buttonAutoInventory.UseVisualStyleBackColor = true;
            this.buttonAutoInventory.Click += new System.EventHandler(this.buttonAutoInventory_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 1037;
            this.label4.Text = "天线噪声阈值：";
            // 
            // textBoxNoiseThr
            // 
            this.textBoxNoiseThr.AcceptsTab = true;
            this.textBoxNoiseThr.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBoxNoiseThr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxNoiseThr.Location = new System.Drawing.Point(97, 57);
            this.textBoxNoiseThr.MaxLength = 2;
            this.textBoxNoiseThr.Name = "textBoxNoiseThr";
            this.textBoxNoiseThr.Size = new System.Drawing.Size(281, 21);
            this.textBoxNoiseThr.TabIndex = 1038;
            this.textBoxNoiseThr.Text = "0";
            // 
            // buttonNoiseThr
            // 
            this.buttonNoiseThr.Location = new System.Drawing.Point(388, 55);
            this.buttonNoiseThr.Name = "buttonNoiseThr";
            this.buttonNoiseThr.Size = new System.Drawing.Size(62, 23);
            this.buttonNoiseThr.TabIndex = 1039;
            this.buttonNoiseThr.Text = "确定";
            this.buttonNoiseThr.UseVisualStyleBackColor = true;
            this.buttonNoiseThr.Click += new System.EventHandler(this.buttonNoiseThr_Click);
            // 
            // SpecialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 536);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.tabControlSpecial);
            this.MaximizeBox = false;
            this.Name = "SpecialForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "特殊功能";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControlSpecial.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonClearInfo;
        private System.Windows.Forms.TextBox textBoxInf;
        private System.Windows.Forms.TabControl tabControlSpecial;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBoxDirOpOverAntIdleNum;
        private System.Windows.Forms.Button buttonDirectStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBoxDirOpOverTimeout;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxAutoInventory;
        private System.Windows.Forms.Button buttonAutoInventory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNoiseThr;
        private System.Windows.Forms.Button buttonNoiseThr;
    }
}