namespace RFIDStation
{
    partial class ISO14443B
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBoxSelectedISO14443BPupi = new System.Windows.Forms.TextBox();
            this.buttonReadISO14443BTags = new System.Windows.Forms.Button();
            this.tabControlISO14443BTagOp = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonISO14443BGetIDCardUid = new System.Windows.Forms.Button();
            this.textBoxISO14443BIDCardUid = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.textBoxDtuRxLen = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxDtuTime = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.buttonDtuRxClear = new System.Windows.Forms.Button();
            this.buttonDtuTxClear = new System.Windows.Forms.Button();
            this.textBoxDtuRx = new System.Windows.Forms.TextBox();
            this.textBoxDtuTx = new System.Windows.Forms.TextBox();
            this.buttonDtu = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonClearISO14443BInfo = new System.Windows.Forms.Button();
            this.textBoxISO14443BInf = new System.Windows.Forms.TextBox();
            this.groupBox13.SuspendLayout();
            this.tabControlISO14443BTagOp.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.textBoxSelectedISO14443BPupi);
            this.groupBox13.Controls.Add(this.buttonReadISO14443BTags);
            this.groupBox13.Location = new System.Drawing.Point(5, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(495, 40);
            this.groupBox13.TabIndex = 127;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "��ǩ��Ϣ";
            // 
            // textBoxSelectedISO14443BPupi
            // 
            this.textBoxSelectedISO14443BPupi.Location = new System.Drawing.Point(5, 14);
            this.textBoxSelectedISO14443BPupi.MaxLength = 8;
            this.textBoxSelectedISO14443BPupi.Name = "textBoxSelectedISO14443BPupi";
            this.textBoxSelectedISO14443BPupi.Size = new System.Drawing.Size(362, 21);
            this.textBoxSelectedISO14443BPupi.TabIndex = 1000;
            this.textBoxSelectedISO14443BPupi.Text = "00000000 00000000 00000000";
            // 
            // buttonReadISO14443BTags
            // 
            this.buttonReadISO14443BTags.Font = new System.Drawing.Font("����", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonReadISO14443BTags.Location = new System.Drawing.Point(373, 14);
            this.buttonReadISO14443BTags.Name = "buttonReadISO14443BTags";
            this.buttonReadISO14443BTags.Size = new System.Drawing.Size(116, 23);
            this.buttonReadISO14443BTags.TabIndex = 2;
            this.buttonReadISO14443BTags.Text = "��ȡ";
            this.buttonReadISO14443BTags.UseVisualStyleBackColor = true;
            this.buttonReadISO14443BTags.Click += new System.EventHandler(this.buttonReadISO14443BTags_Click);
            // 
            // tabControlISO14443BTagOp
            // 
            this.tabControlISO14443BTagOp.Controls.Add(this.tabPage2);
            this.tabControlISO14443BTagOp.Controls.Add(this.tabPage8);
            this.tabControlISO14443BTagOp.Location = new System.Drawing.Point(5, 46);
            this.tabControlISO14443BTagOp.Name = "tabControlISO14443BTagOp";
            this.tabControlISO14443BTagOp.SelectedIndex = 0;
            this.tabControlISO14443BTagOp.Size = new System.Drawing.Size(499, 257);
            this.tabControlISO14443BTagOp.TabIndex = 128;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonISO14443BGetIDCardUid);
            this.tabPage2.Controls.Add(this.textBoxISO14443BIDCardUid);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(491, 231);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "����֤";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonISO14443BGetIDCardUid
            // 
            this.buttonISO14443BGetIDCardUid.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.buttonISO14443BGetIDCardUid.Font = new System.Drawing.Font("����", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonISO14443BGetIDCardUid.Location = new System.Drawing.Point(13, 12);
            this.buttonISO14443BGetIDCardUid.Name = "buttonISO14443BGetIDCardUid";
            this.buttonISO14443BGetIDCardUid.Size = new System.Drawing.Size(131, 23);
            this.buttonISO14443BGetIDCardUid.TabIndex = 1024;
            this.buttonISO14443BGetIDCardUid.Text = "��ȡUID";
            this.buttonISO14443BGetIDCardUid.UseVisualStyleBackColor = true;
            this.buttonISO14443BGetIDCardUid.Click += new System.EventHandler(this.buttonISO14443BGetIDCardUid_Click);
            // 
            // textBoxISO14443BIDCardUid
            // 
            this.textBoxISO14443BIDCardUid.Location = new System.Drawing.Point(150, 15);
            this.textBoxISO14443BIDCardUid.MaxLength = 16;
            this.textBoxISO14443BIDCardUid.Name = "textBoxISO14443BIDCardUid";
            this.textBoxISO14443BIDCardUid.Size = new System.Drawing.Size(332, 21);
            this.textBoxISO14443BIDCardUid.TabIndex = 1023;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.textBoxDtuRxLen);
            this.tabPage8.Controls.Add(this.label56);
            this.tabPage8.Controls.Add(this.label57);
            this.tabPage8.Controls.Add(this.textBoxDtuTime);
            this.tabPage8.Controls.Add(this.label58);
            this.tabPage8.Controls.Add(this.label59);
            this.tabPage8.Controls.Add(this.label60);
            this.tabPage8.Controls.Add(this.buttonDtuRxClear);
            this.tabPage8.Controls.Add(this.buttonDtuTxClear);
            this.tabPage8.Controls.Add(this.textBoxDtuRx);
            this.tabPage8.Controls.Add(this.textBoxDtuTx);
            this.tabPage8.Controls.Add(this.buttonDtu);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(491, 231);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "͸��";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // textBoxDtuRxLen
            // 
            this.textBoxDtuRxLen.Location = new System.Drawing.Point(353, 82);
            this.textBoxDtuRxLen.MaxLength = 2;
            this.textBoxDtuRxLen.Name = "textBoxDtuRxLen";
            this.textBoxDtuRxLen.Size = new System.Drawing.Size(88, 21);
            this.textBoxDtuRxLen.TabIndex = 1057;
            this.textBoxDtuRxLen.Text = "0C";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(258, 86);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(89, 12);
            this.label56.TabIndex = 1058;
            this.label56.Text = "��ǩ��Ӧ֡����";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(158, 89);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(65, 12);
            this.label57.TabIndex = 1056;
            this.label57.Text = "us(ʮ����)";
            // 
            // textBoxDtuTime
            // 
            this.textBoxDtuTime.Location = new System.Drawing.Point(84, 82);
            this.textBoxDtuTime.MaxLength = 16;
            this.textBoxDtuTime.Name = "textBoxDtuTime";
            this.textBoxDtuTime.Size = new System.Drawing.Size(69, 21);
            this.textBoxDtuTime.TabIndex = 1048;
            this.textBoxDtuTime.Text = "10000";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(7, 86);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(77, 12);
            this.label58.TabIndex = 1055;
            this.label58.Text = "��ǩ��ʱʱ��";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(11, 110);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(29, 12);
            this.label59.TabIndex = 1054;
            this.label59.Text = "����";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(7, 6);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(29, 12);
            this.label60.TabIndex = 1047;
            this.label60.Text = "����";
            // 
            // buttonDtuRxClear
            // 
            this.buttonDtuRxClear.Location = new System.Drawing.Point(447, 110);
            this.buttonDtuRxClear.Name = "buttonDtuRxClear";
            this.buttonDtuRxClear.Size = new System.Drawing.Size(39, 77);
            this.buttonDtuRxClear.TabIndex = 1053;
            this.buttonDtuRxClear.Text = "���";
            this.buttonDtuRxClear.UseVisualStyleBackColor = true;
            this.buttonDtuRxClear.Click += new System.EventHandler(this.buttonDtuRxClear_Click);
            // 
            // buttonDtuTxClear
            // 
            this.buttonDtuTxClear.Location = new System.Drawing.Point(447, 6);
            this.buttonDtuTxClear.Name = "buttonDtuTxClear";
            this.buttonDtuTxClear.Size = new System.Drawing.Size(39, 70);
            this.buttonDtuTxClear.TabIndex = 1052;
            this.buttonDtuTxClear.Text = "���";
            this.buttonDtuTxClear.UseVisualStyleBackColor = true;
            this.buttonDtuTxClear.Click += new System.EventHandler(this.buttonDtuTxClear_Click);
            // 
            // textBoxDtuRx
            // 
            this.textBoxDtuRx.Location = new System.Drawing.Point(40, 110);
            this.textBoxDtuRx.MaxLength = 1000;
            this.textBoxDtuRx.Multiline = true;
            this.textBoxDtuRx.Name = "textBoxDtuRx";
            this.textBoxDtuRx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDtuRx.Size = new System.Drawing.Size(401, 77);
            this.textBoxDtuRx.TabIndex = 1051;
            // 
            // textBoxDtuTx
            // 
            this.textBoxDtuTx.Location = new System.Drawing.Point(40, 6);
            this.textBoxDtuTx.MaxLength = 400;
            this.textBoxDtuTx.Multiline = true;
            this.textBoxDtuTx.Name = "textBoxDtuTx";
            this.textBoxDtuTx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDtuTx.Size = new System.Drawing.Size(401, 70);
            this.textBoxDtuTx.TabIndex = 1050;
            this.textBoxDtuTx.Text = "0600";
            // 
            // buttonDtu
            // 
            this.buttonDtu.Location = new System.Drawing.Point(7, 189);
            this.buttonDtu.Name = "buttonDtu";
            this.buttonDtu.Size = new System.Drawing.Size(478, 40);
            this.buttonDtu.TabIndex = 1049;
            this.buttonDtu.Text = "͸��";
            this.buttonDtu.UseVisualStyleBackColor = true;
            this.buttonDtu.Click += new System.EventHandler(this.buttonDtu_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonClearISO14443BInfo);
            this.groupBox2.Controls.Add(this.textBoxISO14443BInf);
            this.groupBox2.Location = new System.Drawing.Point(0, 309);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(499, 264);
            this.groupBox2.TabIndex = 129;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "���";
            // 
            // buttonClearISO14443BInfo
            // 
            this.buttonClearISO14443BInfo.Location = new System.Drawing.Point(418, 9);
            this.buttonClearISO14443BInfo.Name = "buttonClearISO14443BInfo";
            this.buttonClearISO14443BInfo.Size = new System.Drawing.Size(75, 23);
            this.buttonClearISO14443BInfo.TabIndex = 9;
            this.buttonClearISO14443BInfo.Text = "���";
            this.buttonClearISO14443BInfo.UseVisualStyleBackColor = true;
            this.buttonClearISO14443BInfo.Click += new System.EventHandler(this.buttonClearISO14443BInfo_Click);
            // 
            // textBoxISO14443BInf
            // 
            this.textBoxISO14443BInf.Location = new System.Drawing.Point(4, 33);
            this.textBoxISO14443BInf.Multiline = true;
            this.textBoxISO14443BInf.Name = "textBoxISO14443BInf";
            this.textBoxISO14443BInf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxISO14443BInf.Size = new System.Drawing.Size(489, 225);
            this.textBoxISO14443BInf.TabIndex = 7;
            // 
            // ISO14443B
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 573);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.tabControlISO14443BTagOp);
            this.Controls.Add(this.groupBox13);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ISO14443B";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ISO14443B";
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabControlISO14443BTagOp.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBoxSelectedISO14443BPupi;
        private System.Windows.Forms.TabControl tabControlISO14443BTagOp;
        private System.Windows.Forms.Button buttonReadISO14443BTags;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox textBoxDtuRxLen;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxDtuTime;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Button buttonDtuRxClear;
        private System.Windows.Forms.Button buttonDtuTxClear;
        private System.Windows.Forms.TextBox textBoxDtuRx;
        private System.Windows.Forms.TextBox textBoxDtuTx;
        private System.Windows.Forms.Button buttonDtu;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonClearISO14443BInfo;
        private System.Windows.Forms.TextBox textBoxISO14443BInf;
        private System.Windows.Forms.Button buttonISO14443BGetIDCardUid;
        private System.Windows.Forms.TextBox textBoxISO14443BIDCardUid;
    }
}