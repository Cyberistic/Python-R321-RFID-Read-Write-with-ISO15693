using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RFIDStation
{
    public partial class ISO14443B : Form
    {
        public RFIDStation fatherForm;
        private int serialDevice;                   //�����豸
        public bool bOperatingSerial;
        public delegate void Delegate(object obj);

        public ISO14443B()
        {
            InitializeComponent();

            serialDevice = -1;
            bOperatingSerial = false;
        }

       
        public void EnableIso14443b(int h)
        {
            serialDevice = h;

            this.tabControlISO14443BTagOp.Enabled = true;
            this.buttonReadISO14443BTags.Enabled = true;
        }

        public void DisableIso14443b()
        {
            this.tabControlISO14443BTagOp.Enabled = false;
            this.buttonReadISO14443BTags.Enabled = false;
            serialDevice = -1;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxISO14443BInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxISO14443BInf.Invoke(d, obj);

            }
            else
            {
                this.textBoxISO14443BInf.Text = obj.ToString();
            }
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxISO14443BInf.Text = "<�����ɹ�>\r\n\r\n" + this.textBoxISO14443BInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxISO14443BInf.Text = "<����ʧ�ܣ�����������豸��֧�ָ�����>\r\n\r\n" + this.textBoxISO14443BInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxISO14443BInf.Text = "<����ʧ�ܣ���ǩ����Ӧ>\r\n\r\n" + this.textBoxISO14443BInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxISO14443BInf.Text = "<����ʧ�ܣ���ǩ��Ӧ֡У�����>\r\n\r\n" + this.textBoxISO14443BInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxISO14443BInf.Text = "<����ʧ�ܣ���ǩ����>\r\n\r\n" + this.textBoxISO14443BInf.Text;
                }
                else
                {
                    this.textBoxISO14443BInf.Text = "<����ʧ��>\r\n\r\n" + this.textBoxISO14443BInf.Text;
                }
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxISO14443BInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            String s = cmdNmae;

            {
                for (i = 0; i < len; i++)
                {
                    s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxISO14443BInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;
            String s = cmdNmae;
            if (pRcvBuf[2] > 0)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n<ͨ��ʧ��>\r\n";
            }
            s += "\r\n";
            AddDisplayInfo(s + text);
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show("���ݳ��ȴ���");
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }


        private bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            b = fatherForm.GetDeviceAddr(addArray);
            return b;
        }

        private void buttonReadISO14443BTags_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte mode = 0;

            ISO14443B_INFO pInfo = new ISO14443B_INFO();
            pInfo.pupi = new Byte[hfReaderDll.HFREADER_ISO14443B_MAX_PUPI_SIZE];
            pInfo.appField = new Byte[hfReaderDll.HFREADER_ISO14443B_MAX_APPLI_SIZE];
            pInfo.protocol = new Byte[hfReaderDll.HFREADER_ISO14443B_MAX_PROTOCOL_SIZE];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            mode = hfReaderDll.HFREADER_READ_UID_NORMAL;

            textBoxSelectedISO14443BPupi.Text = "";

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443BSelect(serialDevice, addrArray[0], addrArray[1], mode, ref pInfo, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                DisplayOpResult(pInfo.result);
                if (pInfo.result.flag == 0)
                {
                    int i = 0;
                    String s;
                    s = "";
                    for (i = 0; i < hfReaderDll.HFREADER_ISO14443B_MAX_PUPI_SIZE; i++)
                    {
                        s += pInfo.pupi[i].ToString("X").PadLeft(2, '0');
                    }
                    s += " ";

                    for (i = 0; i < hfReaderDll.HFREADER_ISO14443B_MAX_APPLI_SIZE; i++)
                    {
                        s += pInfo.appField[i].ToString("X").PadLeft(2, '0');
                    }
                    s += " ";

                    for (i = 0; i < hfReaderDll.HFREADER_ISO14443B_MAX_PROTOCOL_SIZE; i++)
                    {
                        s += pInfo.protocol[i].ToString("X").PadLeft(2, '0');
                    }
                    s += " ";

                    textBoxSelectedISO14443BPupi.Text = s;
                }

            }
            DisplayRcvInf(rcvBuffer, "ѡ���ڱ�ǩ����<<");
            DisplaySendInf(sendBuffer, "ѡ���ڱ�ǩ>>");
        }

        private void buttonClearISO14443BInfo_Click(object sender, EventArgs e)
        {
            this.textBoxISO14443BInf.Clear();
        }

        private void buttonISO14443BGetIDCardUid_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }
            ushort[] addrArray = new ushort[2];

            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] uid = new Byte[hfReaderDll.HFREADER_ISO14443B_SIZE_IDCARD_UID];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }


            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443BGetIDCardUid(serialDevice, addrArray[0], addrArray[1], uid, ref pResult, sendBuffer, rcvBuffer);
            bOperatingSerial = false;
            if (rlt > 0)
            {
                if (pResult.flag == 0)
                {
                    int i = 0;
                    String s;
                    s = "";
                    for (i = 0; i < hfReaderDll.HFREADER_ISO14443B_SIZE_IDCARD_UID; i++)
                    {
                        s += uid[i].ToString("X").PadLeft(2, '0');
                    }

                    this.textBoxISO14443BIDCardUid.Text = s;
                }
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, "��ȡ����֤UID����<<");
            DisplaySendInf(sendBuffer, "��ȡ����֤UID>>");
        }

        private void buttonDtuTxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuTx.Text = "";
        }

        private void buttonDtuRxClear_Click(object sender, EventArgs e)
        {
            this.textBoxDtuRx.Text = "";
        }

        private void buttonDtu_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show("���ȴ򿪴���");
                return;
            }

            ushort[] addrArray = new ushort[2];
            Byte[] rxLen = new Byte[1];

            ISO14443B_DTU pDtu = new ISO14443B_DTU();
            pDtu.txFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];
            pDtu.rxFrame = new Byte[hfReaderDll.HFREADER_LONG_BUFFER_MAX];

            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (GetHexInput(this.textBoxDtuRxLen.Text, rxLen, 1) <= 0)
            {
                return;
            }
            pDtu.rxLen = rxLen[0];

            pDtu.txLen = (uint)(GetHexInput(this.textBoxDtuTx.Text, pDtu.txFrame));

            pDtu.timeout = Convert.ToUInt32(this.textBoxDtuTime.Text, 10);

            while (bOperatingSerial) ;
            bOperatingSerial = true;
            int rlt = hfReaderDll.iso14443BDtu(serialDevice, addrArray[0], addrArray[1], ref pDtu, sendBuffer, rcvBuffer);
            bOperatingSerial = false;

            if (rlt > 0)
            {
                if (pDtu.result.flag == 0)
                {
                    string s = "";
                    for (uint i = 0; i < pDtu.rxLen; i++)
                    {
                        s += pDtu.rxFrame[i].ToString("X").PadLeft(2, '0');
                    }
                    this.textBoxDtuRx.Text = s;
                    this.textBoxDtuRxLen.Text = pDtu.rxLen.ToString("X").PadLeft(2, '0');
                }
                DisplayOpResult(pDtu.result);
            }
            DisplayRcvInf(rcvBuffer, "͸������<<");
            DisplaySendInf(sendBuffer, "͸��>>");
        }
    }
}