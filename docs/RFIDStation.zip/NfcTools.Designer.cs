namespace RFIDStation
{
    partial class NfcTools
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlNfcTools = new System.Windows.Forms.TabControl();
            this.tabPageDataInfo = new System.Windows.Forms.TabPage();
            this.tabPageWriteNfcInfo = new System.Windows.Forms.TabPage();
            this.buttonGetTagType = new System.Windows.Forms.Button();
            this.textBoxTag = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxTagUid = new System.Windows.Forms.TextBox();
            this.checkBoxNfcContinue = new System.Windows.Forms.CheckBox();
            this.tabControlNfcTools.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlNfcTools
            // 
            this.tabControlNfcTools.Controls.Add(this.tabPageDataInfo);
            this.tabControlNfcTools.Controls.Add(this.tabPageWriteNfcInfo);
            this.tabControlNfcTools.Location = new System.Drawing.Point(1, 55);
            this.tabControlNfcTools.Name = "tabControlNfcTools";
            this.tabControlNfcTools.SelectedIndex = 0;
            this.tabControlNfcTools.Size = new System.Drawing.Size(429, 410);
            this.tabControlNfcTools.TabIndex = 0;
            // 
            // tabPageDataInfo
            // 
            this.tabPageDataInfo.Location = new System.Drawing.Point(4, 22);
            this.tabPageDataInfo.Name = "tabPageDataInfo";
            this.tabPageDataInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDataInfo.Size = new System.Drawing.Size(421, 384);
            this.tabPageDataInfo.TabIndex = 1;
            this.tabPageDataInfo.Text = "Memory";
            this.tabPageDataInfo.UseVisualStyleBackColor = true;
            // 
            // tabPageWriteNfcInfo
            // 
            this.tabPageWriteNfcInfo.Location = new System.Drawing.Point(4, 22);
            this.tabPageWriteNfcInfo.Name = "tabPageWriteNfcInfo";
            this.tabPageWriteNfcInfo.Size = new System.Drawing.Size(421, 384);
            this.tabPageWriteNfcInfo.TabIndex = 2;
            this.tabPageWriteNfcInfo.Text = "Record";
            this.tabPageWriteNfcInfo.UseVisualStyleBackColor = true;
            // 
            // buttonGetTagType
            // 
            this.buttonGetTagType.Location = new System.Drawing.Point(1, 28);
            this.buttonGetTagType.Name = "buttonGetTagType";
            this.buttonGetTagType.Size = new System.Drawing.Size(75, 21);
            this.buttonGetTagType.TabIndex = 1;
            this.buttonGetTagType.Text = "Ѱ��";
            this.buttonGetTagType.UseVisualStyleBackColor = true;
            this.buttonGetTagType.Click += new System.EventHandler(this.buttonGetTagType_Click);
            // 
            // textBoxTag
            // 
            this.textBoxTag.Location = new System.Drawing.Point(129, 28);
            this.textBoxTag.Name = "textBoxTag";
            this.textBoxTag.Size = new System.Drawing.Size(297, 21);
            this.textBoxTag.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "��Ϣ��";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "UID��";
            // 
            // textBoxTagUid
            // 
            this.textBoxTagUid.Location = new System.Drawing.Point(129, 4);
            this.textBoxTagUid.Name = "textBoxTagUid";
            this.textBoxTagUid.Size = new System.Drawing.Size(297, 21);
            this.textBoxTagUid.TabIndex = 5;
            // 
            // checkBoxNfcContinue
            // 
            this.checkBoxNfcContinue.AutoSize = true;
            this.checkBoxNfcContinue.Location = new System.Drawing.Point(12, 9);
            this.checkBoxNfcContinue.Name = "checkBoxNfcContinue";
            this.checkBoxNfcContinue.Size = new System.Drawing.Size(48, 16);
            this.checkBoxNfcContinue.TabIndex = 6;
            this.checkBoxNfcContinue.Text = "����";
            this.checkBoxNfcContinue.UseVisualStyleBackColor = true;
            // 
            // NfcTools
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 465);
            this.Controls.Add(this.checkBoxNfcContinue);
            this.Controls.Add(this.textBoxTagUid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxTag);
            this.Controls.Add(this.buttonGetTagType);
            this.Controls.Add(this.tabControlNfcTools);
            this.MaximizeBox = false;
            this.Name = "NfcTools";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nfc";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NfcTools_FormClosing);
            this.tabControlNfcTools.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlNfcTools;
        private System.Windows.Forms.TabPage tabPageDataInfo;
        private System.Windows.Forms.TabPage tabPageWriteNfcInfo;
        private System.Windows.Forms.Button buttonGetTagType;
        private System.Windows.Forms.TextBox textBoxTag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxTagUid;
        private System.Windows.Forms.CheckBox checkBoxNfcContinue;
    }
}