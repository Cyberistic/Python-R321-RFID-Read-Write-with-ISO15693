namespace RFIDStation
{
    partial class crcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxCrcData = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.buttonCalCrc = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.comboBoxCrcType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // textBoxCrcData
            // 
            this.textBoxCrcData.Location = new System.Drawing.Point(47, 39);
            this.textBoxCrcData.Multiline = true;
            this.textBoxCrcData.Name = "textBoxCrcData";
            this.textBoxCrcData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxCrcData.Size = new System.Drawing.Size(511, 235);
            this.textBoxCrcData.TabIndex = 16;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(5, 43);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(41, 12);
            this.label68.TabIndex = 15;
            this.label68.Text = "���ݣ�";
            // 
            // buttonCalCrc
            // 
            this.buttonCalCrc.Location = new System.Drawing.Point(464, 11);
            this.buttonCalCrc.Name = "buttonCalCrc";
            this.buttonCalCrc.Size = new System.Drawing.Size(94, 23);
            this.buttonCalCrc.TabIndex = 14;
            this.buttonCalCrc.Text = "����";
            this.buttonCalCrc.UseVisualStyleBackColor = true;
            this.buttonCalCrc.Click += new System.EventHandler(this.buttonCalCrc_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(5, 16);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(41, 12);
            this.label67.TabIndex = 13;
            this.label67.Text = "�㷨��";
            // 
            // comboBoxCrcType
            // 
            this.comboBoxCrcType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCrcType.FormattingEnabled = true;
            this.comboBoxCrcType.Items.AddRange(new object[] {
            "ISO15693",
            "ISO14443A",
            "ISO14443B"});
            this.comboBoxCrcType.Location = new System.Drawing.Point(46, 13);
            this.comboBoxCrcType.Name = "comboBoxCrcType";
            this.comboBoxCrcType.Size = new System.Drawing.Size(412, 20);
            this.comboBoxCrcType.TabIndex = 12;
            // 
            // crcForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 285);
            this.Controls.Add(this.textBoxCrcData);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.buttonCalCrc);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.comboBoxCrcType);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "crcForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Crc������";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxCrcData;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Button buttonCalCrc;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.ComboBox comboBoxCrcType;

    }
}