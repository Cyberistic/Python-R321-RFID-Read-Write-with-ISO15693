namespace RFIDStation
{
    partial class ISO15693
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ISO15693));
            this.tabControlISO15693TagOp = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBoxGetUid = new System.Windows.Forms.GroupBox();
            this.textBoxRemainTagNum = new System.Windows.Forms.TextBox();
            this.textBoxReadTagNum = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonClearListBox = new System.Windows.Forms.Button();
            this.buttonReadTags = new System.Windows.Forms.Button();
            this.listBoxUID = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonClearLockBlock = new System.Windows.Forms.Button();
            this.textBoxLBlockAddr = new System.Windows.Forms.TextBox();
            this.buttonLockBlock = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBoxWMBlockNum = new System.Windows.Forms.TextBox();
            this.textBoxWMBlockAddr = new System.Windows.Forms.TextBox();
            this.buttonClearWMBlock = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.textBoxWMBlockData = new System.Windows.Forms.TextBox();
            this.buttonWriteMBlock = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBoxBlocks = new System.Windows.Forms.GroupBox();
            this.textBoxRMBlockNum = new System.Windows.Forms.TextBox();
            this.textBoxRMBlockAddr = new System.Windows.Forms.TextBox();
            this.buttonClearRMultBlock = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxRMBlockData = new System.Windows.Forms.TextBox();
            this.buttonReadMBlock = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBoxTagInfo = new System.Windows.Forms.GroupBox();
            this.buttonClearTagInfo = new System.Windows.Forms.Button();
            this.textBoxTagInfICRef = new System.Windows.Forms.TextBox();
            this.textBoxTagInfBlockSize = new System.Windows.Forms.TextBox();
            this.textBoxTagInfBlockNum = new System.Windows.Forms.TextBox();
            this.textBoxTagInfAFI = new System.Windows.Forms.TextBox();
            this.textBoxTagInfDSFID = new System.Windows.Forms.TextBox();
            this.textBoxTagInfFlag = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.buttonReadTagInf = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxDSFIDValue = new System.Windows.Forms.TextBox();
            this.buttonCtrlDsfid = new System.Windows.Forms.Button();
            this.radioButtonWriteDSFID = new System.Windows.Forms.RadioButton();
            this.radioButtonLockDSFID = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxAFIValue = new System.Windows.Forms.TextBox();
            this.buttonCtrlAfi = new System.Windows.Forms.Button();
            this.radioButtonWriteAFI = new System.Windows.Forms.RadioButton();
            this.radioButtonLockAFI = new System.Windows.Forms.RadioButton();
            this.groupBoxTagParam = new System.Windows.Forms.GroupBox();
            this.buttonCtrlEas = new System.Windows.Forms.Button();
            this.radioButtonLockEAS = new System.Windows.Forms.RadioButton();
            this.radioButtonResetEAS = new System.Windows.Forms.RadioButton();
            this.radioButtonSetEAS = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBoxDtuRxLen = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxDtuTime = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonDtuRxClear = new System.Windows.Forms.Button();
            this.buttonDtuTxClear = new System.Windows.Forms.Button();
            this.textBoxDtuRx = new System.Windows.Forms.TextBox();
            this.textBoxDtuTx = new System.Windows.Forms.TextBox();
            this.buttonDtu = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.checkBoxWaitTime = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxDirOpBlockAddr = new System.Windows.Forms.TextBox();
            this.comboBoxOpTag = new System.Windows.Forms.ComboBox();
            this.textBoxOpTagInfo = new System.Windows.Forms.TextBox();
            this.buttonOpTagStart = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxImOpAntAddr = new System.Windows.Forms.TextBox();
            this.comboBoxImOpAnt = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.buttonImOpStart = new System.Windows.Forms.Button();
            this.textBoxImOpBlockAddr = new System.Windows.Forms.TextBox();
            this.comboBoxImOpMode = new System.Windows.Forms.ComboBox();
            this.textBoxImTagInfo = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.textBoxGateAlarmUid = new System.Windows.Forms.TextBox();
            this.buttonStartRcvGateAlarmUid = new System.Windows.Forms.Button();
            this.buttonSetGateMode = new System.Windows.Forms.Button();
            this.comboBoxEnableGateMode = new System.Windows.Forms.ComboBox();
            this.buttonSetScanAnts = new System.Windows.Forms.Button();
            this.checkBoxGateAnt8 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt7 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt6 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt5 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt4 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt3 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt2 = new System.Windows.Forms.CheckBox();
            this.checkBoxGateAnt1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonClearInfo = new System.Windows.Forms.Button();
            this.textBoxInf = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBoxDestAddr = new System.Windows.Forms.TextBox();
            this.textBoxSrcAddr = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBoxSelectedIso15693Uid = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.toolTipIso15693 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControlISO15693TagOp.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBoxGetUid.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBoxBlocks.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBoxTagInfo.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBoxTagParam.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlISO15693TagOp
            // 
            resources.ApplyResources(this.tabControlISO15693TagOp, "tabControlISO15693TagOp");
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage1);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage5);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage3);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage2);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage4);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage6);
            this.tabControlISO15693TagOp.Controls.Add(this.tabPage7);
            this.tabControlISO15693TagOp.Name = "tabControlISO15693TagOp";
            this.tabControlISO15693TagOp.SelectedIndex = 0;
            this.tabControlISO15693TagOp.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.toolTipIso15693.SetToolTip(this.tabControlISO15693TagOp, resources.GetString("tabControlISO15693TagOp.ToolTip"));
            this.tabControlISO15693TagOp.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControlISO15693TagOp_Selecting);
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Controls.Add(this.groupBoxGetUid);
            this.tabPage1.Name = "tabPage1";
            this.toolTipIso15693.SetToolTip(this.tabPage1, resources.GetString("tabPage1.ToolTip"));
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBoxGetUid
            // 
            resources.ApplyResources(this.groupBoxGetUid, "groupBoxGetUid");
            this.groupBoxGetUid.Controls.Add(this.textBoxRemainTagNum);
            this.groupBoxGetUid.Controls.Add(this.textBoxReadTagNum);
            this.groupBoxGetUid.Controls.Add(this.label14);
            this.groupBoxGetUid.Controls.Add(this.label13);
            this.groupBoxGetUid.Controls.Add(this.buttonClearListBox);
            this.groupBoxGetUid.Controls.Add(this.buttonReadTags);
            this.groupBoxGetUid.Controls.Add(this.listBoxUID);
            this.groupBoxGetUid.Name = "groupBoxGetUid";
            this.groupBoxGetUid.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBoxGetUid, resources.GetString("groupBoxGetUid.ToolTip"));
            // 
            // textBoxRemainTagNum
            // 
            resources.ApplyResources(this.textBoxRemainTagNum, "textBoxRemainTagNum");
            this.textBoxRemainTagNum.Name = "textBoxRemainTagNum";
            this.toolTipIso15693.SetToolTip(this.textBoxRemainTagNum, resources.GetString("textBoxRemainTagNum.ToolTip"));
            // 
            // textBoxReadTagNum
            // 
            resources.ApplyResources(this.textBoxReadTagNum, "textBoxReadTagNum");
            this.textBoxReadTagNum.Name = "textBoxReadTagNum";
            this.toolTipIso15693.SetToolTip(this.textBoxReadTagNum, resources.GetString("textBoxReadTagNum.ToolTip"));
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            this.toolTipIso15693.SetToolTip(this.label14, resources.GetString("label14.ToolTip"));
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            this.toolTipIso15693.SetToolTip(this.label13, resources.GetString("label13.ToolTip"));
            // 
            // buttonClearListBox
            // 
            resources.ApplyResources(this.buttonClearListBox, "buttonClearListBox");
            this.buttonClearListBox.Name = "buttonClearListBox";
            this.toolTipIso15693.SetToolTip(this.buttonClearListBox, resources.GetString("buttonClearListBox.ToolTip"));
            this.buttonClearListBox.UseVisualStyleBackColor = true;
            this.buttonClearListBox.Click += new System.EventHandler(this.buttonClearListBox_Click);
            // 
            // buttonReadTags
            // 
            resources.ApplyResources(this.buttonReadTags, "buttonReadTags");
            this.buttonReadTags.Name = "buttonReadTags";
            this.toolTipIso15693.SetToolTip(this.buttonReadTags, resources.GetString("buttonReadTags.ToolTip"));
            this.buttonReadTags.UseVisualStyleBackColor = true;
            this.buttonReadTags.Click += new System.EventHandler(this.buttonReadTags_Click);
            // 
            // listBoxUID
            // 
            resources.ApplyResources(this.listBoxUID, "listBoxUID");
            this.listBoxUID.FormattingEnabled = true;
            this.listBoxUID.Name = "listBoxUID";
            this.toolTipIso15693.SetToolTip(this.listBoxUID, resources.GetString("listBoxUID.ToolTip"));
            this.listBoxUID.SelectedIndexChanged += new System.EventHandler(this.listBoxUID_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            resources.ApplyResources(this.tabPage5, "tabPage5");
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Controls.Add(this.groupBox12);
            this.tabPage5.Controls.Add(this.groupBoxBlocks);
            this.tabPage5.Name = "tabPage5";
            this.toolTipIso15693.SetToolTip(this.tabPage5, resources.GetString("tabPage5.ToolTip"));
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.buttonClearLockBlock);
            this.groupBox5.Controls.Add(this.textBoxLBlockAddr);
            this.groupBox5.Controls.Add(this.buttonLockBlock);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox5, resources.GetString("groupBox5.ToolTip"));
            // 
            // buttonClearLockBlock
            // 
            resources.ApplyResources(this.buttonClearLockBlock, "buttonClearLockBlock");
            this.buttonClearLockBlock.Name = "buttonClearLockBlock";
            this.toolTipIso15693.SetToolTip(this.buttonClearLockBlock, resources.GetString("buttonClearLockBlock.ToolTip"));
            this.buttonClearLockBlock.UseVisualStyleBackColor = true;
            this.buttonClearLockBlock.Click += new System.EventHandler(this.buttonClearLockBlock_Click);
            // 
            // textBoxLBlockAddr
            // 
            resources.ApplyResources(this.textBoxLBlockAddr, "textBoxLBlockAddr");
            this.textBoxLBlockAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxLBlockAddr.Name = "textBoxLBlockAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxLBlockAddr, resources.GetString("textBoxLBlockAddr.ToolTip"));
            // 
            // buttonLockBlock
            // 
            resources.ApplyResources(this.buttonLockBlock, "buttonLockBlock");
            this.buttonLockBlock.Name = "buttonLockBlock";
            this.toolTipIso15693.SetToolTip(this.buttonLockBlock, resources.GetString("buttonLockBlock.ToolTip"));
            this.buttonLockBlock.UseVisualStyleBackColor = true;
            this.buttonLockBlock.Click += new System.EventHandler(this.buttonLockBlock_Click);
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            this.toolTipIso15693.SetToolTip(this.label10, resources.GetString("label10.ToolTip"));
            // 
            // groupBox12
            // 
            resources.ApplyResources(this.groupBox12, "groupBox12");
            this.groupBox12.Controls.Add(this.textBoxWMBlockNum);
            this.groupBox12.Controls.Add(this.textBoxWMBlockAddr);
            this.groupBox12.Controls.Add(this.buttonClearWMBlock);
            this.groupBox12.Controls.Add(this.label36);
            this.groupBox12.Controls.Add(this.textBoxWMBlockData);
            this.groupBox12.Controls.Add(this.buttonWriteMBlock);
            this.groupBox12.Controls.Add(this.label37);
            this.groupBox12.Controls.Add(this.label38);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox12, resources.GetString("groupBox12.ToolTip"));
            // 
            // textBoxWMBlockNum
            // 
            resources.ApplyResources(this.textBoxWMBlockNum, "textBoxWMBlockNum");
            this.textBoxWMBlockNum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWMBlockNum.Name = "textBoxWMBlockNum";
            this.toolTipIso15693.SetToolTip(this.textBoxWMBlockNum, resources.GetString("textBoxWMBlockNum.ToolTip"));
            // 
            // textBoxWMBlockAddr
            // 
            resources.ApplyResources(this.textBoxWMBlockAddr, "textBoxWMBlockAddr");
            this.textBoxWMBlockAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWMBlockAddr.Name = "textBoxWMBlockAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxWMBlockAddr, resources.GetString("textBoxWMBlockAddr.ToolTip"));
            // 
            // buttonClearWMBlock
            // 
            resources.ApplyResources(this.buttonClearWMBlock, "buttonClearWMBlock");
            this.buttonClearWMBlock.Name = "buttonClearWMBlock";
            this.toolTipIso15693.SetToolTip(this.buttonClearWMBlock, resources.GetString("buttonClearWMBlock.ToolTip"));
            this.buttonClearWMBlock.UseVisualStyleBackColor = true;
            this.buttonClearWMBlock.Click += new System.EventHandler(this.buttonClearWMBlock_Click);
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            this.toolTipIso15693.SetToolTip(this.label36, resources.GetString("label36.ToolTip"));
            // 
            // textBoxWMBlockData
            // 
            resources.ApplyResources(this.textBoxWMBlockData, "textBoxWMBlockData");
            this.textBoxWMBlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxWMBlockData.Name = "textBoxWMBlockData";
            this.toolTipIso15693.SetToolTip(this.textBoxWMBlockData, resources.GetString("textBoxWMBlockData.ToolTip"));
            // 
            // buttonWriteMBlock
            // 
            resources.ApplyResources(this.buttonWriteMBlock, "buttonWriteMBlock");
            this.buttonWriteMBlock.AllowDrop = true;
            this.buttonWriteMBlock.Name = "buttonWriteMBlock";
            this.toolTipIso15693.SetToolTip(this.buttonWriteMBlock, resources.GetString("buttonWriteMBlock.ToolTip"));
            this.buttonWriteMBlock.UseVisualStyleBackColor = true;
            this.buttonWriteMBlock.Click += new System.EventHandler(this.buttonWriteMBlock_Click);
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            this.toolTipIso15693.SetToolTip(this.label37, resources.GetString("label37.ToolTip"));
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.Name = "label38";
            this.toolTipIso15693.SetToolTip(this.label38, resources.GetString("label38.ToolTip"));
            // 
            // groupBoxBlocks
            // 
            resources.ApplyResources(this.groupBoxBlocks, "groupBoxBlocks");
            this.groupBoxBlocks.Controls.Add(this.textBoxRMBlockNum);
            this.groupBoxBlocks.Controls.Add(this.textBoxRMBlockAddr);
            this.groupBoxBlocks.Controls.Add(this.buttonClearRMultBlock);
            this.groupBoxBlocks.Controls.Add(this.label21);
            this.groupBoxBlocks.Controls.Add(this.textBoxRMBlockData);
            this.groupBoxBlocks.Controls.Add(this.buttonReadMBlock);
            this.groupBoxBlocks.Controls.Add(this.label19);
            this.groupBoxBlocks.Controls.Add(this.label20);
            this.groupBoxBlocks.Name = "groupBoxBlocks";
            this.groupBoxBlocks.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBoxBlocks, resources.GetString("groupBoxBlocks.ToolTip"));
            // 
            // textBoxRMBlockNum
            // 
            resources.ApplyResources(this.textBoxRMBlockNum, "textBoxRMBlockNum");
            this.textBoxRMBlockNum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxRMBlockNum.Name = "textBoxRMBlockNum";
            this.toolTipIso15693.SetToolTip(this.textBoxRMBlockNum, resources.GetString("textBoxRMBlockNum.ToolTip"));
            // 
            // textBoxRMBlockAddr
            // 
            resources.ApplyResources(this.textBoxRMBlockAddr, "textBoxRMBlockAddr");
            this.textBoxRMBlockAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxRMBlockAddr.Name = "textBoxRMBlockAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxRMBlockAddr, resources.GetString("textBoxRMBlockAddr.ToolTip"));
            // 
            // buttonClearRMultBlock
            // 
            resources.ApplyResources(this.buttonClearRMultBlock, "buttonClearRMultBlock");
            this.buttonClearRMultBlock.Name = "buttonClearRMultBlock";
            this.toolTipIso15693.SetToolTip(this.buttonClearRMultBlock, resources.GetString("buttonClearRMultBlock.ToolTip"));
            this.buttonClearRMultBlock.UseVisualStyleBackColor = true;
            this.buttonClearRMultBlock.Click += new System.EventHandler(this.buttonClearMultBlock_Click);
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            this.toolTipIso15693.SetToolTip(this.label21, resources.GetString("label21.ToolTip"));
            // 
            // textBoxRMBlockData
            // 
            resources.ApplyResources(this.textBoxRMBlockData, "textBoxRMBlockData");
            this.textBoxRMBlockData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxRMBlockData.Name = "textBoxRMBlockData";
            this.toolTipIso15693.SetToolTip(this.textBoxRMBlockData, resources.GetString("textBoxRMBlockData.ToolTip"));
            // 
            // buttonReadMBlock
            // 
            resources.ApplyResources(this.buttonReadMBlock, "buttonReadMBlock");
            this.buttonReadMBlock.Name = "buttonReadMBlock";
            this.toolTipIso15693.SetToolTip(this.buttonReadMBlock, resources.GetString("buttonReadMBlock.ToolTip"));
            this.buttonReadMBlock.UseVisualStyleBackColor = true;
            this.buttonReadMBlock.Click += new System.EventHandler(this.buttonReadMBlock_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            this.toolTipIso15693.SetToolTip(this.label19, resources.GetString("label19.ToolTip"));
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            this.toolTipIso15693.SetToolTip(this.label20, resources.GetString("label20.ToolTip"));
            // 
            // tabPage3
            // 
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Controls.Add(this.groupBoxTagInfo);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBoxTagParam);
            this.tabPage3.Name = "tabPage3";
            this.toolTipIso15693.SetToolTip(this.tabPage3, resources.GetString("tabPage3.ToolTip"));
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBoxTagInfo
            // 
            resources.ApplyResources(this.groupBoxTagInfo, "groupBoxTagInfo");
            this.groupBoxTagInfo.Controls.Add(this.buttonClearTagInfo);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfICRef);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfBlockSize);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfBlockNum);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfAFI);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfDSFID);
            this.groupBoxTagInfo.Controls.Add(this.textBoxTagInfFlag);
            this.groupBoxTagInfo.Controls.Add(this.label27);
            this.groupBoxTagInfo.Controls.Add(this.label26);
            this.groupBoxTagInfo.Controls.Add(this.label25);
            this.groupBoxTagInfo.Controls.Add(this.label24);
            this.groupBoxTagInfo.Controls.Add(this.label23);
            this.groupBoxTagInfo.Controls.Add(this.label22);
            this.groupBoxTagInfo.Controls.Add(this.buttonReadTagInf);
            this.groupBoxTagInfo.Name = "groupBoxTagInfo";
            this.groupBoxTagInfo.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBoxTagInfo, resources.GetString("groupBoxTagInfo.ToolTip"));
            // 
            // buttonClearTagInfo
            // 
            resources.ApplyResources(this.buttonClearTagInfo, "buttonClearTagInfo");
            this.buttonClearTagInfo.Name = "buttonClearTagInfo";
            this.toolTipIso15693.SetToolTip(this.buttonClearTagInfo, resources.GetString("buttonClearTagInfo.ToolTip"));
            this.buttonClearTagInfo.UseVisualStyleBackColor = true;
            this.buttonClearTagInfo.Click += new System.EventHandler(this.buttonClearTagInfo_Click);
            // 
            // textBoxTagInfICRef
            // 
            resources.ApplyResources(this.textBoxTagInfICRef, "textBoxTagInfICRef");
            this.textBoxTagInfICRef.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfICRef.Name = "textBoxTagInfICRef";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfICRef, resources.GetString("textBoxTagInfICRef.ToolTip"));
            // 
            // textBoxTagInfBlockSize
            // 
            resources.ApplyResources(this.textBoxTagInfBlockSize, "textBoxTagInfBlockSize");
            this.textBoxTagInfBlockSize.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfBlockSize.Name = "textBoxTagInfBlockSize";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfBlockSize, resources.GetString("textBoxTagInfBlockSize.ToolTip"));
            // 
            // textBoxTagInfBlockNum
            // 
            resources.ApplyResources(this.textBoxTagInfBlockNum, "textBoxTagInfBlockNum");
            this.textBoxTagInfBlockNum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfBlockNum.Name = "textBoxTagInfBlockNum";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfBlockNum, resources.GetString("textBoxTagInfBlockNum.ToolTip"));
            // 
            // textBoxTagInfAFI
            // 
            resources.ApplyResources(this.textBoxTagInfAFI, "textBoxTagInfAFI");
            this.textBoxTagInfAFI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfAFI.Name = "textBoxTagInfAFI";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfAFI, resources.GetString("textBoxTagInfAFI.ToolTip"));
            // 
            // textBoxTagInfDSFID
            // 
            resources.ApplyResources(this.textBoxTagInfDSFID, "textBoxTagInfDSFID");
            this.textBoxTagInfDSFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfDSFID.Name = "textBoxTagInfDSFID";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfDSFID, resources.GetString("textBoxTagInfDSFID.ToolTip"));
            // 
            // textBoxTagInfFlag
            // 
            resources.ApplyResources(this.textBoxTagInfFlag, "textBoxTagInfFlag");
            this.textBoxTagInfFlag.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxTagInfFlag.Name = "textBoxTagInfFlag";
            this.toolTipIso15693.SetToolTip(this.textBoxTagInfFlag, resources.GetString("textBoxTagInfFlag.ToolTip"));
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            this.toolTipIso15693.SetToolTip(this.label27, resources.GetString("label27.ToolTip"));
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            this.toolTipIso15693.SetToolTip(this.label26, resources.GetString("label26.ToolTip"));
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            this.toolTipIso15693.SetToolTip(this.label25, resources.GetString("label25.ToolTip"));
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            this.toolTipIso15693.SetToolTip(this.label24, resources.GetString("label24.ToolTip"));
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            this.toolTipIso15693.SetToolTip(this.label23, resources.GetString("label23.ToolTip"));
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            this.toolTipIso15693.SetToolTip(this.label22, resources.GetString("label22.ToolTip"));
            // 
            // buttonReadTagInf
            // 
            resources.ApplyResources(this.buttonReadTagInf, "buttonReadTagInf");
            this.buttonReadTagInf.Name = "buttonReadTagInf";
            this.toolTipIso15693.SetToolTip(this.buttonReadTagInf, resources.GetString("buttonReadTagInf.ToolTip"));
            this.buttonReadTagInf.UseVisualStyleBackColor = true;
            this.buttonReadTagInf.Click += new System.EventHandler(this.buttonReadTagInf_Click);
            // 
            // groupBox7
            // 
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Controls.Add(this.textBoxDSFIDValue);
            this.groupBox7.Controls.Add(this.buttonCtrlDsfid);
            this.groupBox7.Controls.Add(this.radioButtonWriteDSFID);
            this.groupBox7.Controls.Add(this.radioButtonLockDSFID);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox7, resources.GetString("groupBox7.ToolTip"));
            // 
            // textBoxDSFIDValue
            // 
            resources.ApplyResources(this.textBoxDSFIDValue, "textBoxDSFIDValue");
            this.textBoxDSFIDValue.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDSFIDValue.Name = "textBoxDSFIDValue";
            this.toolTipIso15693.SetToolTip(this.textBoxDSFIDValue, resources.GetString("textBoxDSFIDValue.ToolTip"));
            // 
            // buttonCtrlDsfid
            // 
            resources.ApplyResources(this.buttonCtrlDsfid, "buttonCtrlDsfid");
            this.buttonCtrlDsfid.Name = "buttonCtrlDsfid";
            this.toolTipIso15693.SetToolTip(this.buttonCtrlDsfid, resources.GetString("buttonCtrlDsfid.ToolTip"));
            this.buttonCtrlDsfid.UseVisualStyleBackColor = true;
            this.buttonCtrlDsfid.Click += new System.EventHandler(this.buttonCtrlDsfid_Click);
            // 
            // radioButtonWriteDSFID
            // 
            resources.ApplyResources(this.radioButtonWriteDSFID, "radioButtonWriteDSFID");
            this.radioButtonWriteDSFID.Checked = true;
            this.radioButtonWriteDSFID.Name = "radioButtonWriteDSFID";
            this.radioButtonWriteDSFID.TabStop = true;
            this.toolTipIso15693.SetToolTip(this.radioButtonWriteDSFID, resources.GetString("radioButtonWriteDSFID.ToolTip"));
            this.radioButtonWriteDSFID.UseVisualStyleBackColor = true;
            // 
            // radioButtonLockDSFID
            // 
            resources.ApplyResources(this.radioButtonLockDSFID, "radioButtonLockDSFID");
            this.radioButtonLockDSFID.Name = "radioButtonLockDSFID";
            this.toolTipIso15693.SetToolTip(this.radioButtonLockDSFID, resources.GetString("radioButtonLockDSFID.ToolTip"));
            this.radioButtonLockDSFID.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.textBoxAFIValue);
            this.groupBox6.Controls.Add(this.buttonCtrlAfi);
            this.groupBox6.Controls.Add(this.radioButtonWriteAFI);
            this.groupBox6.Controls.Add(this.radioButtonLockAFI);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox6, resources.GetString("groupBox6.ToolTip"));
            // 
            // textBoxAFIValue
            // 
            resources.ApplyResources(this.textBoxAFIValue, "textBoxAFIValue");
            this.textBoxAFIValue.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxAFIValue.Name = "textBoxAFIValue";
            this.toolTipIso15693.SetToolTip(this.textBoxAFIValue, resources.GetString("textBoxAFIValue.ToolTip"));
            // 
            // buttonCtrlAfi
            // 
            resources.ApplyResources(this.buttonCtrlAfi, "buttonCtrlAfi");
            this.buttonCtrlAfi.Name = "buttonCtrlAfi";
            this.toolTipIso15693.SetToolTip(this.buttonCtrlAfi, resources.GetString("buttonCtrlAfi.ToolTip"));
            this.buttonCtrlAfi.UseVisualStyleBackColor = true;
            this.buttonCtrlAfi.Click += new System.EventHandler(this.buttonCtrlAfi_Click);
            // 
            // radioButtonWriteAFI
            // 
            resources.ApplyResources(this.radioButtonWriteAFI, "radioButtonWriteAFI");
            this.radioButtonWriteAFI.Checked = true;
            this.radioButtonWriteAFI.Name = "radioButtonWriteAFI";
            this.radioButtonWriteAFI.TabStop = true;
            this.toolTipIso15693.SetToolTip(this.radioButtonWriteAFI, resources.GetString("radioButtonWriteAFI.ToolTip"));
            this.radioButtonWriteAFI.UseVisualStyleBackColor = true;
            // 
            // radioButtonLockAFI
            // 
            resources.ApplyResources(this.radioButtonLockAFI, "radioButtonLockAFI");
            this.radioButtonLockAFI.Name = "radioButtonLockAFI";
            this.toolTipIso15693.SetToolTip(this.radioButtonLockAFI, resources.GetString("radioButtonLockAFI.ToolTip"));
            this.radioButtonLockAFI.UseVisualStyleBackColor = true;
            // 
            // groupBoxTagParam
            // 
            resources.ApplyResources(this.groupBoxTagParam, "groupBoxTagParam");
            this.groupBoxTagParam.Controls.Add(this.buttonCtrlEas);
            this.groupBoxTagParam.Controls.Add(this.radioButtonLockEAS);
            this.groupBoxTagParam.Controls.Add(this.radioButtonResetEAS);
            this.groupBoxTagParam.Controls.Add(this.radioButtonSetEAS);
            this.groupBoxTagParam.Name = "groupBoxTagParam";
            this.groupBoxTagParam.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBoxTagParam, resources.GetString("groupBoxTagParam.ToolTip"));
            // 
            // buttonCtrlEas
            // 
            resources.ApplyResources(this.buttonCtrlEas, "buttonCtrlEas");
            this.buttonCtrlEas.Name = "buttonCtrlEas";
            this.toolTipIso15693.SetToolTip(this.buttonCtrlEas, resources.GetString("buttonCtrlEas.ToolTip"));
            this.buttonCtrlEas.UseVisualStyleBackColor = true;
            this.buttonCtrlEas.Click += new System.EventHandler(this.buttonCtrlEas_Click);
            // 
            // radioButtonLockEAS
            // 
            resources.ApplyResources(this.radioButtonLockEAS, "radioButtonLockEAS");
            this.radioButtonLockEAS.Name = "radioButtonLockEAS";
            this.toolTipIso15693.SetToolTip(this.radioButtonLockEAS, resources.GetString("radioButtonLockEAS.ToolTip"));
            this.radioButtonLockEAS.UseVisualStyleBackColor = true;
            // 
            // radioButtonResetEAS
            // 
            resources.ApplyResources(this.radioButtonResetEAS, "radioButtonResetEAS");
            this.radioButtonResetEAS.Name = "radioButtonResetEAS";
            this.toolTipIso15693.SetToolTip(this.radioButtonResetEAS, resources.GetString("radioButtonResetEAS.ToolTip"));
            this.radioButtonResetEAS.UseVisualStyleBackColor = true;
            // 
            // radioButtonSetEAS
            // 
            resources.ApplyResources(this.radioButtonSetEAS, "radioButtonSetEAS");
            this.radioButtonSetEAS.Checked = true;
            this.radioButtonSetEAS.Name = "radioButtonSetEAS";
            this.radioButtonSetEAS.TabStop = true;
            this.toolTipIso15693.SetToolTip(this.radioButtonSetEAS, resources.GetString("radioButtonSetEAS.ToolTip"));
            this.radioButtonSetEAS.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Controls.Add(this.textBoxDtuRxLen);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.textBoxDtuTime);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.buttonDtuRxClear);
            this.tabPage2.Controls.Add(this.buttonDtuTxClear);
            this.tabPage2.Controls.Add(this.textBoxDtuRx);
            this.tabPage2.Controls.Add(this.textBoxDtuTx);
            this.tabPage2.Controls.Add(this.buttonDtu);
            this.tabPage2.Name = "tabPage2";
            this.toolTipIso15693.SetToolTip(this.tabPage2, resources.GetString("tabPage2.ToolTip"));
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBoxDtuRxLen
            // 
            resources.ApplyResources(this.textBoxDtuRxLen, "textBoxDtuRxLen");
            this.textBoxDtuRxLen.Name = "textBoxDtuRxLen";
            this.toolTipIso15693.SetToolTip(this.textBoxDtuRxLen, resources.GetString("textBoxDtuRxLen.ToolTip"));
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            this.toolTipIso15693.SetToolTip(this.label12, resources.GetString("label12.ToolTip"));
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            this.toolTipIso15693.SetToolTip(this.label11, resources.GetString("label11.ToolTip"));
            // 
            // textBoxDtuTime
            // 
            resources.ApplyResources(this.textBoxDtuTime, "textBoxDtuTime");
            this.textBoxDtuTime.Name = "textBoxDtuTime";
            this.toolTipIso15693.SetToolTip(this.textBoxDtuTime, resources.GetString("textBoxDtuTime.ToolTip"));
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            this.toolTipIso15693.SetToolTip(this.label9, resources.GetString("label9.ToolTip"));
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            this.toolTipIso15693.SetToolTip(this.label4, resources.GetString("label4.ToolTip"));
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.toolTipIso15693.SetToolTip(this.label3, resources.GetString("label3.ToolTip"));
            // 
            // buttonDtuRxClear
            // 
            resources.ApplyResources(this.buttonDtuRxClear, "buttonDtuRxClear");
            this.buttonDtuRxClear.Name = "buttonDtuRxClear";
            this.toolTipIso15693.SetToolTip(this.buttonDtuRxClear, resources.GetString("buttonDtuRxClear.ToolTip"));
            this.buttonDtuRxClear.UseVisualStyleBackColor = true;
            this.buttonDtuRxClear.Click += new System.EventHandler(this.buttonDtuRxClear_Click);
            // 
            // buttonDtuTxClear
            // 
            resources.ApplyResources(this.buttonDtuTxClear, "buttonDtuTxClear");
            this.buttonDtuTxClear.Name = "buttonDtuTxClear";
            this.toolTipIso15693.SetToolTip(this.buttonDtuTxClear, resources.GetString("buttonDtuTxClear.ToolTip"));
            this.buttonDtuTxClear.UseVisualStyleBackColor = true;
            this.buttonDtuTxClear.Click += new System.EventHandler(this.buttonDtuTxClear_Click);
            // 
            // textBoxDtuRx
            // 
            resources.ApplyResources(this.textBoxDtuRx, "textBoxDtuRx");
            this.textBoxDtuRx.Name = "textBoxDtuRx";
            this.toolTipIso15693.SetToolTip(this.textBoxDtuRx, resources.GetString("textBoxDtuRx.ToolTip"));
            // 
            // textBoxDtuTx
            // 
            resources.ApplyResources(this.textBoxDtuTx, "textBoxDtuTx");
            this.textBoxDtuTx.Name = "textBoxDtuTx";
            this.toolTipIso15693.SetToolTip(this.textBoxDtuTx, resources.GetString("textBoxDtuTx.ToolTip"));
            // 
            // buttonDtu
            // 
            resources.ApplyResources(this.buttonDtu, "buttonDtu");
            this.buttonDtu.Name = "buttonDtu";
            this.toolTipIso15693.SetToolTip(this.buttonDtu, resources.GetString("buttonDtu.ToolTip"));
            this.buttonDtu.UseVisualStyleBackColor = true;
            this.buttonDtu.Click += new System.EventHandler(this.buttonDtu_Click);
            // 
            // tabPage4
            // 
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Controls.Add(this.checkBoxWaitTime);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.textBoxDirOpBlockAddr);
            this.tabPage4.Controls.Add(this.comboBoxOpTag);
            this.tabPage4.Controls.Add(this.textBoxOpTagInfo);
            this.tabPage4.Controls.Add(this.buttonOpTagStart);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Name = "tabPage4";
            this.toolTipIso15693.SetToolTip(this.tabPage4, resources.GetString("tabPage4.ToolTip"));
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // checkBoxWaitTime
            // 
            resources.ApplyResources(this.checkBoxWaitTime, "checkBoxWaitTime");
            this.checkBoxWaitTime.Name = "checkBoxWaitTime";
            this.toolTipIso15693.SetToolTip(this.checkBoxWaitTime, resources.GetString("checkBoxWaitTime.ToolTip"));
            this.checkBoxWaitTime.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            this.toolTipIso15693.SetToolTip(this.label5, resources.GetString("label5.ToolTip"));
            // 
            // textBoxDirOpBlockAddr
            // 
            resources.ApplyResources(this.textBoxDirOpBlockAddr, "textBoxDirOpBlockAddr");
            this.textBoxDirOpBlockAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDirOpBlockAddr.Name = "textBoxDirOpBlockAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxDirOpBlockAddr, resources.GetString("textBoxDirOpBlockAddr.ToolTip"));
            // 
            // comboBoxOpTag
            // 
            resources.ApplyResources(this.comboBoxOpTag, "comboBoxOpTag");
            this.comboBoxOpTag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOpTag.FormattingEnabled = true;
            this.comboBoxOpTag.Items.AddRange(new object[] {
            resources.GetString("comboBoxOpTag.Items"),
            resources.GetString("comboBoxOpTag.Items1"),
            resources.GetString("comboBoxOpTag.Items2"),
            resources.GetString("comboBoxOpTag.Items3"),
            resources.GetString("comboBoxOpTag.Items4"),
            resources.GetString("comboBoxOpTag.Items5"),
            resources.GetString("comboBoxOpTag.Items6"),
            resources.GetString("comboBoxOpTag.Items7")});
            this.comboBoxOpTag.Name = "comboBoxOpTag";
            this.toolTipIso15693.SetToolTip(this.comboBoxOpTag, resources.GetString("comboBoxOpTag.ToolTip"));
            this.comboBoxOpTag.SelectedIndexChanged += new System.EventHandler(this.comboBoxOpTag_SelectedIndexChanged);
            // 
            // textBoxOpTagInfo
            // 
            resources.ApplyResources(this.textBoxOpTagInfo, "textBoxOpTagInfo");
            this.textBoxOpTagInfo.Name = "textBoxOpTagInfo";
            this.textBoxOpTagInfo.ReadOnly = true;
            this.toolTipIso15693.SetToolTip(this.textBoxOpTagInfo, resources.GetString("textBoxOpTagInfo.ToolTip"));
            // 
            // buttonOpTagStart
            // 
            resources.ApplyResources(this.buttonOpTagStart, "buttonOpTagStart");
            this.buttonOpTagStart.Name = "buttonOpTagStart";
            this.toolTipIso15693.SetToolTip(this.buttonOpTagStart, resources.GetString("buttonOpTagStart.ToolTip"));
            this.buttonOpTagStart.UseVisualStyleBackColor = true;
            this.buttonOpTagStart.Click += new System.EventHandler(this.buttonOpTagStart_Click);
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            this.toolTipIso15693.SetToolTip(this.label18, resources.GetString("label18.ToolTip"));
            // 
            // tabPage6
            // 
            resources.ApplyResources(this.tabPage6, "tabPage6");
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Controls.Add(this.comboBoxImOpAntAddr);
            this.tabPage6.Controls.Add(this.comboBoxImOpAnt);
            this.tabPage6.Controls.Add(this.label42);
            this.tabPage6.Controls.Add(this.label40);
            this.tabPage6.Controls.Add(this.buttonImOpStart);
            this.tabPage6.Controls.Add(this.textBoxImOpBlockAddr);
            this.tabPage6.Controls.Add(this.comboBoxImOpMode);
            this.tabPage6.Controls.Add(this.textBoxImTagInfo);
            this.tabPage6.Name = "tabPage6";
            this.toolTipIso15693.SetToolTip(this.tabPage6, resources.GetString("tabPage6.ToolTip"));
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            this.toolTipIso15693.SetToolTip(this.label6, resources.GetString("label6.ToolTip"));
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.toolTipIso15693.SetToolTip(this.label2, resources.GetString("label2.ToolTip"));
            // 
            // comboBoxImOpAntAddr
            // 
            this.comboBoxImOpAntAddr.AcceptsTab = true;
            resources.ApplyResources(this.comboBoxImOpAntAddr, "comboBoxImOpAntAddr");
            this.comboBoxImOpAntAddr.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.comboBoxImOpAntAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.comboBoxImOpAntAddr.Name = "comboBoxImOpAntAddr";
            this.toolTipIso15693.SetToolTip(this.comboBoxImOpAntAddr, resources.GetString("comboBoxImOpAntAddr.ToolTip"));
            // 
            // comboBoxImOpAnt
            // 
            resources.ApplyResources(this.comboBoxImOpAnt, "comboBoxImOpAnt");
            this.comboBoxImOpAnt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxImOpAnt.FormattingEnabled = true;
            this.comboBoxImOpAnt.Items.AddRange(new object[] {
            resources.GetString("comboBoxImOpAnt.Items"),
            resources.GetString("comboBoxImOpAnt.Items1"),
            resources.GetString("comboBoxImOpAnt.Items2"),
            resources.GetString("comboBoxImOpAnt.Items3"),
            resources.GetString("comboBoxImOpAnt.Items4"),
            resources.GetString("comboBoxImOpAnt.Items5"),
            resources.GetString("comboBoxImOpAnt.Items6"),
            resources.GetString("comboBoxImOpAnt.Items7"),
            resources.GetString("comboBoxImOpAnt.Items8"),
            resources.GetString("comboBoxImOpAnt.Items9"),
            resources.GetString("comboBoxImOpAnt.Items10"),
            resources.GetString("comboBoxImOpAnt.Items11"),
            resources.GetString("comboBoxImOpAnt.Items12"),
            resources.GetString("comboBoxImOpAnt.Items13"),
            resources.GetString("comboBoxImOpAnt.Items14"),
            resources.GetString("comboBoxImOpAnt.Items15"),
            resources.GetString("comboBoxImOpAnt.Items16"),
            resources.GetString("comboBoxImOpAnt.Items17"),
            resources.GetString("comboBoxImOpAnt.Items18"),
            resources.GetString("comboBoxImOpAnt.Items19"),
            resources.GetString("comboBoxImOpAnt.Items20"),
            resources.GetString("comboBoxImOpAnt.Items21"),
            resources.GetString("comboBoxImOpAnt.Items22"),
            resources.GetString("comboBoxImOpAnt.Items23"),
            resources.GetString("comboBoxImOpAnt.Items24"),
            resources.GetString("comboBoxImOpAnt.Items25"),
            resources.GetString("comboBoxImOpAnt.Items26")});
            this.comboBoxImOpAnt.Name = "comboBoxImOpAnt";
            this.toolTipIso15693.SetToolTip(this.comboBoxImOpAnt, resources.GetString("comboBoxImOpAnt.ToolTip"));
            this.comboBoxImOpAnt.SelectedIndexChanged += new System.EventHandler(this.comboBoxImOpAnt_SelectedIndexChanged);
            // 
            // label42
            // 
            resources.ApplyResources(this.label42, "label42");
            this.label42.Name = "label42";
            this.toolTipIso15693.SetToolTip(this.label42, resources.GetString("label42.ToolTip"));
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.Name = "label40";
            this.toolTipIso15693.SetToolTip(this.label40, resources.GetString("label40.ToolTip"));
            // 
            // buttonImOpStart
            // 
            resources.ApplyResources(this.buttonImOpStart, "buttonImOpStart");
            this.buttonImOpStart.Name = "buttonImOpStart";
            this.toolTipIso15693.SetToolTip(this.buttonImOpStart, resources.GetString("buttonImOpStart.ToolTip"));
            this.buttonImOpStart.UseVisualStyleBackColor = true;
            this.buttonImOpStart.Click += new System.EventHandler(this.buttonImOpStart_Click);
            // 
            // textBoxImOpBlockAddr
            // 
            this.textBoxImOpBlockAddr.AcceptsTab = true;
            resources.ApplyResources(this.textBoxImOpBlockAddr, "textBoxImOpBlockAddr");
            this.textBoxImOpBlockAddr.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBoxImOpBlockAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxImOpBlockAddr.Name = "textBoxImOpBlockAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxImOpBlockAddr, resources.GetString("textBoxImOpBlockAddr.ToolTip"));
            // 
            // comboBoxImOpMode
            // 
            resources.ApplyResources(this.comboBoxImOpMode, "comboBoxImOpMode");
            this.comboBoxImOpMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxImOpMode.FormattingEnabled = true;
            this.comboBoxImOpMode.Items.AddRange(new object[] {
            resources.GetString("comboBoxImOpMode.Items"),
            resources.GetString("comboBoxImOpMode.Items1")});
            this.comboBoxImOpMode.Name = "comboBoxImOpMode";
            this.toolTipIso15693.SetToolTip(this.comboBoxImOpMode, resources.GetString("comboBoxImOpMode.ToolTip"));
            this.comboBoxImOpMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxImOpMode_SelectedIndexChanged);
            // 
            // textBoxImTagInfo
            // 
            resources.ApplyResources(this.textBoxImTagInfo, "textBoxImTagInfo");
            this.textBoxImTagInfo.Name = "textBoxImTagInfo";
            this.textBoxImTagInfo.ReadOnly = true;
            this.toolTipIso15693.SetToolTip(this.textBoxImTagInfo, resources.GetString("textBoxImTagInfo.ToolTip"));
            // 
            // tabPage7
            // 
            resources.ApplyResources(this.tabPage7, "tabPage7");
            this.tabPage7.Controls.Add(this.textBoxGateAlarmUid);
            this.tabPage7.Controls.Add(this.buttonStartRcvGateAlarmUid);
            this.tabPage7.Controls.Add(this.buttonSetGateMode);
            this.tabPage7.Controls.Add(this.comboBoxEnableGateMode);
            this.tabPage7.Controls.Add(this.buttonSetScanAnts);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt8);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt7);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt6);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt5);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt4);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt3);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt2);
            this.tabPage7.Controls.Add(this.checkBoxGateAnt1);
            this.tabPage7.Name = "tabPage7";
            this.toolTipIso15693.SetToolTip(this.tabPage7, resources.GetString("tabPage7.ToolTip"));
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // textBoxGateAlarmUid
            // 
            resources.ApplyResources(this.textBoxGateAlarmUid, "textBoxGateAlarmUid");
            this.textBoxGateAlarmUid.Name = "textBoxGateAlarmUid";
            this.textBoxGateAlarmUid.ReadOnly = true;
            this.toolTipIso15693.SetToolTip(this.textBoxGateAlarmUid, resources.GetString("textBoxGateAlarmUid.ToolTip"));
            // 
            // buttonStartRcvGateAlarmUid
            // 
            resources.ApplyResources(this.buttonStartRcvGateAlarmUid, "buttonStartRcvGateAlarmUid");
            this.buttonStartRcvGateAlarmUid.Name = "buttonStartRcvGateAlarmUid";
            this.toolTipIso15693.SetToolTip(this.buttonStartRcvGateAlarmUid, resources.GetString("buttonStartRcvGateAlarmUid.ToolTip"));
            this.buttonStartRcvGateAlarmUid.UseVisualStyleBackColor = true;
            this.buttonStartRcvGateAlarmUid.Click += new System.EventHandler(this.buttonStartRcvGateAlarmUid_Click);
            // 
            // buttonSetGateMode
            // 
            resources.ApplyResources(this.buttonSetGateMode, "buttonSetGateMode");
            this.buttonSetGateMode.Name = "buttonSetGateMode";
            this.toolTipIso15693.SetToolTip(this.buttonSetGateMode, resources.GetString("buttonSetGateMode.ToolTip"));
            this.buttonSetGateMode.UseVisualStyleBackColor = true;
            this.buttonSetGateMode.Click += new System.EventHandler(this.buttonSetGateMode_Click);
            // 
            // comboBoxEnableGateMode
            // 
            resources.ApplyResources(this.comboBoxEnableGateMode, "comboBoxEnableGateMode");
            this.comboBoxEnableGateMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEnableGateMode.FormattingEnabled = true;
            this.comboBoxEnableGateMode.Items.AddRange(new object[] {
            resources.GetString("comboBoxEnableGateMode.Items"),
            resources.GetString("comboBoxEnableGateMode.Items1")});
            this.comboBoxEnableGateMode.Name = "comboBoxEnableGateMode";
            this.toolTipIso15693.SetToolTip(this.comboBoxEnableGateMode, resources.GetString("comboBoxEnableGateMode.ToolTip"));
            // 
            // buttonSetScanAnts
            // 
            resources.ApplyResources(this.buttonSetScanAnts, "buttonSetScanAnts");
            this.buttonSetScanAnts.Name = "buttonSetScanAnts";
            this.toolTipIso15693.SetToolTip(this.buttonSetScanAnts, resources.GetString("buttonSetScanAnts.ToolTip"));
            this.buttonSetScanAnts.UseVisualStyleBackColor = true;
            this.buttonSetScanAnts.Click += new System.EventHandler(this.buttonSetScanAnts_Click);
            // 
            // checkBoxGateAnt8
            // 
            resources.ApplyResources(this.checkBoxGateAnt8, "checkBoxGateAnt8");
            this.checkBoxGateAnt8.Name = "checkBoxGateAnt8";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt8, resources.GetString("checkBoxGateAnt8.ToolTip"));
            this.checkBoxGateAnt8.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt7
            // 
            resources.ApplyResources(this.checkBoxGateAnt7, "checkBoxGateAnt7");
            this.checkBoxGateAnt7.Name = "checkBoxGateAnt7";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt7, resources.GetString("checkBoxGateAnt7.ToolTip"));
            this.checkBoxGateAnt7.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt6
            // 
            resources.ApplyResources(this.checkBoxGateAnt6, "checkBoxGateAnt6");
            this.checkBoxGateAnt6.Name = "checkBoxGateAnt6";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt6, resources.GetString("checkBoxGateAnt6.ToolTip"));
            this.checkBoxGateAnt6.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt5
            // 
            resources.ApplyResources(this.checkBoxGateAnt5, "checkBoxGateAnt5");
            this.checkBoxGateAnt5.Name = "checkBoxGateAnt5";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt5, resources.GetString("checkBoxGateAnt5.ToolTip"));
            this.checkBoxGateAnt5.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt4
            // 
            resources.ApplyResources(this.checkBoxGateAnt4, "checkBoxGateAnt4");
            this.checkBoxGateAnt4.Name = "checkBoxGateAnt4";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt4, resources.GetString("checkBoxGateAnt4.ToolTip"));
            this.checkBoxGateAnt4.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt3
            // 
            resources.ApplyResources(this.checkBoxGateAnt3, "checkBoxGateAnt3");
            this.checkBoxGateAnt3.Name = "checkBoxGateAnt3";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt3, resources.GetString("checkBoxGateAnt3.ToolTip"));
            this.checkBoxGateAnt3.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt2
            // 
            resources.ApplyResources(this.checkBoxGateAnt2, "checkBoxGateAnt2");
            this.checkBoxGateAnt2.Name = "checkBoxGateAnt2";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt2, resources.GetString("checkBoxGateAnt2.ToolTip"));
            this.checkBoxGateAnt2.UseVisualStyleBackColor = true;
            // 
            // checkBoxGateAnt1
            // 
            resources.ApplyResources(this.checkBoxGateAnt1, "checkBoxGateAnt1");
            this.checkBoxGateAnt1.Checked = true;
            this.checkBoxGateAnt1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxGateAnt1.Name = "checkBoxGateAnt1";
            this.toolTipIso15693.SetToolTip(this.checkBoxGateAnt1, resources.GetString("checkBoxGateAnt1.ToolTip"));
            this.checkBoxGateAnt1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.buttonClearInfo);
            this.groupBox2.Controls.Add(this.textBoxInf);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox2, resources.GetString("groupBox2.ToolTip"));
            // 
            // buttonClearInfo
            // 
            resources.ApplyResources(this.buttonClearInfo, "buttonClearInfo");
            this.buttonClearInfo.Name = "buttonClearInfo";
            this.toolTipIso15693.SetToolTip(this.buttonClearInfo, resources.GetString("buttonClearInfo.ToolTip"));
            this.buttonClearInfo.UseVisualStyleBackColor = true;
            this.buttonClearInfo.Click += new System.EventHandler(this.buttonClearInfo_Click);
            // 
            // textBoxInf
            // 
            resources.ApplyResources(this.textBoxInf, "textBoxInf");
            this.textBoxInf.Name = "textBoxInf";
            this.toolTipIso15693.SetToolTip(this.textBoxInf, resources.GetString("textBoxInf.ToolTip"));
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            this.toolTipIso15693.SetToolTip(this.label32, resources.GetString("label32.ToolTip"));
            // 
            // textBoxDestAddr
            // 
            resources.ApplyResources(this.textBoxDestAddr, "textBoxDestAddr");
            this.textBoxDestAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDestAddr.Name = "textBoxDestAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxDestAddr, resources.GetString("textBoxDestAddr.ToolTip"));
            // 
            // textBoxSrcAddr
            // 
            resources.ApplyResources(this.textBoxSrcAddr, "textBoxSrcAddr");
            this.textBoxSrcAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxSrcAddr.Name = "textBoxSrcAddr";
            this.toolTipIso15693.SetToolTip(this.textBoxSrcAddr, resources.GetString("textBoxSrcAddr.ToolTip"));
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.Name = "label33";
            this.toolTipIso15693.SetToolTip(this.label33, resources.GetString("label33.ToolTip"));
            // 
            // groupBox13
            // 
            resources.ApplyResources(this.groupBox13, "groupBox13");
            this.groupBox13.Controls.Add(this.textBoxSelectedIso15693Uid);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.TabStop = false;
            this.toolTipIso15693.SetToolTip(this.groupBox13, resources.GetString("groupBox13.ToolTip"));
            // 
            // textBoxSelectedIso15693Uid
            // 
            resources.ApplyResources(this.textBoxSelectedIso15693Uid, "textBoxSelectedIso15693Uid");
            this.textBoxSelectedIso15693Uid.Name = "textBoxSelectedIso15693Uid";
            this.toolTipIso15693.SetToolTip(this.textBoxSelectedIso15693Uid, resources.GetString("textBoxSelectedIso15693Uid.ToolTip"));
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Name = "textBox1";
            this.toolTipIso15693.SetToolTip(this.textBox1, resources.GetString("textBox1.ToolTip"));
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Name = "textBox2";
            this.toolTipIso15693.SetToolTip(this.textBox2, resources.GetString("textBox2.ToolTip"));
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox3.Name = "textBox3";
            this.toolTipIso15693.SetToolTip(this.textBox3, resources.GetString("textBox3.ToolTip"));
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.toolTipIso15693.SetToolTip(this.textBox4, resources.GetString("textBox4.ToolTip"));
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.checkBox1.Name = "checkBox1";
            this.toolTipIso15693.SetToolTip(this.checkBox1, resources.GetString("checkBox1.ToolTip"));
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.toolTipIso15693.SetToolTip(this.button1, resources.GetString("button1.ToolTip"));
            this.button1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            resources.ApplyResources(this.checkBox2, "checkBox2");
            this.checkBox2.Name = "checkBox2";
            this.toolTipIso15693.SetToolTip(this.checkBox2, resources.GetString("checkBox2.ToolTip"));
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox5.Name = "textBox5";
            this.toolTipIso15693.SetToolTip(this.textBox5, resources.GetString("textBox5.ToolTip"));
            // 
            // textBox6
            // 
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox6.Name = "textBox6";
            this.toolTipIso15693.SetToolTip(this.textBox6, resources.GetString("textBox6.ToolTip"));
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            this.toolTipIso15693.SetToolTip(this.label28, resources.GetString("label28.ToolTip"));
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            this.toolTipIso15693.SetToolTip(this.label29, resources.GetString("label29.ToolTip"));
            // 
            // textBox7
            // 
            resources.ApplyResources(this.textBox7, "textBox7");
            this.textBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox7.Name = "textBox7";
            this.toolTipIso15693.SetToolTip(this.textBox7, resources.GetString("textBox7.ToolTip"));
            // 
            // textBox8
            // 
            resources.ApplyResources(this.textBox8, "textBox8");
            this.textBox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox8.Name = "textBox8";
            this.toolTipIso15693.SetToolTip(this.textBox8, resources.GetString("textBox8.ToolTip"));
            // 
            // textBox9
            // 
            resources.ApplyResources(this.textBox9, "textBox9");
            this.textBox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox9.Name = "textBox9";
            this.toolTipIso15693.SetToolTip(this.textBox9, resources.GetString("textBox9.ToolTip"));
            // 
            // textBox10
            // 
            resources.ApplyResources(this.textBox10, "textBox10");
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.toolTipIso15693.SetToolTip(this.textBox10, resources.GetString("textBox10.ToolTip"));
            // 
            // checkBox3
            // 
            resources.ApplyResources(this.checkBox3, "checkBox3");
            this.checkBox3.Name = "checkBox3";
            this.toolTipIso15693.SetToolTip(this.checkBox3, resources.GetString("checkBox3.ToolTip"));
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.toolTipIso15693.SetToolTip(this.button2, resources.GetString("button2.ToolTip"));
            this.button2.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            resources.ApplyResources(this.checkBox4, "checkBox4");
            this.checkBox4.Name = "checkBox4";
            this.toolTipIso15693.SetToolTip(this.checkBox4, resources.GetString("checkBox4.ToolTip"));
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // textBox11
            // 
            resources.ApplyResources(this.textBox11, "textBox11");
            this.textBox11.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox11.Name = "textBox11";
            this.toolTipIso15693.SetToolTip(this.textBox11, resources.GetString("textBox11.ToolTip"));
            // 
            // textBox12
            // 
            resources.ApplyResources(this.textBox12, "textBox12");
            this.textBox12.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox12.Name = "textBox12";
            this.toolTipIso15693.SetToolTip(this.textBox12, resources.GetString("textBox12.ToolTip"));
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            this.toolTipIso15693.SetToolTip(this.label30, resources.GetString("label30.ToolTip"));
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            this.toolTipIso15693.SetToolTip(this.label31, resources.GetString("label31.ToolTip"));
            // 
            // ISO15693
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.tabControlISO15693TagOp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ISO15693";
            this.toolTipIso15693.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ISO15693_FormClosing);
            this.tabControlISO15693TagOp.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBoxGetUid.ResumeLayout(false);
            this.groupBoxGetUid.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBoxBlocks.ResumeLayout(false);
            this.groupBoxBlocks.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBoxTagInfo.ResumeLayout(false);
            this.groupBoxTagInfo.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBoxTagParam.ResumeLayout(false);
            this.groupBoxTagParam.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlISO15693TagOp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxInf;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonCtrlAfi;
        private System.Windows.Forms.GroupBox groupBoxTagParam;
        private System.Windows.Forms.Button buttonCtrlEas;
        private System.Windows.Forms.RadioButton radioButtonLockEAS;
        private System.Windows.Forms.RadioButton radioButtonResetEAS;
        private System.Windows.Forms.RadioButton radioButtonSetEAS;
        private System.Windows.Forms.RadioButton radioButtonLockDSFID;
        private System.Windows.Forms.RadioButton radioButtonWriteDSFID;
        private System.Windows.Forms.RadioButton radioButtonLockAFI;
        private System.Windows.Forms.RadioButton radioButtonWriteAFI;
        private System.Windows.Forms.TextBox textBoxAFIValue;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxDSFIDValue;
        private System.Windows.Forms.Button buttonCtrlDsfid;
        private System.Windows.Forms.GroupBox groupBoxTagInfo;
        private System.Windows.Forms.TextBox textBoxTagInfICRef;
        private System.Windows.Forms.TextBox textBoxTagInfBlockSize;
        private System.Windows.Forms.TextBox textBoxTagInfBlockNum;
        private System.Windows.Forms.TextBox textBoxTagInfAFI;
        private System.Windows.Forms.TextBox textBoxTagInfDSFID;
        private System.Windows.Forms.TextBox textBoxTagInfFlag;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button buttonReadTagInf;
        private System.Windows.Forms.Button buttonClearTagInfo;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBoxDestAddr;
        private System.Windows.Forms.TextBox textBoxSrcAddr;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBoxSelectedIso15693Uid;
        private System.Windows.Forms.Button buttonClearInfo;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBoxBlocks;
        private System.Windows.Forms.TextBox textBoxRMBlockNum;
        private System.Windows.Forms.TextBox textBoxRMBlockAddr;
        private System.Windows.Forms.Button buttonClearRMultBlock;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxRMBlockData;
        private System.Windows.Forms.Button buttonReadMBlock;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBoxWMBlockNum;
        private System.Windows.Forms.TextBox textBoxWMBlockAddr;
        private System.Windows.Forms.Button buttonClearWMBlock;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBoxWMBlockData;
        private System.Windows.Forms.Button buttonWriteMBlock;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonClearLockBlock;
        private System.Windows.Forms.TextBox textBoxLBlockAddr;
        private System.Windows.Forms.Button buttonLockBlock;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBoxGetUid;
        private System.Windows.Forms.TextBox textBoxRemainTagNum;
        private System.Windows.Forms.TextBox textBoxReadTagNum;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonClearListBox;
        private System.Windows.Forms.Button buttonReadTags;
        private System.Windows.Forms.ListBox listBoxUID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button buttonDtuRxClear;
        private System.Windows.Forms.Button buttonDtuTxClear;
        private System.Windows.Forms.TextBox textBoxDtuRx;
        private System.Windows.Forms.TextBox textBoxDtuTx;
        private System.Windows.Forms.Button buttonDtu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxDtuTime;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxDtuRxLen;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button buttonOpTagStart;
        private System.Windows.Forms.TextBox textBoxOpTagInfo;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox textBoxImTagInfo;
        private System.Windows.Forms.Button buttonImOpStart;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBoxImOpMode;
        private System.Windows.Forms.TextBox textBoxImOpBlockAddr;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox comboBoxImOpAnt;
        private System.Windows.Forms.ComboBox comboBoxOpTag;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.CheckBox checkBoxGateAnt1;
        private System.Windows.Forms.CheckBox checkBoxGateAnt8;
        private System.Windows.Forms.CheckBox checkBoxGateAnt7;
        private System.Windows.Forms.CheckBox checkBoxGateAnt6;
        private System.Windows.Forms.CheckBox checkBoxGateAnt5;
        private System.Windows.Forms.CheckBox checkBoxGateAnt4;
        private System.Windows.Forms.CheckBox checkBoxGateAnt3;
        private System.Windows.Forms.CheckBox checkBoxGateAnt2;
        private System.Windows.Forms.Button buttonSetScanAnts;
        private System.Windows.Forms.ComboBox comboBoxEnableGateMode;
        private System.Windows.Forms.Button buttonSetGateMode;
        private System.Windows.Forms.Button buttonStartRcvGateAlarmUid;
        private System.Windows.Forms.TextBox textBoxGateAlarmUid;
        private System.Windows.Forms.TextBox comboBoxImOpAntAddr;
        private System.Windows.Forms.ToolTip toolTipIso15693;
        private System.Windows.Forms.TextBox textBoxDirOpBlockAddr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBoxWaitTime;
    }
}