namespace RFIDStation
{
    partial class RFIDStation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RFIDStation));
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxDestAddr = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panelNetParams = new System.Windows.Forms.Panel();
            this.comboBoxNetDevicePortList = new System.Windows.Forms.ComboBox();
            this.comboBoxNetDeviceIpList = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.comboBoxUsbList = new System.Windows.Forms.ComboBox();
            this.labelUsbList = new System.Windows.Forms.Label();
            this.comboBoxComInterface = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.buttonOpenSerial = new System.Windows.Forms.Button();
            this.comboBoxBaudrate = new System.Windows.Forms.ComboBox();
            this.comboBoxComPort = new System.Windows.Forms.ComboBox();
            this.labelBr = new System.Windows.Forms.Label();
            this.labelCom = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.radioButtonFelica = new System.Windows.Forms.RadioButton();
            this.radioButtonISO14443B = new System.Windows.Forms.RadioButton();
            this.radioButtonISO15693 = new System.Windows.Forms.RadioButton();
            this.radioButtonISO14443A = new System.Windows.Forms.RadioButton();
            this.buttonReadConfiguration = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.radioButtonBeepModeDisable = new System.Windows.Forms.RadioButton();
            this.radioButtonBeepModeEnable = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButtonBR9600 = new System.Windows.Forms.RadioButton();
            this.radioButtonBR38400 = new System.Windows.Forms.RadioButton();
            this.radioButtonBR115200 = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButtonTagModeQuiet = new System.Windows.Forms.RadioButton();
            this.radioButtonTagModeUnquiet = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButtonAFIModeDisable = new System.Windows.Forms.RadioButton();
            this.textBoxAFI = new System.Windows.Forms.TextBox();
            this.radioButtonAFIModeEnable = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonCmdModeTrigle = new System.Windows.Forms.RadioButton();
            this.radioButtonCmdModeAuto = new System.Windows.Forms.RadioButton();
            this.buttonConfigReader = new System.Windows.Forms.Button();
            this.textBoxReaderAddr = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.buttonRFControl = new System.Windows.Forms.Button();
            this.radioButtonRFReset = new System.Windows.Forms.RadioButton();
            this.radioButtonRFOpen = new System.Windows.Forms.RadioButton();
            this.radioButtonRFClose = new System.Windows.Forms.RadioButton();
            this.tabControlDevice = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBoxBr = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBoxTagQuit = new System.Windows.Forms.GroupBox();
            this.groupBoxAFIMode = new System.Windows.Forms.GroupBox();
            this.groupBoxCmdMode = new System.Windows.Forms.GroupBox();
            this.groupBoxProtocol = new System.Windows.Forms.GroupBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBoxSetPower = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBoxAntPower = new System.Windows.Forms.ComboBox();
            this.comboBoxCtrlPwrAntIndex = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.buttonCtrlPwr = new System.Windows.Forms.Button();
            this.groupBoxSelectAnt = new System.Windows.Forms.GroupBox();
            this.comboBoxAntCurIndex = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.comboBoxAntNum = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.buttonCtrlAnt = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.textBoxGDeviceHv = new System.Windows.Forms.TextBox();
            this.buttonGetV = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxGDeviceSv = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBoxGDeviceType = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBoxTagType = new System.Windows.Forms.ComboBox();
            this.groupBoxTool = new System.Windows.Forms.GroupBox();
            this.comboBoxTool = new System.Windows.Forms.ComboBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.comboBoxTagOp = new System.Windows.Forms.ComboBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.buttonClearInfo = new System.Windows.Forms.Button();
            this.statusStripInfo = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelCom = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelBr = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelWarn = new System.Windows.Forms.ToolStripStatusLabel();
            this.textBoxInf = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBoxLang = new System.Windows.Forms.ComboBox();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelNetParams.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tabControlDevice.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBoxBr.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBoxTagQuit.SuspendLayout();
            this.groupBoxAFIMode.SuspendLayout();
            this.groupBoxCmdMode.SuspendLayout();
            this.groupBoxProtocol.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBoxSetPower.SuspendLayout();
            this.groupBoxSelectAnt.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBoxTool.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.statusStripInfo.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.textBoxDestAddr);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // textBoxDestAddr
            // 
            resources.ApplyResources(this.textBoxDestAddr, "textBoxDestAddr");
            this.textBoxDestAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxDestAddr.Name = "textBoxDestAddr";
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.panelNetParams);
            this.groupBox1.Controls.Add(this.comboBoxUsbList);
            this.groupBox1.Controls.Add(this.labelUsbList);
            this.groupBox1.Controls.Add(this.comboBoxComInterface);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.buttonOpenSerial);
            this.groupBox1.Controls.Add(this.comboBoxBaudrate);
            this.groupBox1.Controls.Add(this.comboBoxComPort);
            this.groupBox1.Controls.Add(this.labelBr);
            this.groupBox1.Controls.Add(this.labelCom);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // panelNetParams
            // 
            resources.ApplyResources(this.panelNetParams, "panelNetParams");
            this.panelNetParams.Controls.Add(this.comboBoxNetDevicePortList);
            this.panelNetParams.Controls.Add(this.comboBoxNetDeviceIpList);
            this.panelNetParams.Controls.Add(this.label71);
            this.panelNetParams.Controls.Add(this.label70);
            this.panelNetParams.Name = "panelNetParams";
            // 
            // comboBoxNetDevicePortList
            // 
            resources.ApplyResources(this.comboBoxNetDevicePortList, "comboBoxNetDevicePortList");
            this.comboBoxNetDevicePortList.FormattingEnabled = true;
            this.comboBoxNetDevicePortList.Name = "comboBoxNetDevicePortList";
            this.comboBoxNetDevicePortList.SelectedIndexChanged += new System.EventHandler(this.comboBoxNetDevicePortList_SelectedIndexChanged);
            // 
            // comboBoxNetDeviceIpList
            // 
            resources.ApplyResources(this.comboBoxNetDeviceIpList, "comboBoxNetDeviceIpList");
            this.comboBoxNetDeviceIpList.FormattingEnabled = true;
            this.comboBoxNetDeviceIpList.Name = "comboBoxNetDeviceIpList";
            this.comboBoxNetDeviceIpList.SelectedIndexChanged += new System.EventHandler(this.comboBoxNetDeviceIpList_SelectedIndexChanged);
            // 
            // label71
            // 
            resources.ApplyResources(this.label71, "label71");
            this.label71.Name = "label71";
            // 
            // label70
            // 
            resources.ApplyResources(this.label70, "label70");
            this.label70.Name = "label70";
            // 
            // comboBoxUsbList
            // 
            resources.ApplyResources(this.comboBoxUsbList, "comboBoxUsbList");
            this.comboBoxUsbList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUsbList.FormattingEnabled = true;
            this.comboBoxUsbList.Name = "comboBoxUsbList";
            this.comboBoxUsbList.SelectedIndexChanged += new System.EventHandler(this.comboBoxUsbList_SelectedIndexChanged);
            // 
            // labelUsbList
            // 
            resources.ApplyResources(this.labelUsbList, "labelUsbList");
            this.labelUsbList.Name = "labelUsbList";
            // 
            // comboBoxComInterface
            // 
            resources.ApplyResources(this.comboBoxComInterface, "comboBoxComInterface");
            this.comboBoxComInterface.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxComInterface.FormattingEnabled = true;
            this.comboBoxComInterface.Items.AddRange(new object[] {
            resources.GetString("comboBoxComInterface.Items"),
            resources.GetString("comboBoxComInterface.Items1"),
            resources.GetString("comboBoxComInterface.Items2")});
            this.comboBoxComInterface.Name = "comboBoxComInterface";
            this.comboBoxComInterface.SelectedIndexChanged += new System.EventHandler(this.comboBoxComInterface_SelectedIndexChanged);
            // 
            // label42
            // 
            resources.ApplyResources(this.label42, "label42");
            this.label42.Name = "label42";
            // 
            // buttonOpenSerial
            // 
            resources.ApplyResources(this.buttonOpenSerial, "buttonOpenSerial");
            this.buttonOpenSerial.Name = "buttonOpenSerial";
            this.buttonOpenSerial.UseVisualStyleBackColor = true;
            this.buttonOpenSerial.Click += new System.EventHandler(this.buttonOpenSerial_Click);
            // 
            // comboBoxBaudrate
            // 
            resources.ApplyResources(this.comboBoxBaudrate, "comboBoxBaudrate");
            this.comboBoxBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBaudrate.FormattingEnabled = true;
            this.comboBoxBaudrate.Items.AddRange(new object[] {
            resources.GetString("comboBoxBaudrate.Items"),
            resources.GetString("comboBoxBaudrate.Items1"),
            resources.GetString("comboBoxBaudrate.Items2")});
            this.comboBoxBaudrate.Name = "comboBoxBaudrate";
            this.comboBoxBaudrate.SelectedIndexChanged += new System.EventHandler(this.comboBoxBaudrate_SelectedIndexChanged);
            // 
            // comboBoxComPort
            // 
            resources.ApplyResources(this.comboBoxComPort, "comboBoxComPort");
            this.comboBoxComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxComPort.FormattingEnabled = true;
            this.comboBoxComPort.Items.AddRange(new object[] {
            resources.GetString("comboBoxComPort.Items"),
            resources.GetString("comboBoxComPort.Items1"),
            resources.GetString("comboBoxComPort.Items2"),
            resources.GetString("comboBoxComPort.Items3"),
            resources.GetString("comboBoxComPort.Items4"),
            resources.GetString("comboBoxComPort.Items5"),
            resources.GetString("comboBoxComPort.Items6"),
            resources.GetString("comboBoxComPort.Items7"),
            resources.GetString("comboBoxComPort.Items8"),
            resources.GetString("comboBoxComPort.Items9"),
            resources.GetString("comboBoxComPort.Items10"),
            resources.GetString("comboBoxComPort.Items11"),
            resources.GetString("comboBoxComPort.Items12"),
            resources.GetString("comboBoxComPort.Items13"),
            resources.GetString("comboBoxComPort.Items14"),
            resources.GetString("comboBoxComPort.Items15"),
            resources.GetString("comboBoxComPort.Items16"),
            resources.GetString("comboBoxComPort.Items17")});
            this.comboBoxComPort.Name = "comboBoxComPort";
            this.comboBoxComPort.DropDown += new System.EventHandler(this.comboBoxComPort_DropDown);
            this.comboBoxComPort.SelectedIndexChanged += new System.EventHandler(this.comboBoxComPort_SelectedIndexChanged);
            // 
            // labelBr
            // 
            resources.ApplyResources(this.labelBr, "labelBr");
            this.labelBr.Name = "labelBr";
            // 
            // labelCom
            // 
            resources.ApplyResources(this.labelCom, "labelCom");
            this.labelCom.Name = "labelCom";
            // 
            // panel12
            // 
            resources.ApplyResources(this.panel12, "panel12");
            this.panel12.Controls.Add(this.radioButtonFelica);
            this.panel12.Controls.Add(this.radioButtonISO14443B);
            this.panel12.Controls.Add(this.radioButtonISO15693);
            this.panel12.Controls.Add(this.radioButtonISO14443A);
            this.panel12.Name = "panel12";
            // 
            // radioButtonFelica
            // 
            resources.ApplyResources(this.radioButtonFelica, "radioButtonFelica");
            this.radioButtonFelica.Name = "radioButtonFelica";
            this.radioButtonFelica.UseVisualStyleBackColor = true;
            this.radioButtonFelica.CheckedChanged += new System.EventHandler(this.radioButtonFelica_CheckedChanged);
            // 
            // radioButtonISO14443B
            // 
            resources.ApplyResources(this.radioButtonISO14443B, "radioButtonISO14443B");
            this.radioButtonISO14443B.Name = "radioButtonISO14443B";
            this.radioButtonISO14443B.UseVisualStyleBackColor = true;
            this.radioButtonISO14443B.CheckedChanged += new System.EventHandler(this.radioButtonISO14443B_CheckedChanged);
            // 
            // radioButtonISO15693
            // 
            resources.ApplyResources(this.radioButtonISO15693, "radioButtonISO15693");
            this.radioButtonISO15693.Checked = true;
            this.radioButtonISO15693.Name = "radioButtonISO15693";
            this.radioButtonISO15693.TabStop = true;
            this.radioButtonISO15693.UseVisualStyleBackColor = true;
            this.radioButtonISO15693.CheckedChanged += new System.EventHandler(this.radioButtonISO15693_CheckedChanged);
            // 
            // radioButtonISO14443A
            // 
            resources.ApplyResources(this.radioButtonISO14443A, "radioButtonISO14443A");
            this.radioButtonISO14443A.Name = "radioButtonISO14443A";
            this.radioButtonISO14443A.UseVisualStyleBackColor = true;
            this.radioButtonISO14443A.CheckedChanged += new System.EventHandler(this.radioButtonISO14443A_CheckedChanged);
            // 
            // buttonReadConfiguration
            // 
            resources.ApplyResources(this.buttonReadConfiguration, "buttonReadConfiguration");
            this.buttonReadConfiguration.Name = "buttonReadConfiguration";
            this.buttonReadConfiguration.UseVisualStyleBackColor = true;
            this.buttonReadConfiguration.Click += new System.EventHandler(this.buttonReadConfiguration_Click);
            // 
            // panel9
            // 
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Controls.Add(this.radioButtonBeepModeDisable);
            this.panel9.Controls.Add(this.radioButtonBeepModeEnable);
            this.panel9.Name = "panel9";
            // 
            // radioButtonBeepModeDisable
            // 
            resources.ApplyResources(this.radioButtonBeepModeDisable, "radioButtonBeepModeDisable");
            this.radioButtonBeepModeDisable.Name = "radioButtonBeepModeDisable";
            this.radioButtonBeepModeDisable.UseVisualStyleBackColor = true;
            // 
            // radioButtonBeepModeEnable
            // 
            resources.ApplyResources(this.radioButtonBeepModeEnable, "radioButtonBeepModeEnable");
            this.radioButtonBeepModeEnable.Checked = true;
            this.radioButtonBeepModeEnable.Name = "radioButtonBeepModeEnable";
            this.radioButtonBeepModeEnable.TabStop = true;
            this.radioButtonBeepModeEnable.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Controls.Add(this.radioButtonBR9600);
            this.panel8.Controls.Add(this.radioButtonBR38400);
            this.panel8.Controls.Add(this.radioButtonBR115200);
            this.panel8.Name = "panel8";
            // 
            // radioButtonBR9600
            // 
            resources.ApplyResources(this.radioButtonBR9600, "radioButtonBR9600");
            this.radioButtonBR9600.Name = "radioButtonBR9600";
            this.radioButtonBR9600.UseVisualStyleBackColor = true;
            // 
            // radioButtonBR38400
            // 
            resources.ApplyResources(this.radioButtonBR38400, "radioButtonBR38400");
            this.radioButtonBR38400.Checked = true;
            this.radioButtonBR38400.Name = "radioButtonBR38400";
            this.radioButtonBR38400.TabStop = true;
            this.radioButtonBR38400.UseVisualStyleBackColor = true;
            // 
            // radioButtonBR115200
            // 
            resources.ApplyResources(this.radioButtonBR115200, "radioButtonBR115200");
            this.radioButtonBR115200.Name = "radioButtonBR115200";
            this.radioButtonBR115200.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.radioButtonTagModeQuiet);
            this.panel5.Controls.Add(this.radioButtonTagModeUnquiet);
            this.panel5.Name = "panel5";
            // 
            // panel7
            // 
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // radioButtonTagModeQuiet
            // 
            resources.ApplyResources(this.radioButtonTagModeQuiet, "radioButtonTagModeQuiet");
            this.radioButtonTagModeQuiet.Checked = true;
            this.radioButtonTagModeQuiet.Name = "radioButtonTagModeQuiet";
            this.radioButtonTagModeQuiet.TabStop = true;
            this.radioButtonTagModeQuiet.UseVisualStyleBackColor = true;
            // 
            // radioButtonTagModeUnquiet
            // 
            resources.ApplyResources(this.radioButtonTagModeUnquiet, "radioButtonTagModeUnquiet");
            this.radioButtonTagModeUnquiet.Name = "radioButtonTagModeUnquiet";
            this.radioButtonTagModeUnquiet.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.radioButtonAFIModeDisable);
            this.panel3.Controls.Add(this.textBoxAFI);
            this.panel3.Controls.Add(this.radioButtonAFIModeEnable);
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // radioButtonAFIModeDisable
            // 
            resources.ApplyResources(this.radioButtonAFIModeDisable, "radioButtonAFIModeDisable");
            this.radioButtonAFIModeDisable.Checked = true;
            this.radioButtonAFIModeDisable.Name = "radioButtonAFIModeDisable";
            this.radioButtonAFIModeDisable.TabStop = true;
            this.radioButtonAFIModeDisable.UseVisualStyleBackColor = true;
            // 
            // textBoxAFI
            // 
            resources.ApplyResources(this.textBoxAFI, "textBoxAFI");
            this.textBoxAFI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxAFI.Name = "textBoxAFI";
            // 
            // radioButtonAFIModeEnable
            // 
            resources.ApplyResources(this.radioButtonAFIModeEnable, "radioButtonAFIModeEnable");
            this.radioButtonAFIModeEnable.Name = "radioButtonAFIModeEnable";
            this.radioButtonAFIModeEnable.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.radioButtonCmdModeTrigle);
            this.panel2.Controls.Add(this.radioButtonCmdModeAuto);
            this.panel2.Name = "panel2";
            // 
            // radioButtonCmdModeTrigle
            // 
            resources.ApplyResources(this.radioButtonCmdModeTrigle, "radioButtonCmdModeTrigle");
            this.radioButtonCmdModeTrigle.Name = "radioButtonCmdModeTrigle";
            this.radioButtonCmdModeTrigle.UseVisualStyleBackColor = true;
            // 
            // radioButtonCmdModeAuto
            // 
            resources.ApplyResources(this.radioButtonCmdModeAuto, "radioButtonCmdModeAuto");
            this.radioButtonCmdModeAuto.Checked = true;
            this.radioButtonCmdModeAuto.Name = "radioButtonCmdModeAuto";
            this.radioButtonCmdModeAuto.TabStop = true;
            this.radioButtonCmdModeAuto.UseVisualStyleBackColor = true;
            this.radioButtonCmdModeAuto.CheckedChanged += new System.EventHandler(this.radioButtonCmdModeAuto_CheckedChanged);
            // 
            // buttonConfigReader
            // 
            resources.ApplyResources(this.buttonConfigReader, "buttonConfigReader");
            this.buttonConfigReader.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonConfigReader.Name = "buttonConfigReader";
            this.buttonConfigReader.UseVisualStyleBackColor = true;
            this.buttonConfigReader.Click += new System.EventHandler(this.buttonConfigReader_Click);
            // 
            // textBoxReaderAddr
            // 
            resources.ApplyResources(this.textBoxReaderAddr, "textBoxReaderAddr");
            this.textBoxReaderAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxReaderAddr.Name = "textBoxReaderAddr";
            // 
            // groupBox14
            // 
            resources.ApplyResources(this.groupBox14, "groupBox14");
            this.groupBox14.Controls.Add(this.buttonRFControl);
            this.groupBox14.Controls.Add(this.radioButtonRFReset);
            this.groupBox14.Controls.Add(this.radioButtonRFOpen);
            this.groupBox14.Controls.Add(this.radioButtonRFClose);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.TabStop = false;
            // 
            // buttonRFControl
            // 
            resources.ApplyResources(this.buttonRFControl, "buttonRFControl");
            this.buttonRFControl.Name = "buttonRFControl";
            this.buttonRFControl.UseVisualStyleBackColor = true;
            this.buttonRFControl.Click += new System.EventHandler(this.buttonRFControl_Click);
            // 
            // radioButtonRFReset
            // 
            resources.ApplyResources(this.radioButtonRFReset, "radioButtonRFReset");
            this.radioButtonRFReset.Name = "radioButtonRFReset";
            this.radioButtonRFReset.UseVisualStyleBackColor = true;
            // 
            // radioButtonRFOpen
            // 
            resources.ApplyResources(this.radioButtonRFOpen, "radioButtonRFOpen");
            this.radioButtonRFOpen.Name = "radioButtonRFOpen";
            this.radioButtonRFOpen.UseVisualStyleBackColor = true;
            // 
            // radioButtonRFClose
            // 
            resources.ApplyResources(this.radioButtonRFClose, "radioButtonRFClose");
            this.radioButtonRFClose.Checked = true;
            this.radioButtonRFClose.Name = "radioButtonRFClose";
            this.radioButtonRFClose.TabStop = true;
            this.radioButtonRFClose.UseVisualStyleBackColor = true;
            // 
            // tabControlDevice
            // 
            resources.ApplyResources(this.tabControlDevice, "tabControlDevice");
            this.tabControlDevice.Controls.Add(this.tabPage1);
            this.tabControlDevice.Controls.Add(this.tabPage2);
            this.tabControlDevice.Controls.Add(this.tabPage4);
            this.tabControlDevice.Name = "tabControlDevice";
            this.tabControlDevice.SelectedIndex = 0;
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Controls.Add(this.groupBox13);
            this.tabPage1.Controls.Add(this.groupBoxBr);
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.groupBoxTagQuit);
            this.tabPage1.Controls.Add(this.groupBoxAFIMode);
            this.tabPage1.Controls.Add(this.groupBoxCmdMode);
            this.tabPage1.Controls.Add(this.groupBoxProtocol);
            this.tabPage1.Controls.Add(this.buttonConfigReader);
            this.tabPage1.Controls.Add(this.buttonReadConfiguration);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            resources.ApplyResources(this.groupBox13, "groupBox13");
            this.groupBox13.Controls.Add(this.textBoxReaderAddr);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.TabStop = false;
            // 
            // groupBoxBr
            // 
            resources.ApplyResources(this.groupBoxBr, "groupBoxBr");
            this.groupBoxBr.Controls.Add(this.panel8);
            this.groupBoxBr.Name = "groupBoxBr";
            this.groupBoxBr.TabStop = false;
            // 
            // groupBox11
            // 
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Controls.Add(this.panel9);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // groupBoxTagQuit
            // 
            resources.ApplyResources(this.groupBoxTagQuit, "groupBoxTagQuit");
            this.groupBoxTagQuit.Controls.Add(this.panel5);
            this.groupBoxTagQuit.Name = "groupBoxTagQuit";
            this.groupBoxTagQuit.TabStop = false;
            // 
            // groupBoxAFIMode
            // 
            resources.ApplyResources(this.groupBoxAFIMode, "groupBoxAFIMode");
            this.groupBoxAFIMode.Controls.Add(this.panel3);
            this.groupBoxAFIMode.Name = "groupBoxAFIMode";
            this.groupBoxAFIMode.TabStop = false;
            // 
            // groupBoxCmdMode
            // 
            resources.ApplyResources(this.groupBoxCmdMode, "groupBoxCmdMode");
            this.groupBoxCmdMode.Controls.Add(this.panel2);
            this.groupBoxCmdMode.Name = "groupBoxCmdMode";
            this.groupBoxCmdMode.TabStop = false;
            // 
            // groupBoxProtocol
            // 
            resources.ApplyResources(this.groupBoxProtocol, "groupBoxProtocol");
            this.groupBoxProtocol.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxProtocol.Controls.Add(this.panel12);
            this.groupBoxProtocol.Name = "groupBoxProtocol";
            this.groupBoxProtocol.TabStop = false;
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Controls.Add(this.groupBoxSetPower);
            this.tabPage2.Controls.Add(this.groupBoxSelectAnt);
            this.tabPage2.Controls.Add(this.groupBox14);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBoxSetPower
            // 
            resources.ApplyResources(this.groupBoxSetPower, "groupBoxSetPower");
            this.groupBoxSetPower.Controls.Add(this.label38);
            this.groupBoxSetPower.Controls.Add(this.comboBoxAntPower);
            this.groupBoxSetPower.Controls.Add(this.comboBoxCtrlPwrAntIndex);
            this.groupBoxSetPower.Controls.Add(this.label37);
            this.groupBoxSetPower.Controls.Add(this.buttonCtrlPwr);
            this.groupBoxSetPower.Name = "groupBoxSetPower";
            this.groupBoxSetPower.TabStop = false;
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.Name = "label38";
            // 
            // comboBoxAntPower
            // 
            resources.ApplyResources(this.comboBoxAntPower, "comboBoxAntPower");
            this.comboBoxAntPower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAntPower.FormattingEnabled = true;
            this.comboBoxAntPower.Items.AddRange(new object[] {
            resources.GetString("comboBoxAntPower.Items"),
            resources.GetString("comboBoxAntPower.Items1"),
            resources.GetString("comboBoxAntPower.Items2"),
            resources.GetString("comboBoxAntPower.Items3")});
            this.comboBoxAntPower.Name = "comboBoxAntPower";
            // 
            // comboBoxCtrlPwrAntIndex
            // 
            resources.ApplyResources(this.comboBoxCtrlPwrAntIndex, "comboBoxCtrlPwrAntIndex");
            this.comboBoxCtrlPwrAntIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCtrlPwrAntIndex.FormattingEnabled = true;
            this.comboBoxCtrlPwrAntIndex.Items.AddRange(new object[] {
            resources.GetString("comboBoxCtrlPwrAntIndex.Items"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items1"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items2"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items3"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items4"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items5"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items6"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items7"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items8"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items9"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items10"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items11"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items12"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items13"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items14"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items15"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items16"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items17"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items18"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items19"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items20"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items21"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items22"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items23"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items24"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items25"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items26"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items27"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items28"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items29"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items30"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items31"),
            resources.GetString("comboBoxCtrlPwrAntIndex.Items32")});
            this.comboBoxCtrlPwrAntIndex.Name = "comboBoxCtrlPwrAntIndex";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            // 
            // buttonCtrlPwr
            // 
            resources.ApplyResources(this.buttonCtrlPwr, "buttonCtrlPwr");
            this.buttonCtrlPwr.Name = "buttonCtrlPwr";
            this.buttonCtrlPwr.UseVisualStyleBackColor = true;
            this.buttonCtrlPwr.Click += new System.EventHandler(this.buttonCtrlPwr_Click);
            // 
            // groupBoxSelectAnt
            // 
            resources.ApplyResources(this.groupBoxSelectAnt, "groupBoxSelectAnt");
            this.groupBoxSelectAnt.Controls.Add(this.comboBoxAntCurIndex);
            this.groupBoxSelectAnt.Controls.Add(this.label51);
            this.groupBoxSelectAnt.Controls.Add(this.comboBoxAntNum);
            this.groupBoxSelectAnt.Controls.Add(this.label50);
            this.groupBoxSelectAnt.Controls.Add(this.buttonCtrlAnt);
            this.groupBoxSelectAnt.Name = "groupBoxSelectAnt";
            this.groupBoxSelectAnt.TabStop = false;
            // 
            // comboBoxAntCurIndex
            // 
            resources.ApplyResources(this.comboBoxAntCurIndex, "comboBoxAntCurIndex");
            this.comboBoxAntCurIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAntCurIndex.FormattingEnabled = true;
            this.comboBoxAntCurIndex.Items.AddRange(new object[] {
            resources.GetString("comboBoxAntCurIndex.Items"),
            resources.GetString("comboBoxAntCurIndex.Items1"),
            resources.GetString("comboBoxAntCurIndex.Items2"),
            resources.GetString("comboBoxAntCurIndex.Items3")});
            this.comboBoxAntCurIndex.Name = "comboBoxAntCurIndex";
            // 
            // label51
            // 
            resources.ApplyResources(this.label51, "label51");
            this.label51.Name = "label51";
            // 
            // comboBoxAntNum
            // 
            resources.ApplyResources(this.comboBoxAntNum, "comboBoxAntNum");
            this.comboBoxAntNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAntNum.FormattingEnabled = true;
            this.comboBoxAntNum.Items.AddRange(new object[] {
            resources.GetString("comboBoxAntNum.Items"),
            resources.GetString("comboBoxAntNum.Items1"),
            resources.GetString("comboBoxAntNum.Items2"),
            resources.GetString("comboBoxAntNum.Items3"),
            resources.GetString("comboBoxAntNum.Items4"),
            resources.GetString("comboBoxAntNum.Items5"),
            resources.GetString("comboBoxAntNum.Items6"),
            resources.GetString("comboBoxAntNum.Items7"),
            resources.GetString("comboBoxAntNum.Items8"),
            resources.GetString("comboBoxAntNum.Items9"),
            resources.GetString("comboBoxAntNum.Items10"),
            resources.GetString("comboBoxAntNum.Items11"),
            resources.GetString("comboBoxAntNum.Items12"),
            resources.GetString("comboBoxAntNum.Items13"),
            resources.GetString("comboBoxAntNum.Items14"),
            resources.GetString("comboBoxAntNum.Items15"),
            resources.GetString("comboBoxAntNum.Items16"),
            resources.GetString("comboBoxAntNum.Items17"),
            resources.GetString("comboBoxAntNum.Items18"),
            resources.GetString("comboBoxAntNum.Items19"),
            resources.GetString("comboBoxAntNum.Items20"),
            resources.GetString("comboBoxAntNum.Items21"),
            resources.GetString("comboBoxAntNum.Items22"),
            resources.GetString("comboBoxAntNum.Items23"),
            resources.GetString("comboBoxAntNum.Items24"),
            resources.GetString("comboBoxAntNum.Items25"),
            resources.GetString("comboBoxAntNum.Items26"),
            resources.GetString("comboBoxAntNum.Items27"),
            resources.GetString("comboBoxAntNum.Items28"),
            resources.GetString("comboBoxAntNum.Items29"),
            resources.GetString("comboBoxAntNum.Items30"),
            resources.GetString("comboBoxAntNum.Items31"),
            resources.GetString("comboBoxAntNum.Items32"),
            resources.GetString("comboBoxAntNum.Items33"),
            resources.GetString("comboBoxAntNum.Items34"),
            resources.GetString("comboBoxAntNum.Items35"),
            resources.GetString("comboBoxAntNum.Items36"),
            resources.GetString("comboBoxAntNum.Items37"),
            resources.GetString("comboBoxAntNum.Items38"),
            resources.GetString("comboBoxAntNum.Items39"),
            resources.GetString("comboBoxAntNum.Items40"),
            resources.GetString("comboBoxAntNum.Items41"),
            resources.GetString("comboBoxAntNum.Items42"),
            resources.GetString("comboBoxAntNum.Items43"),
            resources.GetString("comboBoxAntNum.Items44"),
            resources.GetString("comboBoxAntNum.Items45"),
            resources.GetString("comboBoxAntNum.Items46")});
            this.comboBoxAntNum.Name = "comboBoxAntNum";
            this.comboBoxAntNum.SelectedIndexChanged += new System.EventHandler(this.comboBoxAntNum_SelectedIndexChanged);
            // 
            // label50
            // 
            resources.ApplyResources(this.label50, "label50");
            this.label50.Name = "label50";
            // 
            // buttonCtrlAnt
            // 
            resources.ApplyResources(this.buttonCtrlAnt, "buttonCtrlAnt");
            this.buttonCtrlAnt.Name = "buttonCtrlAnt";
            this.buttonCtrlAnt.UseVisualStyleBackColor = true;
            this.buttonCtrlAnt.Click += new System.EventHandler(this.buttonCtrlAnt_Click);
            // 
            // tabPage4
            // 
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Controls.Add(this.groupBox33);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox33
            // 
            resources.ApplyResources(this.groupBox33, "groupBox33");
            this.groupBox33.Controls.Add(this.textBoxGDeviceHv);
            this.groupBox33.Controls.Add(this.buttonGetV);
            this.groupBox33.Controls.Add(this.label57);
            this.groupBox33.Controls.Add(this.textBoxGDeviceSv);
            this.groupBox33.Controls.Add(this.label58);
            this.groupBox33.Controls.Add(this.textBoxGDeviceType);
            this.groupBox33.Controls.Add(this.label59);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.TabStop = false;
            // 
            // textBoxGDeviceHv
            // 
            resources.ApplyResources(this.textBoxGDeviceHv, "textBoxGDeviceHv");
            this.textBoxGDeviceHv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxGDeviceHv.Name = "textBoxGDeviceHv";
            this.textBoxGDeviceHv.ReadOnly = true;
            // 
            // buttonGetV
            // 
            resources.ApplyResources(this.buttonGetV, "buttonGetV");
            this.buttonGetV.Name = "buttonGetV";
            this.buttonGetV.UseVisualStyleBackColor = true;
            this.buttonGetV.Click += new System.EventHandler(this.buttonGetV_Click);
            // 
            // label57
            // 
            resources.ApplyResources(this.label57, "label57");
            this.label57.Name = "label57";
            // 
            // textBoxGDeviceSv
            // 
            resources.ApplyResources(this.textBoxGDeviceSv, "textBoxGDeviceSv");
            this.textBoxGDeviceSv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxGDeviceSv.Name = "textBoxGDeviceSv";
            this.textBoxGDeviceSv.ReadOnly = true;
            // 
            // label58
            // 
            resources.ApplyResources(this.label58, "label58");
            this.label58.Name = "label58";
            // 
            // textBoxGDeviceType
            // 
            resources.ApplyResources(this.textBoxGDeviceType, "textBoxGDeviceType");
            this.textBoxGDeviceType.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxGDeviceType.Name = "textBoxGDeviceType";
            this.textBoxGDeviceType.ReadOnly = true;
            // 
            // label59
            // 
            resources.ApplyResources(this.label59, "label59");
            this.label59.Name = "label59";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            resources.ApplyResources(this.radioButton2, "radioButton2");
            this.radioButton2.Checked = true;
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Name = "textBox1";
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Name = "textBox2";
            // 
            // comboBoxTagType
            // 
            resources.ApplyResources(this.comboBoxTagType, "comboBoxTagType");
            this.comboBoxTagType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTagType.FormattingEnabled = true;
            this.comboBoxTagType.Items.AddRange(new object[] {
            resources.GetString("comboBoxTagType.Items"),
            resources.GetString("comboBoxTagType.Items1"),
            resources.GetString("comboBoxTagType.Items2"),
            resources.GetString("comboBoxTagType.Items3"),
            resources.GetString("comboBoxTagType.Items4")});
            this.comboBoxTagType.Name = "comboBoxTagType";
            // 
            // groupBoxTool
            // 
            resources.ApplyResources(this.groupBoxTool, "groupBoxTool");
            this.groupBoxTool.Controls.Add(this.comboBoxTool);
            this.groupBoxTool.ForeColor = System.Drawing.Color.Black;
            this.groupBoxTool.Name = "groupBoxTool";
            this.groupBoxTool.TabStop = false;
            // 
            // comboBoxTool
            // 
            resources.ApplyResources(this.comboBoxTool, "comboBoxTool");
            this.comboBoxTool.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTool.FormattingEnabled = true;
            this.comboBoxTool.Items.AddRange(new object[] {
            resources.GetString("comboBoxTool.Items"),
            resources.GetString("comboBoxTool.Items1"),
            resources.GetString("comboBoxTool.Items2"),
            resources.GetString("comboBoxTool.Items3"),
            resources.GetString("comboBoxTool.Items4")});
            this.comboBoxTool.Name = "comboBoxTool";
            this.comboBoxTool.SelectedIndexChanged += new System.EventHandler(this.comboBoxTool_SelectedIndexChanged);
            // 
            // groupBox19
            // 
            resources.ApplyResources(this.groupBox19, "groupBox19");
            this.groupBox19.Controls.Add(this.comboBoxTagOp);
            this.groupBox19.ForeColor = System.Drawing.Color.Black;
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.TabStop = false;
            // 
            // comboBoxTagOp
            // 
            resources.ApplyResources(this.comboBoxTagOp, "comboBoxTagOp");
            this.comboBoxTagOp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTagOp.FormattingEnabled = true;
            this.comboBoxTagOp.Items.AddRange(new object[] {
            resources.GetString("comboBoxTagOp.Items"),
            resources.GetString("comboBoxTagOp.Items1"),
            resources.GetString("comboBoxTagOp.Items2"),
            resources.GetString("comboBoxTagOp.Items3"),
            resources.GetString("comboBoxTagOp.Items4")});
            this.comboBoxTagOp.Name = "comboBoxTagOp";
            this.comboBoxTagOp.SelectedIndexChanged += new System.EventHandler(this.comboBoxTagOp_SelectedIndexChanged);
            // 
            // groupBox20
            // 
            resources.ApplyResources(this.groupBox20, "groupBox20");
            this.groupBox20.Controls.Add(this.buttonClearInfo);
            this.groupBox20.Controls.Add(this.statusStripInfo);
            this.groupBox20.Controls.Add(this.textBoxInf);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.TabStop = false;
            // 
            // buttonClearInfo
            // 
            resources.ApplyResources(this.buttonClearInfo, "buttonClearInfo");
            this.buttonClearInfo.Name = "buttonClearInfo";
            this.buttonClearInfo.UseVisualStyleBackColor = true;
            this.buttonClearInfo.Click += new System.EventHandler(this.buttonClearInfo_Click);
            // 
            // statusStripInfo
            // 
            resources.ApplyResources(this.statusStripInfo, "statusStripInfo");
            this.statusStripInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelCom,
            this.toolStripStatusLabelState,
            this.toolStripStatusLabelBr,
            this.toolStripStatusLabelWarn});
            this.statusStripInfo.Name = "statusStripInfo";
            // 
            // toolStripStatusLabelCom
            // 
            resources.ApplyResources(this.toolStripStatusLabelCom, "toolStripStatusLabelCom");
            this.toolStripStatusLabelCom.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.toolStripStatusLabelCom.Name = "toolStripStatusLabelCom";
            // 
            // toolStripStatusLabelState
            // 
            resources.ApplyResources(this.toolStripStatusLabelState, "toolStripStatusLabelState");
            this.toolStripStatusLabelState.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.toolStripStatusLabelState.Name = "toolStripStatusLabelState";
            // 
            // toolStripStatusLabelBr
            // 
            resources.ApplyResources(this.toolStripStatusLabelBr, "toolStripStatusLabelBr");
            this.toolStripStatusLabelBr.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.toolStripStatusLabelBr.Name = "toolStripStatusLabelBr";
            // 
            // toolStripStatusLabelWarn
            // 
            resources.ApplyResources(this.toolStripStatusLabelWarn, "toolStripStatusLabelWarn");
            this.toolStripStatusLabelWarn.Name = "toolStripStatusLabelWarn";
            this.toolStripStatusLabelWarn.Spring = true;
            // 
            // textBoxInf
            // 
            resources.ApplyResources(this.textBoxInf, "textBoxInf");
            this.textBoxInf.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBoxInf.Name = "textBoxInf";
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.groupBox28);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.radioButton5);
            this.groupBox2.Controls.Add(this.radioButton6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // groupBox28
            // 
            resources.ApplyResources(this.groupBox28, "groupBox28");
            this.groupBox28.Controls.Add(this.button1);
            this.groupBox28.Controls.Add(this.label1);
            this.groupBox28.Controls.Add(this.label2);
            this.groupBox28.Controls.Add(this.radioButton3);
            this.groupBox28.Controls.Add(this.radioButton4);
            this.groupBox28.Controls.Add(this.label43);
            this.groupBox28.Controls.Add(this.label44);
            this.groupBox28.Controls.Add(this.textBox3);
            this.groupBox28.Controls.Add(this.textBox4);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.TabStop = false;
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // radioButton3
            // 
            resources.ApplyResources(this.radioButton3, "radioButton3");
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            resources.ApplyResources(this.radioButton4, "radioButton4");
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            resources.ApplyResources(this.label43, "label43");
            this.label43.Name = "label43";
            // 
            // label44
            // 
            resources.ApplyResources(this.label44, "label44");
            this.label44.Name = "label44";
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox3.Name = "textBox3";
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox4.Name = "textBox4";
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            resources.ApplyResources(this.radioButton5, "radioButton5");
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            resources.ApplyResources(this.radioButton6, "radioButton6");
            this.radioButton6.Checked = true;
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // groupBox29
            // 
            resources.ApplyResources(this.groupBox29, "groupBox29");
            this.groupBox29.Controls.Add(this.groupBox30);
            this.groupBox29.Controls.Add(this.button5);
            this.groupBox29.Controls.Add(this.radioButton9);
            this.groupBox29.Controls.Add(this.radioButton10);
            this.groupBox29.Controls.Add(this.radioButton11);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.TabStop = false;
            // 
            // groupBox30
            // 
            resources.ApplyResources(this.groupBox30, "groupBox30");
            this.groupBox30.Controls.Add(this.button4);
            this.groupBox30.Controls.Add(this.label45);
            this.groupBox30.Controls.Add(this.label46);
            this.groupBox30.Controls.Add(this.radioButton7);
            this.groupBox30.Controls.Add(this.radioButton8);
            this.groupBox30.Controls.Add(this.label47);
            this.groupBox30.Controls.Add(this.label48);
            this.groupBox30.Controls.Add(this.textBox5);
            this.groupBox30.Controls.Add(this.textBox6);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.TabStop = false;
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            resources.ApplyResources(this.label45, "label45");
            this.label45.Name = "label45";
            // 
            // label46
            // 
            resources.ApplyResources(this.label46, "label46");
            this.label46.Name = "label46";
            // 
            // radioButton7
            // 
            resources.ApplyResources(this.radioButton7, "radioButton7");
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            resources.ApplyResources(this.radioButton8, "radioButton8");
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            resources.ApplyResources(this.label47, "label47");
            this.label47.Name = "label47";
            // 
            // label48
            // 
            resources.ApplyResources(this.label48, "label48");
            this.label48.Name = "label48";
            // 
            // textBox5
            // 
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox5.Name = "textBox5";
            // 
            // textBox6
            // 
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox6.Name = "textBox6";
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            resources.ApplyResources(this.radioButton9, "radioButton9");
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            resources.ApplyResources(this.radioButton10, "radioButton10");
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            resources.ApplyResources(this.radioButton11, "radioButton11");
            this.radioButton11.Checked = true;
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.TabStop = true;
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.comboBoxLang);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // comboBoxLang
            // 
            resources.ApplyResources(this.comboBoxLang, "comboBoxLang");
            this.comboBoxLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLang.FormattingEnabled = true;
            this.comboBoxLang.Items.AddRange(new object[] {
            resources.GetString("comboBoxLang.Items"),
            resources.GetString("comboBoxLang.Items1")});
            this.comboBoxLang.Name = "comboBoxLang";
            this.comboBoxLang.SelectedIndexChanged += new System.EventHandler(this.comboBoxLang_SelectedIndexChanged);
            // 
            // RFIDStation
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.groupBoxTool);
            this.Controls.Add(this.tabControlDevice);
            this.Controls.Add(this.groupBox6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RFIDStation";
            this.Load += new System.EventHandler(this.RFIDStation_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelNetParams.ResumeLayout(false);
            this.panelNetParams.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.tabControlDevice.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBoxBr.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBoxTagQuit.ResumeLayout(false);
            this.groupBoxAFIMode.ResumeLayout(false);
            this.groupBoxCmdMode.ResumeLayout(false);
            this.groupBoxProtocol.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBoxSetPower.ResumeLayout(false);
            this.groupBoxSetPower.PerformLayout();
            this.groupBoxSelectAnt.ResumeLayout(false);
            this.groupBoxSelectAnt.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBoxTool.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.statusStripInfo.ResumeLayout(false);
            this.statusStripInfo.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBoxDestAddr;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonOpenSerial;
        private System.Windows.Forms.ComboBox comboBoxBaudrate;
        private System.Windows.Forms.ComboBox comboBoxComPort;
        private System.Windows.Forms.Label labelBr;
        private System.Windows.Forms.Label labelCom;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RadioButton radioButtonISO15693;
        private System.Windows.Forms.RadioButton radioButtonISO14443A;
        private System.Windows.Forms.Button buttonReadConfiguration;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RadioButton radioButtonBeepModeDisable;
        private System.Windows.Forms.RadioButton radioButtonBeepModeEnable;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButtonBR9600;
        private System.Windows.Forms.RadioButton radioButtonBR38400;
        private System.Windows.Forms.RadioButton radioButtonBR115200;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioButtonTagModeQuiet;
        private System.Windows.Forms.RadioButton radioButtonTagModeUnquiet;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButtonAFIModeDisable;
        private System.Windows.Forms.TextBox textBoxAFI;
        private System.Windows.Forms.RadioButton radioButtonAFIModeEnable;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButtonCmdModeTrigle;
        private System.Windows.Forms.RadioButton radioButtonCmdModeAuto;
        private System.Windows.Forms.Button buttonConfigReader;
        private System.Windows.Forms.TextBox textBoxReaderAddr;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button buttonRFControl;
        private System.Windows.Forms.RadioButton radioButtonRFReset;
        private System.Windows.Forms.RadioButton radioButtonRFOpen;
        private System.Windows.Forms.RadioButton radioButtonRFClose;
        private System.Windows.Forms.TabControl tabControlDevice;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBoxProtocol;
        private System.Windows.Forms.GroupBox groupBoxCmdMode;
        private System.Windows.Forms.GroupBox groupBoxAFIMode;
        private System.Windows.Forms.GroupBox groupBoxTagQuit;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBoxBr;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox comboBoxTagType;
        private System.Windows.Forms.GroupBox groupBoxTool;
        private System.Windows.Forms.ComboBox comboBoxTool;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.ComboBox comboBoxTagOp;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox textBoxInf;
        private System.Windows.Forms.Button buttonClearInfo;
        private System.Windows.Forms.ComboBox comboBoxComInterface;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.Button buttonGetV;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBoxGDeviceType;
        private System.Windows.Forms.TextBox textBoxGDeviceSv;
        private System.Windows.Forms.TextBox textBoxGDeviceHv;
        private System.Windows.Forms.RadioButton radioButtonFelica;
        private System.Windows.Forms.RadioButton radioButtonISO14443B;
        private System.Windows.Forms.GroupBox groupBoxSelectAnt;
        private System.Windows.Forms.Button buttonCtrlAnt;
        private System.Windows.Forms.GroupBox groupBoxSetPower;
        private System.Windows.Forms.Button buttonCtrlPwr;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBoxCtrlPwrAntIndex;
        private System.Windows.Forms.ComboBox comboBoxAntPower;
        private System.Windows.Forms.Label labelUsbList;
        private System.Windows.Forms.ComboBox comboBoxUsbList;
        private System.Windows.Forms.ComboBox comboBoxAntNum;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox comboBoxAntCurIndex;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panelNetParams;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox comboBoxNetDevicePortList;
        private System.Windows.Forms.ComboBox comboBoxNetDeviceIpList;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.StatusStrip statusStripInfo;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCom;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelState;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelBr;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelWarn;
        private System.Windows.Forms.ComboBox comboBoxLang;
    }
}

