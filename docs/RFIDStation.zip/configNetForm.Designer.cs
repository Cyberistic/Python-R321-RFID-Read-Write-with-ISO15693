﻿namespace RFIDStation
{
    partial class configNetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxDevice = new System.Windows.Forms.GroupBox();
            this.listViewDevice = new System.Windows.Forms.ListView();
            this.chIp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chMac = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonScan = new System.Windows.Forms.Button();
            this.buttonSetParams = new System.Windows.Forms.Button();
            this.groupBoxParams = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxBr = new System.Windows.Forms.ComboBox();
            this.textBoxRemotePort = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxRemoteIp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxLocalPort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxGateway = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSubNetMask = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxLocalIp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxNetMode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDefault = new System.Windows.Forms.Button();
            this.groupBoxDevice.SuspendLayout();
            this.groupBoxParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxDevice
            // 
            this.groupBoxDevice.Controls.Add(this.listViewDevice);
            this.groupBoxDevice.Location = new System.Drawing.Point(11, 12);
            this.groupBoxDevice.Name = "groupBoxDevice";
            this.groupBoxDevice.Size = new System.Drawing.Size(277, 239);
            this.groupBoxDevice.TabIndex = 16;
            this.groupBoxDevice.TabStop = false;
            this.groupBoxDevice.Text = "设备列表";
            // 
            // listViewDevice
            // 
            this.listViewDevice.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chIp,
            this.chMac});
            this.listViewDevice.FullRowSelect = true;
            this.listViewDevice.GridLines = true;
            this.listViewDevice.Location = new System.Drawing.Point(6, 26);
            this.listViewDevice.MultiSelect = false;
            this.listViewDevice.Name = "listViewDevice";
            this.listViewDevice.Size = new System.Drawing.Size(265, 204);
            this.listViewDevice.TabIndex = 0;
            this.listViewDevice.UseCompatibleStateImageBehavior = false;
            this.listViewDevice.View = System.Windows.Forms.View.Details;
            this.listViewDevice.SelectedIndexChanged += new System.EventHandler(this.listViewDevice_SelectedIndexChanged);
            // 
            // chIp
            // 
            this.chIp.Text = "IP";
            this.chIp.Width = 120;
            // 
            // chMac
            // 
            this.chMac.Text = "Mac";
            this.chMac.Width = 130;
            // 
            // buttonScan
            // 
            this.buttonScan.Location = new System.Drawing.Point(11, 257);
            this.buttonScan.Name = "buttonScan";
            this.buttonScan.Size = new System.Drawing.Size(277, 23);
            this.buttonScan.TabIndex = 17;
            this.buttonScan.Text = "开始搜索";
            this.buttonScan.UseVisualStyleBackColor = true;
            this.buttonScan.Click += new System.EventHandler(this.buttonScan_Click);
            // 
            // buttonSetParams
            // 
            this.buttonSetParams.Location = new System.Drawing.Point(308, 257);
            this.buttonSetParams.Name = "buttonSetParams";
            this.buttonSetParams.Size = new System.Drawing.Size(128, 23);
            this.buttonSetParams.TabIndex = 18;
            this.buttonSetParams.Text = "配置参数";
            this.buttonSetParams.UseVisualStyleBackColor = true;
            this.buttonSetParams.Click += new System.EventHandler(this.buttonSetParams_Click);
            // 
            // groupBoxParams
            // 
            this.groupBoxParams.Controls.Add(this.label8);
            this.groupBoxParams.Controls.Add(this.comboBoxBr);
            this.groupBoxParams.Controls.Add(this.textBoxRemotePort);
            this.groupBoxParams.Controls.Add(this.label6);
            this.groupBoxParams.Controls.Add(this.textBoxRemoteIp);
            this.groupBoxParams.Controls.Add(this.label7);
            this.groupBoxParams.Controls.Add(this.textBoxLocalPort);
            this.groupBoxParams.Controls.Add(this.label5);
            this.groupBoxParams.Controls.Add(this.textBoxGateway);
            this.groupBoxParams.Controls.Add(this.label4);
            this.groupBoxParams.Controls.Add(this.textBoxSubNetMask);
            this.groupBoxParams.Controls.Add(this.label3);
            this.groupBoxParams.Controls.Add(this.textBoxLocalIp);
            this.groupBoxParams.Controls.Add(this.label2);
            this.groupBoxParams.Controls.Add(this.comboBoxNetMode);
            this.groupBoxParams.Controls.Add(this.label1);
            this.groupBoxParams.Location = new System.Drawing.Point(308, 12);
            this.groupBoxParams.Name = "groupBoxParams";
            this.groupBoxParams.Size = new System.Drawing.Size(277, 239);
            this.groupBoxParams.TabIndex = 19;
            this.groupBoxParams.TabStop = false;
            this.groupBoxParams.Text = "网口参数";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "串口速率：";
            // 
            // comboBoxBr
            // 
            this.comboBoxBr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBr.Enabled = false;
            this.comboBoxBr.FormattingEnabled = true;
            this.comboBoxBr.Items.AddRange(new object[] {
            "9600",
            "38400",
            "115200"});
            this.comboBoxBr.Location = new System.Drawing.Point(82, 210);
            this.comboBoxBr.Name = "comboBoxBr";
            this.comboBoxBr.Size = new System.Drawing.Size(189, 20);
            this.comboBoxBr.TabIndex = 14;
            // 
            // textBoxRemotePort
            // 
            this.textBoxRemotePort.Location = new System.Drawing.Point(82, 181);
            this.textBoxRemotePort.Name = "textBoxRemotePort";
            this.textBoxRemotePort.Size = new System.Drawing.Size(189, 21);
            this.textBoxRemotePort.TabIndex = 13;
            this.textBoxRemotePort.Text = "10000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "远程端口：";
            // 
            // textBoxRemoteIp
            // 
            this.textBoxRemoteIp.Location = new System.Drawing.Point(82, 155);
            this.textBoxRemoteIp.Name = "textBoxRemoteIp";
            this.textBoxRemoteIp.Size = new System.Drawing.Size(189, 21);
            this.textBoxRemoteIp.TabIndex = 11;
            this.textBoxRemoteIp.Text = "192.168.1.10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "远程地址：";
            // 
            // textBoxLocalPort
            // 
            this.textBoxLocalPort.Location = new System.Drawing.Point(82, 77);
            this.textBoxLocalPort.Name = "textBoxLocalPort";
            this.textBoxLocalPort.Size = new System.Drawing.Size(189, 21);
            this.textBoxLocalPort.TabIndex = 9;
            this.textBoxLocalPort.Text = "10000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "本地端口：";
            // 
            // textBoxGateway
            // 
            this.textBoxGateway.Location = new System.Drawing.Point(82, 129);
            this.textBoxGateway.Name = "textBoxGateway";
            this.textBoxGateway.Size = new System.Drawing.Size(189, 21);
            this.textBoxGateway.TabIndex = 7;
            this.textBoxGateway.Text = "192.168.1.1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "网关地址：";
            // 
            // textBoxSubNetMask
            // 
            this.textBoxSubNetMask.Location = new System.Drawing.Point(82, 103);
            this.textBoxSubNetMask.Name = "textBoxSubNetMask";
            this.textBoxSubNetMask.Size = new System.Drawing.Size(189, 21);
            this.textBoxSubNetMask.TabIndex = 5;
            this.textBoxSubNetMask.Text = "255.255.255.0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "子网掩码：";
            // 
            // textBoxLocalIp
            // 
            this.textBoxLocalIp.Location = new System.Drawing.Point(82, 51);
            this.textBoxLocalIp.Name = "textBoxLocalIp";
            this.textBoxLocalIp.Size = new System.Drawing.Size(189, 21);
            this.textBoxLocalIp.TabIndex = 3;
            this.textBoxLocalIp.Text = "192.168.1.7";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "本地地址：";
            // 
            // comboBoxNetMode
            // 
            this.comboBoxNetMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNetMode.FormattingEnabled = true;
            this.comboBoxNetMode.Items.AddRange(new object[] {
            "UdpClient",
            "TcpClient",
            "UdpServer",
            "TcpServer"});
            this.comboBoxNetMode.Location = new System.Drawing.Point(82, 26);
            this.comboBoxNetMode.Name = "comboBoxNetMode";
            this.comboBoxNetMode.Size = new System.Drawing.Size(189, 20);
            this.comboBoxNetMode.TabIndex = 1;
            this.comboBoxNetMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxNetMode_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "工作模式：";
            // 
            // buttonDefault
            // 
            this.buttonDefault.Location = new System.Drawing.Point(457, 257);
            this.buttonDefault.Name = "buttonDefault";
            this.buttonDefault.Size = new System.Drawing.Size(128, 23);
            this.buttonDefault.TabIndex = 20;
            this.buttonDefault.Text = "恢复默认";
            this.buttonDefault.UseVisualStyleBackColor = true;
            this.buttonDefault.Click += new System.EventHandler(this.buttonDefault_Click);
            // 
            // configNetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 289);
            this.Controls.Add(this.buttonDefault);
            this.Controls.Add(this.groupBoxParams);
            this.Controls.Add(this.buttonSetParams);
            this.Controls.Add(this.buttonScan);
            this.Controls.Add(this.groupBoxDevice);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "configNetForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "配置网口参数";
            this.Load += new System.EventHandler(this.configNetForm_Load);
            this.groupBoxDevice.ResumeLayout(false);
            this.groupBoxParams.ResumeLayout(false);
            this.groupBoxParams.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDevice;
        private System.Windows.Forms.ListView listViewDevice;
        private System.Windows.Forms.ColumnHeader chIp;
        private System.Windows.Forms.ColumnHeader chMac;
        private System.Windows.Forms.Button buttonScan;
        private System.Windows.Forms.Button buttonSetParams;
        private System.Windows.Forms.GroupBox groupBoxParams;
        private System.Windows.Forms.TextBox textBoxRemotePort;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxRemoteIp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxLocalPort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxGateway;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSubNetMask;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxLocalIp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxNetMode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxBr;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonDefault;
    }
}