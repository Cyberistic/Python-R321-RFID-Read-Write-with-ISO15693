using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RFIDStation
{
    public partial class crcForm : Form
    {
        private int calIso15693Crc(byte[] pFrame, int len)
        {
            const int POLYNOMIAL = 0x8408;
            const int PRESET_VALUE = 0xFFFF;

            int crc = 0;
            int temp = 0;
            int i = 0, j = 0;
            crc = PRESET_VALUE;
            for (i = 0; i < len; i++)
            {
                temp = (int)(pFrame[i]);
                temp &= 0xFF;
                crc = (crc ^ temp);
                crc &= 0xFFFF;
                for (j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) == 0x0001)
                    {
                        crc = (crc >> 1) ^ POLYNOMIAL;
                    }
                    else
                    {
                        crc = (crc >> 1);
                    }
                }
                crc &= 0xFFFF;
            }
            crc = ~crc;
            return crc & 0xFFFF;
        }


        private int calIso14443ACrc(byte[] pFrame, int len)
        {
            const int POLYNOMIAL = 0x8408;
            const int PRESET_VALUE = 0x6363;

            int crc = 0;
            int temp = 0;
            int i = 0, j = 0;
            crc = PRESET_VALUE;
            for (i = 0; i < len; i++)
            {
                temp = (int)(pFrame[i]);
                temp &= 0xFF;
                crc = (crc ^ temp);
                crc &= 0xFFFF;
                for (j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) == 0x0001)
                    {
                        crc = (crc >> 1) ^ POLYNOMIAL;
                    }
                    else
                    {
                        crc = (crc >> 1);
                    }
                }
                crc &= 0xFFFF;
            }

            return crc;
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public crcForm()
        {
            InitializeComponent();

            comboBoxCrcType.SelectedIndex = 0;
            
        }

        private void buttonCalCrc_Click(object sender, EventArgs e)
        {
            Byte[] param = new Byte[4096];
            int paramsLen = 0;
            int crc = 0;

            textBoxCrcData.Text = textBoxCrcData.Text.Replace(" ", "");
            textBoxCrcData.Text = textBoxCrcData.Text.Replace("-", "");
            textBoxCrcData.Text = textBoxCrcData.Text.Replace("_", "");
            textBoxCrcData.Text = textBoxCrcData.Text.Replace("#", "");
            if (this.textBoxCrcData.Text.Length <= param.Length * 2)
            {
                paramsLen = GetHexInput(this.textBoxCrcData.Text, param);
                if (paramsLen > 0)
                {
                    if (comboBoxCrcType.SelectedIndex == 0 || comboBoxCrcType.SelectedIndex == 2)
                    {
                        crc = calIso15693Crc(param, paramsLen);
                    }
                    else if (comboBoxCrcType.SelectedIndex == 1)
                    {
                        crc = calIso14443ACrc(param, paramsLen);
                    }
                    textBoxCrcData.Text += "\r\nCRC:";

                    textBoxCrcData.Text += ((Byte)((crc >> 0) & 0xFF)).ToString("X").PadLeft(2, '0');
                    textBoxCrcData.Text += ((Byte)((crc >> 8) & 0xFF)).ToString("X").PadLeft(2, '0');
                }

            }
        }
    }
}