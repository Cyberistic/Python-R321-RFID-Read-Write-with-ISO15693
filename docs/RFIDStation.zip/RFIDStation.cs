using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.Resources;

namespace RFIDStation
{
    public partial class RFIDStation : Form
    {
        ResourceManager res=new ResourceManager(typeof(RFIDStation));
        private int serialDevice;                   //�����豸
        private int hHFREADERDLLModule;               //dll���
        private ISO15693 iso15693Form;
        private ISO14443A iso14443AForm;
        private ISO14443B iso14443BForm;

        private felica felicaForm;
        private NfcTools nfcForm;
        private updateSystem updateSystemForm;
        private uartDebug uartDebugForm;
        private int[] usbHandleList = new int[256];
        private int usbDevNum = 0;
        public string deviceTypeStr = "";
        private bool bFormOk = false;

        private int netDeviceNum = 0;
        private string[] netDeviceMacInfo = new string[256];
        private string[] netDeviceIpInfo = new string[256];
        private string[] netDevicePortInfo = new string[256];

        private void ShowComInfo(string com, int h, string state)
        {
            this.toolStripStatusLabelCom.Text = com;
            if (com == "COM")
            {
                this.toolStripStatusLabelBr.Text = comboBoxComPort.Text + ":" + comboBoxBaudrate.Text;
            }
            else if (com == "USB")
            {
                this.toolStripStatusLabelBr.Text = comboBoxUsbList.Text;
            }
            else if (com == "NET")
            {
                this.toolStripStatusLabelBr.Text = comboBoxNetDeviceIpList.Text + ":" + comboBoxNetDevicePortList.Text;
            }

            this.toolStripStatusLabelState.Text = state;
        }

        private void UpdateComBox()
        {
            string[] portList = System.IO.Ports.SerialPort.GetPortNames();
            int i = 0;
            for (i = 0; i < comboBoxComPort.Items.Count; ++i)
            {
                int j = 0;
                string name = comboBoxComPort.Items[i].ToString();
                for (j = 0; j < portList.Length; j++)
                {
                    if (portList[j] == name)
                    {
                        break;
                    }
                }
                if (j == portList.Length)
                {
                    comboBoxComPort.Items.Remove(name);
                    comboBoxComPort.SelectedIndex = -1;
                }
            }
            for (i = 0; i < portList.Length; ++i)
            {
                string name = portList[i];
                if (comboBoxComPort.Items.IndexOf(name) < 0)
                {
                    comboBoxComPort.Items.Add(name);
                }
            }
        }

        private void comboBoxComPort_DropDown(object sender, EventArgs e)
        {
            UpdateComBox();
        }

        private void UpdateNetBox()
        {
            int i = 0;
            int settingIndex = -1;

            ScanNetDevices();
            for (i = 0; i < netDeviceNum; i++)
            {
                comboBoxNetDeviceIpList.Items.Add(netDeviceIpInfo[i]);
                comboBoxNetDevicePortList.Items.Add(netDevicePortInfo[i]);

                if (Settings.Default.netIp + " " + Settings.Default.netPort == netDeviceIpInfo[i] + " " + netDevicePortInfo[i])
                {
                    settingIndex = i;
                }
            }
            if (netDeviceNum > 0)
            {
                if (settingIndex < 0)
                {
                    settingIndex = 0;
                }
                comboBoxNetDeviceIpList.SelectedIndex = settingIndex;
                comboBoxNetDevicePortList.SelectedIndex = settingIndex;
            }
        }

        private void comboBoxNetDeviceIpList_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxNetDevicePortList.SelectedIndex = comboBoxNetDeviceIpList.SelectedIndex;
        }

        private void comboBoxNetDevicePortList_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxNetDeviceIpList.SelectedIndex = comboBoxNetDevicePortList.SelectedIndex;
        }

        private bool ReadNetDeviceInfo(IPAddress masterIp, Byte[] deviceParams, ref string portStr, ref string ipStr)
        {
            byte[] txCmd = { 0xFF, 0x13, 0x03, 0xD8, 0xB0, 0x4C, 0x46, 0x35, 0xCA, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x61, 0x64, 0x6D, 0x69, 0x6E, 0x00, 0x41 };
            byte chk = 0;
            int i = 0;

            for (i = 0; i < 6; i++)
            {
                txCmd[3 + i] = deviceParams[9 + i];
            }
            for (i = 0; i < 20; i++)
            {
                chk += txCmd[1 + i];
            }
            txCmd[21] = chk;

            UdpClient localUdpClient = null;
            try
            {
                IPEndPoint localUdpPoint = new IPEndPoint(masterIp, 1000);
                localUdpClient = new UdpClient(localUdpPoint);
                localUdpClient.Client.SendTimeout = 500;
                localUdpClient.Client.ReceiveTimeout = 500;
                IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                localUdpClient.Send(txCmd, txCmd.Length, deviceUdpPoint);
                byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                if (recvData != null)
                {
                    int br = recvData[67 + 0] + recvData[67 + 1] * 256 + recvData[67 + 2] * 256 * 256;
                    if (br != 115200)
                    {
                        return false;
                    }

                    if (recvData[67 + 51] != 3)
                    {
                        return false;
                    }

                    ipStr = recvData[12].ToString() + "." + recvData[11].ToString() + "." + recvData[10].ToString() + "." + recvData[9].ToString();
                    portStr = (recvData[67 + 12] + recvData[67 + 13] * 256).ToString();

                }
                else
                {
                    return false;
                }

                localUdpClient.Close();

                return true;
            }
            catch (Exception ex)
            {
                if (localUdpClient != null)
                {
                    localUdpClient.Close();
                }

                return false;
            }
        }

        private void ScanNetDevices()
        {
            IPAddress[] localIpList = new IPAddress[256];
            int localIpNum = 0;

            netDeviceNum = 0;

            foreach (IPAddress _IPAddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (_IPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    localIpList[localIpNum++] = _IPAddress;
                }
            }

            int n = 0;
            UdpClient localUdpClient = null;
            for (n = 0; n < localIpNum; n++)
            {
                try
                {
                    IPEndPoint localUdpPoint = new IPEndPoint(localIpList[n], 53453);
                    localUdpClient = new UdpClient(localUdpPoint);
                    localUdpClient.Client.SendTimeout = 500;
                    localUdpClient.Client.ReceiveTimeout = 500;
                    IPEndPoint deviceUdpPoint = new IPEndPoint(IPAddress.Parse("255.255.255.255"), 1500);

                    byte[] cmdScan = { 0xFF, 0x01, 0x01, 0x02 };
                    localUdpClient.Send(cmdScan, cmdScan.Length, deviceUdpPoint);
                    while (true)
                    {
                        try
                        {
                            byte[] recvData = localUdpClient.Receive(ref deviceUdpPoint);
                            if (recvData != null)
                            {
                                int i = 0;
                                string macStr = "";

                                macStr += recvData[9].ToString("X").PadLeft(2, '0') + ":";
                                macStr += recvData[10].ToString("X").PadLeft(2, '0') + ":";
                                macStr += recvData[11].ToString("X").PadLeft(2, '0') + ":";
                                macStr += recvData[12].ToString("X").PadLeft(2, '0') + ":";
                                macStr += recvData[13].ToString("X").PadLeft(2, '0') + ":";
                                macStr += recvData[14].ToString("X").PadLeft(2, '0');
                                for (i = 0; i < netDeviceNum; i++)
                                {
                                    if (netDeviceMacInfo[i] == macStr)
                                    {
                                        break;
                                    }
                                }
                                if (i == netDeviceNum)
                                {
                                    string devicePortStr = "", deviceIpStr = "";
                                    if (ReadNetDeviceInfo(localIpList[n], recvData, ref devicePortStr, ref deviceIpStr))
                                    {
                                        netDeviceMacInfo[netDeviceNum] = macStr;
                                        netDeviceIpInfo[netDeviceNum] = deviceIpStr;
                                        netDevicePortInfo[netDeviceNum] = devicePortStr;
                                        netDeviceNum++;
                                    }
                                }

                                Thread.Sleep(10);
                            }
                            else
                            {
                                localUdpClient.Close();
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            localUdpClient.Close();
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (localUdpClient != null)
                    {
                        localUdpClient.Close();
                    }
                }
            }
        }

        private void RFIDStation_Load(object sender, EventArgs e)
        {
           // ChangeLang.LoadLanguage(this, typeof(RFIDStation));
            string language = Settings.Default.DefaultLanguage;
            if (language == "zh-CN")
            {
                comboBoxLang.SelectedIndex = 0;
            }

            else if (language == "en-US")
            {
                comboBoxLang.SelectedIndex = 1;
            }

            UpdateNetBox();
            comboBoxLang.SelectedIndex = 0;
            ShowComInfo(Settings.Default.comType.ToUpper(), serialDevice, "Close");
            if (Settings.Default.comType == "com")
            {
                this.comboBoxComInterface.SelectedIndex = 0;
                this.comboBoxComPort.Text = Settings.Default.com;
                this.comboBoxBaudrate.Text = Settings.Default.comBr;
            }
            else if (Settings.Default.comType == "usb")
            {
                this.comboBoxComInterface.SelectedIndex = 1;
            }
            else if (Settings.Default.comType == "net")
            {
                this.comboBoxComInterface.SelectedIndex = 2;
            }
            bFormOk = true;
        }

        public RFIDStation()
        {
            InitializeComponent();

            hHFREADERDLLModule = 0;
            hHFREADERDLLModule = hfReaderDll.LoadLibrary("HFREADER.dll");

            if (hHFREADERDLLModule <= 0)
            {
                MessageBox.Show("װ��HFREADER.dll�ļ�ʧ�ܣ���ȷ��HFREADER.dll�ļ��Ƿ����");
                System.Environment.Exit(0);
            }

            /*int h = hfReaderDll.hfReaderOpenUsb(0x0101, 0x1010);
            int rlt = 0;
            Byte[] f = new Byte[64];
            f[0] = 0x00;
            rlt = hfReaderDll.hfReaderGetUsbFeature(h, f, 64);
            f[0] = 0x00;
            f[1] = 0x01;
            f[2] = 0x00; f[3] = 0xc2; f[4] = 0x01; f[5] = 0x00;
            f[6] = 0x00;
            f[7] = 0x00;
            f[8] = 0x08; 
            rlt = hfReaderDll.hfReaderSetUsbFeature(h, f, 9);
             */
            int i = 0;
            this.comboBoxComPort.Items.Clear();
            UpdateComBox();
            int selectIndex = comboBoxComPort.Items.IndexOf(Settings.Default.com);
            if (selectIndex >= 0)
            {
                comboBoxComPort.SelectedIndex = selectIndex;
            }
            else
            {
                comboBoxComPort.SelectedIndex = -1;
            }

            serialDevice = -1;
            this.comboBoxBaudrate.Text = "38400";
            this.comboBoxBaudrate.SelectedIndex = 1;
            this.comboBoxTool.SelectedIndex = 0;
            this.comboBoxTagOp.SelectedIndex = 0;

            this.comboBoxCtrlPwrAntIndex.SelectedIndex = 0;
            this.comboBoxAntPower.SelectedIndex = 0;
            this.comboBoxAntNum.SelectedIndex = 6;

            this.Text += "    V" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }

        private bool GetUsbAddr(ushort[] addArray)
        {
            bool b = false;

            return b;
        }

        private void GetDeviceVersion()
        {
            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            HFREADER_VERSION pVersion = new HFREADER_VERSION();
            pVersion.type = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            pVersion.sv = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            pVersion.hv = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            int rlt = hfReaderDll.hfReaderGetVersion(serialDevice, 0x0000, 0xFFFF, ref pVersion, null, null);
            if (rlt > 0)
            {
                if (pVersion.result.flag == 0)
                {
                    deviceTypeStr = System.Text.Encoding.Default.GetString(pVersion.type).Replace("\0", "");
                    string sv = System.Text.Encoding.Default.GetString(pVersion.sv).Replace("\0", "");
                    string hv = System.Text.Encoding.Default.GetString(pVersion.hv).Replace("\0", "");

                    if (comboBoxLang.SelectedIndex==0)
                    {
                        this.textBoxInf.Text = "�豸�ͺţ�" + deviceTypeStr + "  �̼��汾��" + sv + "  Ӳ���汾��" + hv + "\r\n\r\n" + this.textBoxInf.Text;
                    }
                    else if (comboBoxLang.SelectedIndex==1)
                    {
                        this.textBoxInf.Text = "Device Version��" + deviceTypeStr + " Soft Version��" + sv + "  Hardware Version��" + hv + "\r\n\r\n" + this.textBoxInf.Text;
                    }
                    

                    if (deviceTypeStr.IndexOf("R321") >= 0)
                    {
                        groupBoxCmdMode.Enabled = false;
                        radioButtonCmdModeTrigle.Checked = true;

                        groupBoxTagQuit.Enabled = false;
                        radioButtonTagModeUnquiet.Checked = true;
                    }
                }
            }
        }

        private void buttonOpenSerial_Click(object sender, EventArgs e)
        {
            if (serialDevice <= 0)
            {
                if (this.comboBoxComInterface.SelectedIndex == 0) //����
                {
                    string portName = this.comboBoxComPort.Text;
                    if (portName.Length > 4)
                    {
                        portName = "\\\\.\\" + portName;
                    }
                    serialDevice = hfReaderDll.hfReaderOpenPort(portName, this.comboBoxBaudrate.Text);
                }
                else if (this.comboBoxComInterface.SelectedIndex == 1) //USB
                {
                    comboBoxUsbList.Items.Clear();

                    usbDevNum = hfReaderDll.hfReaderScanUsbList(hfReaderDll.HFREADER_USB_VID, hfReaderDll.HFREADER_USB_PID, usbHandleList);
                    //usbDevNum = hfReaderDll.hfReaderScanUsbList(0x04d9, 0xB564, usbHandleList);
                    if (usbDevNum > 0)
                    {
                        int i = 0;
                        for (i = 0; i < usbDevNum; i++)
                        {
                            comboBoxUsbList.Items.Add("USB " + (i + 1));
                        }
                        comboBoxUsbList.SelectedIndex = 0;
                        serialDevice = usbHandleList[0];
                    }
                    else
                    {
                        serialDevice = -1;
                    }
                }
                else if (this.comboBoxComInterface.SelectedIndex == 2) //TCP
                {
                    int iPort = 0;
                    string strIp = this.comboBoxNetDeviceIpList.Text;
                    string strPort = this.comboBoxNetDevicePortList.Text;
                    if (string.IsNullOrEmpty(strIp) || string.IsNullOrEmpty(strPort))
                    {
                        if (comboBoxLang.SelectedIndex==0)
                        {
                            MessageBox.Show("IP�Ͷ˿ڲ���Ϊ��!", "��ʾ");
                            return;
                        }
                        else if (comboBoxLang.SelectedIndex==1)
                        {
                            MessageBox.Show("IP and port cannot be empty!", "Prompt");
                            return;
                        }
                       
                    }
                    iPort = int.Parse(strPort);
                    serialDevice = hfReaderDll.hfReaderOpenSocket(strIp, (ushort)iPort);
                }

                if (serialDevice > 0)
                {
                    if (comboBoxLang.SelectedIndex == 0)
                    {
                        this.buttonOpenSerial.Text = "�ر�";
                    }
                    else if (comboBoxLang.SelectedIndex == 1)
                    {
                        this.buttonOpenSerial.Text = "Close";
                    }
                    
                    this.comboBoxTagOp.Enabled = true;
                    EnableSonForm();
                    this.comboBoxComInterface.Enabled = false;
                    this.panelNetParams.Enabled = false;
                    GetDeviceVersion();

                    if (this.comboBoxComInterface.SelectedIndex == 0)
                    {
                        Settings.Default.comType = "com";
                        Settings.Default.com = this.comboBoxComPort.Text;
                        Settings.Default.comBr = this.comboBoxBaudrate.Text;
                    }
                    else if (this.comboBoxComInterface.SelectedIndex == 1)
                    {
                        Settings.Default.comType = "usb";
                    }
                    else if (this.comboBoxComInterface.SelectedIndex == 2)
                    {
                        Settings.Default.comType = "net";
                        Settings.Default.netIp = comboBoxNetDeviceIpList.Text;
                        Settings.Default.netPort = comboBoxNetDevicePortList.Text;
                    }
                    Settings.Default.Save();
                    ShowComInfo(Settings.Default.comType.ToUpper(), serialDevice, "Open");
                }
                else
                {
                    if (comboBoxLang.SelectedIndex == 0)
                    {
                        MessageBox.Show("�򿪴���ʧ��!", "��ʾ");
                        return;
                    }
                    else if (comboBoxLang.SelectedIndex == 1)
                    {
                        MessageBox.Show("Failed to open serial port!", "Prompt");
                        return;
                    }
                }
            }
            else
            {
                int op = 0;
                string com = "";
                if (this.comboBoxComInterface.SelectedIndex == 0)
                {
                    op = hfReaderDll.hfReaderClosePort(serialDevice);
                    com = "COM";
                }
                else if (this.comboBoxComInterface.SelectedIndex == 1)
                {
                    int i = 0;
                    for (i = 0; i < usbDevNum; i++)
                    {
                        op = hfReaderDll.hfReaderCloseUsb(usbHandleList[i]);
                    }
                    comboBoxUsbList.Items.Clear();
                    com = "USB";
                }
                else if (this.comboBoxComInterface.SelectedIndex == 2)
                {
                    op = hfReaderDll.hfReaderCloseSocket(serialDevice);
                    com = "NET";
                }
                if (op >= 0)
                {
                    if (comboBoxLang.SelectedIndex == 0)
                    {
                        this.buttonOpenSerial.Text = "��";
                    }
                    else if (comboBoxLang.SelectedIndex == 1)
                    {
                        this.buttonOpenSerial.Text = "Open";
                    }
                    
                    DisableSonForm();
                }
                serialDevice = -1;
                this.comboBoxComInterface.Enabled = true;
                this.panelNetParams.Enabled = true;
                //this.comboBoxTool.Enabled = false;
                groupBoxCmdMode.Enabled = true;
                groupBoxTagQuit.Enabled = true;
                ShowComInfo(com, serialDevice, "Close");
            }
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show(res.GetString("LengthError"));
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("HexError"));
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            byte[] buffer = new Byte[255];
            addArray[0] = 0x0000;
            if (GetHexInput(textBoxDestAddr.Text, buffer, 2) > 0)
            {
                addArray[1] = (ushort)(buffer[0] * 256 + buffer[1]);
                b = true;
            }

            return b;
        }

        private void LockUart()
        {
            if ((iso15693Form != null) && (!iso15693Form.IsDisposed))
            {
                if (this.radioButtonISO15693.Checked)
                {
                    while (iso15693Form.bOperatingSerial) ;
                    iso15693Form.bOperatingSerial = true;
                }
            }
            if ((iso14443AForm != null) && (!iso14443AForm.IsDisposed))
            {
                if (this.radioButtonISO14443A.Checked)
                {
                    while (iso14443AForm.bOperatingSerial) ;
                    iso14443AForm.bOperatingSerial = true;
                }
            }
        }

        private void UnlockUart()
        {
            if ((iso15693Form != null) && (!iso15693Form.IsDisposed))
            {
                if (this.radioButtonISO15693.Checked)
                {
                    iso15693Form.bOperatingSerial = false;
                }
            }
            if ((iso14443AForm != null) && (!iso14443AForm.IsDisposed))
            {
                if (this.radioButtonISO14443A.Checked)
                {
                    iso14443AForm.bOperatingSerial = false;
                }
            }
        }

        public void DisplayOpResult(HFREADER_OPRESULT result)
        {
            if (result.flag == 0)
            {
                this.textBoxInf.Text = res.GetString("Opsuccess")+"\r\n\r\n" + this.textBoxInf.Text;
            }
            else
            {
                if (result.errType == 4)
                {
                    this.textBoxInf.Text = res.GetString("Operror1")+"\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 3)
                {
                    this.textBoxInf.Text = res.GetString("Operror2") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 2)
                {
                    this.textBoxInf.Text = res.GetString("Operror3") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else if (result.errType == 1)
                {
                    this.textBoxInf.Text = res.GetString("Operror4") + "\r\n\r\n" + this.textBoxInf.Text;
                }
                else
                {
                    this.textBoxInf.Text = res.GetString("Operror5") + "\r\n\r\n" + this.textBoxInf.Text;
                }
            }
        }

        public void DisplaySendInf(Byte[] pSendBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pSendBuf[2] + 3;
            String s = cmdNmae;
            for (i = 0; i < len; i++)
            {
                s += pSendBuf[i].ToString("X").PadLeft(2, '0');
                s += " ";
            }
            s += "\r\n";
            this.textBoxInf.Text = s + text;
        }

        public void DisplayRcvInf(Byte[] pRcvBuf, String cmdNmae)
        {
            String text = this.textBoxInf.Text;
            int i = 0;
            int len = pRcvBuf[2] + 3;
            String s = cmdNmae;
            if (pRcvBuf[2] > 0)
            {
                for (i = 0; i < len; i++)
                {
                    s += pRcvBuf[i].ToString("X").PadLeft(2, '0');
                    s += " ";
                }
            }
            else
            {
                s += "\r\n"+res.GetString("Operror6")+"\r\n";
            }
            s += "\r\n";

            this.textBoxInf.Text = s + text;
        }

        private void buttonConfigReader_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            Byte WorkMode = 0;
            ushort ReaderAddr = 0;
            Byte cmdMode = 0;
            Byte AFICtrl = 0;
            Byte UIDSendMode = 0;
            Byte tagStatus = 0;
            Byte baudrate = 0;
            Byte BeepStatus = 0;
            Byte AFI = 0;
            HFREADER_CONFIG pReaderConfig = new HFREADER_CONFIG();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.radioButtonISO15693.Checked)
            {
                WorkMode |= hfReaderDll.HFREADER_CFG_TYPE_ISO15693;
            }
            else if (this.radioButtonISO14443A.Checked)
            {
                WorkMode |= hfReaderDll.HFREADER_CFG_TYPE_ISO14443A;
            }
            else if (this.radioButtonISO14443B.Checked)
            {
                WorkMode |= hfReaderDll.HFREADER_CFG_TYPE_ISO14443B;
            }
            else if (this.radioButtonFelica.Checked)
            {
                WorkMode |= hfReaderDll.HFREADER_CFG_TYPE_FELICA;
            }

            WorkMode |= hfReaderDll.HFREADER_CFG_WM_INVENTORY;
            pReaderConfig.workMode = WorkMode;

            if (this.radioButtonCmdModeAuto.Checked)
            {
                cmdMode = hfReaderDll.HFREADER_CFG_INVENTORY_AUTO;
            }
            else
            {
                cmdMode = hfReaderDll.HFREADER_CFG_INVENTORY_TRIGGER;
            }
            pReaderConfig.cmdMode = cmdMode;

            UIDSendMode = hfReaderDll.HFREADER_CFG_UID_POSITIVE;
            pReaderConfig.uidSendMode = UIDSendMode;

            if (this.radioButtonBeepModeEnable.Checked)
            {
                BeepStatus = hfReaderDll.HFREADER_CFG_BUZZER_ENABLE;
            }
            else
            {
                BeepStatus = hfReaderDll.HFREADER_CFG_BUZZER_DISABLE;
            }
            pReaderConfig.beepStatus = BeepStatus;

            if (this.radioButtonAFIModeEnable.Checked)
            {
                AFICtrl = hfReaderDll.HFREADER_CFG_AFI_ENABLE;
            }
            else
            {
                AFICtrl = hfReaderDll.HFREADER_CFG_AFI_DISABLE;
            }
            pReaderConfig.afiCtrl = AFICtrl;

            if (this.radioButtonTagModeQuiet.Checked)
            {
                tagStatus = hfReaderDll.HFREADER_CFG_TAG_QUIET;
            }
            else
            {
                tagStatus = hfReaderDll.HFREADER_CFG_TAG_NOQUIET;
            }
            pReaderConfig.tagStatus = tagStatus;

            if (this.radioButtonBR9600.Checked)
            {
                baudrate = hfReaderDll.HFREADER_CFG_BAUDRATE9600;
            }
            else if (this.radioButtonBR115200.Checked)
            {
                baudrate = hfReaderDll.HFREADER_CFG_BAUDRATE115200;
            }
            else
            {
                baudrate = hfReaderDll.HFREADER_CFG_BAUDRATE38400;
            }
            pReaderConfig.baudrate = baudrate;

            if (GetHexInput(this.textBoxAFI.Text, buffer, 1) > 0)
            {
                AFI = buffer[0];
            }
            else
            {
                return;
            }
            pReaderConfig.afi = AFI;

            if (GetHexInput(this.textBoxReaderAddr.Text, buffer, 2) > 0)
            {
                ReaderAddr = (ushort)(buffer[0] * 256 + buffer[1]);
            }
            else
            {
                return;
            }
            pReaderConfig.readerAddr = ReaderAddr;

            LockUart();
            int rlt = hfReaderDll.hfReaderSetConfig(serialDevice, addrArray[0], addrArray[1], ref pReaderConfig, sendBuffer, rcvBuffer);
            UnlockUart();
            DisplayOpResult(pReaderConfig.result);
            DisplayRcvInf(rcvBuffer, res.GetString("String1"));
            DisplaySendInf(sendBuffer, res.GetString("String2"));
        }

        private void buttonReadConfiguration_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            HFREADER_CONFIG pReaderConfig = new HFREADER_CONFIG();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            LockUart();
            int rlt = hfReaderDll.hfReaderGetConfig(serialDevice, addrArray[0], addrArray[1], ref pReaderConfig, sendBuffer, rcvBuffer);
            UnlockUart();
            if (rlt > 0)
            {
                DisplayOpResult(pReaderConfig.result);
                {
                    Byte mode = (Byte)(pReaderConfig.workMode);
                    if ((mode & hfReaderDll.HFREADER_CFG_TYPE_MASK) == hfReaderDll.HFREADER_CFG_TYPE_ISO15693)
                    {
                        this.radioButtonISO15693.Checked = true;
                    }
                    else if ((mode & hfReaderDll.HFREADER_CFG_TYPE_MASK) == hfReaderDll.HFREADER_CFG_TYPE_ISO14443A)
                    {
                        this.radioButtonISO14443A.Checked = true;
                    }
                    else if ((mode & hfReaderDll.HFREADER_CFG_TYPE_MASK) == hfReaderDll.HFREADER_CFG_TYPE_ISO14443B)
                    {
                        this.radioButtonISO14443B.Checked = true;
                    }
                    else if ((mode & hfReaderDll.HFREADER_CFG_TYPE_MASK) == hfReaderDll.HFREADER_CFG_TYPE_FELICA)
                    {
                        this.radioButtonFelica.Checked = true;
                    }
                    if (groupBoxCmdMode.Enabled) //�����޸�����ģʽ-��Զ����
                    {
                        if (pReaderConfig.cmdMode == hfReaderDll.HFREADER_CFG_INVENTORY_AUTO)
                        {
                            this.radioButtonCmdModeAuto.Checked = true;
                        }
                        else
                        {
                            this.radioButtonCmdModeTrigle.Checked = true;
                        }
                    }

                    if (pReaderConfig.beepStatus == hfReaderDll.HFREADER_CFG_BUZZER_ENABLE)
                    {
                        this.radioButtonBeepModeEnable.Checked = true;
                    }
                    else
                    {
                        this.radioButtonBeepModeDisable.Checked = true;
                    }

                    if (pReaderConfig.afiCtrl == hfReaderDll.HFREADER_CFG_AFI_ENABLE)
                    {
                        this.radioButtonAFIModeEnable.Checked = true;
                    }
                    else
                    {
                        this.radioButtonAFIModeDisable.Checked = true;
                    }

                    if (groupBoxTagQuit.Enabled)        //�����޸ı�ǩ����-��Զ����
                    {
                        if (pReaderConfig.tagStatus == hfReaderDll.HFREADER_CFG_TAG_QUIET)
                        {
                            this.radioButtonTagModeQuiet.Checked = true;
                        }
                        else
                        {
                            this.radioButtonTagModeUnquiet.Checked = true;
                        }
                    }

                    if (pReaderConfig.baudrate == hfReaderDll.HFREADER_CFG_BAUDRATE9600)
                    {
                        this.radioButtonBR9600.Checked = true;
                    }
                    else if (pReaderConfig.baudrate == hfReaderDll.HFREADER_CFG_BAUDRATE115200)
                    {
                        this.radioButtonBR115200.Checked = true;
                    }
                    else
                    {
                        this.radioButtonBR38400.Checked = true;
                    }

                    this.textBoxReaderAddr.Text = pReaderConfig.readerAddr.ToString("X").PadLeft(4, '0');
                    this.textBoxAFI.Text = pReaderConfig.afi.ToString("X").PadLeft(2, '0');
                }
            }

            DisplayRcvInf(rcvBuffer, res.GetString("String3"));
            DisplaySendInf(sendBuffer, res.GetString("String4"));
        }

        private void buttonRFControl_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            Byte rfCtrl = 0;
            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.radioButtonRFOpen.Checked)
            {
                rfCtrl = hfReaderDll.HFREADER_RF_OPEN;
            }
            else if (this.radioButtonRFClose.Checked)
            {
                rfCtrl = hfReaderDll.HFREADER_RF_CLOSE;
            }
            else
            {
                rfCtrl = hfReaderDll.HFREADER_RF_RESET;
            }

            //LockUart();
            int rlt = hfReaderDll.hfReaderCtrlRf(serialDevice, addrArray[0], addrArray[1], rfCtrl, ref pResult, sendBuffer, rcvBuffer);
            //UnlockUart();

            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String5"));
            DisplaySendInf(sendBuffer, res.GetString("String6"));
        }

        private void radioButtonFelica_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBoxAFIMode.Enabled = false;
            EnableSonForm();
        }

        private void radioButtonISO14443B_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBoxAFIMode.Enabled = false;
            EnableSonForm();
        }

        private void radioButtonISO14443A_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBoxAFIMode.Enabled = false;
            EnableSonForm();
        }

        private void radioButtonISO15693_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBoxAFIMode.Enabled = true;
            EnableSonForm();
        }

        private void EnableSonForm()
        {
            if ((iso15693Form != null) && (!iso15693Form.IsDisposed))
            {
                if (this.radioButtonISO15693.Checked)
                {
                    iso15693Form.EnableIso15693(serialDevice);
                }
            }
            if ((iso14443AForm != null) && (!iso14443AForm.IsDisposed))
            {
                if (this.radioButtonISO14443A.Checked)
                {
                    iso14443AForm.EnableIso14443a(serialDevice);
                }
            }
            if ((iso14443BForm != null) && (!iso14443BForm.IsDisposed))
            {
                if (this.radioButtonISO14443B.Checked)
                {
                    iso14443BForm.EnableIso14443b(serialDevice);
                }
            }
            if ((felicaForm != null) && (!felicaForm.IsDisposed))
            {
                if (this.radioButtonFelica.Checked)
                {
                    felicaForm.EnableFelica(serialDevice);
                }
            }
        }

        private void DisableSonForm()
        {
            if ((iso15693Form != null) && (!iso15693Form.IsDisposed))
            {
                iso15693Form.DisableIso15693();
            }
            if ((iso14443AForm != null) && (!iso14443AForm.IsDisposed))
            {
                iso14443AForm.DisableIso14443a();
            }
            if ((nfcForm != null) && (!nfcForm.IsDisposed))
            {
                nfcForm.DisableNfc();
            }
            if ((iso14443BForm != null) && (!iso14443BForm.IsDisposed))
            {
                iso14443BForm.DisableIso14443b();
            }
            if ((felicaForm != null) && (!felicaForm.IsDisposed))
            {
                felicaForm.DisableFelica();
            }
            if ((updateSystemForm != null) && (!updateSystemForm.IsDisposed))
            {
                updateSystemForm.DisableUpdate();
            }
            if ((uartDebugForm != null) && (!uartDebugForm.IsDisposed))
            {
                uartDebugForm.DisableUartDebug();
            }
        }

        private void comboBoxTool_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBoxTool.SelectedIndex==4)
            {
                if (deviceTypeStr == "")
                {
                    MessageBox.Show(res.GetString("String7"));
                    this.comboBoxTool.SelectedIndex = 0;
                }
                else
                {
                    if (serialDevice == -1)
                    {
                        MessageBox.Show(res.GetString("String7"));
                        this.comboBoxTool.SelectedIndex = 0;
                        return;
                    }
                    LoginForm form = new LoginForm();
                    form.ShowDialog();
                    if (form.deviceType == deviceTypeStr)
                    {
                        DisableSonForm();
                        SpecialForm sf = new SpecialForm();
                        sf.fatherForm = this;
                        sf.serialDevice = serialDevice;
                        sf.ShowDialog();
                        this.comboBoxTool.SelectedIndex = 0;
                    }
                    else
                    {
                        MessageBox.Show(res.GetString("String8"));
                        this.comboBoxTool.SelectedIndex = 0;
                    }
                }
            }
            else if (this.comboBoxTool.SelectedIndex==3)
            {
                if (serialDevice == -1)
                {
                    MessageBox.Show(res.GetString("String7"));
                    this.comboBoxTool.SelectedIndex = 0;
                    return;
                }
                if (deviceTypeStr.IndexOf("R321") >= 0)
                {
                    if (updateSystemForm == null || updateSystemForm.IsDisposed)
                    {
                        DisableSonForm();
                        nfcForm = new NfcTools();
                        nfcForm.EnableNfc(serialDevice);
                        nfcForm.ShowDialog();
                        this.comboBoxTool.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show(res.GetString("String9"));
                    this.comboBoxTool.SelectedIndex = 0;
                }
            }
            else if (this.comboBoxTool.SelectedIndex==2)
            {
                crcForm crcfm = new crcForm();
                crcfm.ShowDialog();
                this.comboBoxTool.SelectedIndex = 0;
            }
            if (this.comboBoxTool.SelectedIndex==1)
            {
                if (serialDevice == -1)
                {
                    MessageBox.Show(res.GetString("String7"));
                    this.comboBoxTool.SelectedIndex = 0;
                    return;
                }
                if (uartDebugForm == null || uartDebugForm.IsDisposed)
                {
                    DisableSonForm();
                    uartDebugForm = new uartDebug();
                    uartDebugForm.serialDevice = serialDevice;
                    uartDebugForm.ShowDialog();
                    this.comboBoxTool.SelectedIndex = 0;
                }
            }
        }

        private void comboBoxTagOp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBoxTagOp.SelectedIndex == 4)
            {
                if (felicaForm == null || felicaForm.IsDisposed)
                {
                    felicaForm = new felica();
                    felicaForm.fatherForm = this;
                    if (this.radioButtonFelica.Checked)
                    {
                        felicaForm.EnableFelica(serialDevice);
                    }
                    else
                    {
                        felicaForm.DisableFelica();
                    }

                    felicaForm.Show();
                }
            }
            else if (this.comboBoxTagOp.SelectedIndex == 3)
            {
                if (iso15693Form == null || iso15693Form.IsDisposed)
                {
                    iso15693Form = new ISO15693();
                    iso15693Form.fatherForm = this;
                    if (this.radioButtonISO15693.Checked)
                    {
                        iso15693Form.EnableIso15693(serialDevice);
                    }
                    else
                    {
                        iso15693Form.DisableIso15693();
                    }
                 
                    LoadAll(iso15693Form);
                    iso15693Form.Show();
                }
            }
            else if (this.comboBoxTagOp.SelectedIndex == 2)
            {
                if (iso14443BForm == null || iso14443BForm.IsDisposed)
                {
                    iso14443BForm = new ISO14443B();
                    iso14443BForm.fatherForm = this;
                    if (this.radioButtonISO14443B.Checked)
                    {
                        iso14443BForm.EnableIso14443b(serialDevice);
                    }
                    else
                    {
                        iso14443BForm.DisableIso14443b();
                    }

                    iso14443BForm.Show();
                }
            }
            else if (this.comboBoxTagOp.SelectedIndex == 1)
            {
                if (iso14443AForm == null || iso14443AForm.IsDisposed)
                {
                    iso14443AForm = new ISO14443A();
                    iso14443AForm.fatherForm = this;
                    if (this.radioButtonISO14443A.Checked)
                    {
                        iso14443AForm.EnableIso14443a(serialDevice);
                    }
                    else
                    {
                        iso14443AForm.DisableIso14443a();
                    }
                    LoadAll(iso14443AForm);
                    iso14443AForm.Show();
                    iso14443AForm.CtrlUidEnalbe(this.radioButtonCmdModeAuto.Checked);
                }
            }
        }

        //ѡ�񴮿��б�
        private void comboBoxComPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bFormOk)
            {
                if (serialDevice > 0)
                {
                    int op = hfReaderDll.hfReaderClosePort(serialDevice);
                    if (op >= 0)
                    {
                        this.buttonOpenSerial.Text = "��";
                        this.comboBoxTagOp.Enabled = false;
                        DisableSonForm();
                    }
                    serialDevice = -1;
                }

                buttonOpenSerial_Click(null, null);
            }
        }

        private void comboBoxBaudrate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bFormOk)
            {
                if (serialDevice > 0)
                {
                    int op = hfReaderDll.hfReaderClosePort(serialDevice);
                    if (op >= 0)
                    {
                        this.buttonOpenSerial.Text = res.GetString("String10");
                        this.comboBoxTagOp.Enabled = false;
                        DisableSonForm();
                    }
                    serialDevice = -1;
                }

                buttonOpenSerial_Click(null, null);
            }
        }

        private void buttonClearInfo_Click(object sender, EventArgs e)
        {
            this.textBoxInf.Text = "";
        }

        private void radioButtonCmdModeAuto_CheckedChanged(object sender, EventArgs e)
        {
            if ((iso14443AForm != null) && (!iso14443AForm.IsDisposed))
            {
                iso14443AForm.CtrlUidEnalbe(this.radioButtonCmdModeAuto.Checked);
            }
        }

        private void comboBoxComInterface_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBoxComInterface.SelectedIndex == 0)
            {
                ShowComInfo("COM", serialDevice, "Close");
                this.comboBoxBaudrate.Enabled = true;
                this.comboBoxComPort.Enabled = true;
                this.comboBoxBaudrate.Show();
                this.comboBoxComPort.Show();
                this.labelCom.Show();
                this.labelBr.Show();

                this.labelUsbList.Enabled = false;
                this.comboBoxUsbList.Enabled = false;
                this.labelUsbList.Hide();
                this.comboBoxUsbList.Hide();

                this.groupBoxBr.Enabled = true;

                this.panelNetParams.Hide();
            }
            else if (this.comboBoxComInterface.SelectedIndex == 1)
            {
                ShowComInfo("USB", serialDevice, "Close");
                this.comboBoxBaudrate.Enabled = false;
                this.comboBoxComPort.Enabled = false;
                this.comboBoxBaudrate.Hide();
                this.comboBoxComPort.Hide();
                this.labelCom.Hide();
                this.labelBr.Hide();

                this.groupBoxBr.Enabled = false;

                this.labelUsbList.Enabled = true;
                this.comboBoxUsbList.Enabled = true;
                this.labelUsbList.Show();
                this.comboBoxUsbList.Show();

                this.panelNetParams.Hide();
            }
            else if (this.comboBoxComInterface.SelectedIndex == 2)
            {
                ShowComInfo("NET", serialDevice, "Close");
                this.comboBoxBaudrate.Enabled = false;
                this.comboBoxComPort.Enabled = false;
                this.comboBoxBaudrate.Hide();
                this.comboBoxComPort.Hide();
                this.labelCom.Hide();
                this.labelBr.Hide();

                this.groupBoxBr.Enabled = false;

                this.labelUsbList.Enabled = false;
                this.comboBoxUsbList.Enabled = false;
                this.labelUsbList.Hide();
                this.comboBoxUsbList.Hide();

                this.panelNetParams.Show();
            }
        }

        private void buttonGetV_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            HFREADER_VERSION pVersion = new HFREADER_VERSION();
            pVersion.type = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            pVersion.sv = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            pVersion.hv = new byte[hfReaderDll.HFREADER_VERSION_SIZE];
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            LockUart();
            int rlt = hfReaderDll.hfReaderGetVersion(serialDevice, addrArray[0], addrArray[1], ref pVersion, sendBuffer, rcvBuffer);
            UnlockUart();

            if (rlt > 0)
            {
                if (pVersion.result.flag == 0)
                {
                    this.textBoxGDeviceType.Text = System.Text.Encoding.Default.GetString(pVersion.type);
                    this.textBoxGDeviceSv.Text = System.Text.Encoding.Default.GetString(pVersion.sv);
                    this.textBoxGDeviceHv.Text = System.Text.Encoding.Default.GetString(pVersion.hv);
                }
                else
                {
                    this.textBoxGDeviceType.Text = "";
                    this.textBoxGDeviceSv.Text = "";
                    this.textBoxGDeviceHv.Text = "";
                }

                DisplayOpResult(pVersion.result);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String11"));
            DisplaySendInf(sendBuffer, res.GetString("String12"));
        }

        private void buttonCtrlAnt_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];
            int antNum = 0;

            antNum = Convert.ToInt32(comboBoxAntNum.SelectedItem.ToString());

            //Byte trgCtrl = 0;
            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            Byte[] ant = new Byte[antNum];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            ant[this.comboBoxAntCurIndex.SelectedIndex] = 0x01;

            LockUart();
            int rlt = hfReaderDll.hfReaderSelectAnt(serialDevice, addrArray[0], addrArray[1], antNum, ant, ref pResult, sendBuffer, rcvBuffer);
            UnlockUart();

            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String13"));
            DisplaySendInf(sendBuffer, res.GetString("String14"));
        }

        private void buttonCtrlPwr_Click(object sender, EventArgs e)
        {
            if (serialDevice < 0)
            {
                MessageBox.Show(res.GetString("Operror7"));
                return;
            }

            Byte[] buffer = new Byte[255];
            ushort[] addrArray = new ushort[2];

            //Byte trgCtrl = 0;
            HFREADER_OPRESULT pResult = new HFREADER_OPRESULT();
            Byte[] sendBuffer = new Byte[1024];
            Byte[] rcvBuffer = new Byte[1024];
            Byte[] powerParams = new Byte[2];

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }
            String antStr = comboBoxCtrlPwrAntIndex.SelectedItem.ToString();

            if (antStr == res.GetString("String15"))
            {
                powerParams[0] = 0xFF;
            }
            else
            {
                powerParams[0] = (Byte)comboBoxCtrlPwrAntIndex.SelectedIndex;
            }
            powerParams[1] = (Byte)comboBoxAntPower.SelectedIndex;

            LockUart();
            int rlt = hfReaderDll.hfReaderSetPower(serialDevice, addrArray[0], addrArray[1], powerParams[0], powerParams[1], ref pResult, sendBuffer, rcvBuffer);
            UnlockUart();

            if (rlt > 0)
            {
                DisplayOpResult(pResult);
            }
            DisplayRcvInf(rcvBuffer, res.GetString("String16"));
            DisplaySendInf(sendBuffer, res.GetString("String17"));
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show(res.GetString("HexError"));
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public string Hex2Str(Byte[] buffer, int start, int len)
        {
            int i = 0;
            string s = "";
            for (i = 0; i < len; i++)
            {
                s += buffer[start + i].ToString("X").PadLeft(2, '0');
            }

            return s;
        }

        private void comboBoxUsbList_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialDevice = usbHandleList[comboBoxUsbList.SelectedIndex];
            ShowComInfo("USB", serialDevice, "Open");
        }

        private void comboBoxAntNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            int antNum = 0;
            int i = 0;
            String s = "";
            s = this.comboBoxAntNum.SelectedItem.ToString();
            if (s != "")
            {
                antNum = Convert.ToInt32(s);
                comboBoxAntCurIndex.Items.Clear();
                for (i = 0; i < antNum; i++)
                {
                    comboBoxAntCurIndex.Items.Add((i + 1).ToString());
                }
            }
            else
            {
                comboBoxAntCurIndex.Items.Clear();
                for (i = 0; i < 8; i++)
                {
                    comboBoxAntCurIndex.Items.Add((i + 1).ToString());
                }
            }
            comboBoxAntCurIndex.SelectedIndex = 0;
        }


      
        

       
        
        private void LoadAll(Form form)
        {
            if (form.Name == "RFIDStation")
            {
                ChangeLang.LoadLanguage(form, typeof(RFIDStation));
            }
            else if (form.Name == "ISO15693")
            {
                ChangeLang.LoadLanguage(form, typeof(ISO15693));
            }

        }

        private void comboBoxLang_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            if (this.comboBoxLang.SelectedIndex==0)
            {
               
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("");
                ChangeLang.LoadLanguage(this, typeof(RFIDStation));

            }
            else if (this.comboBoxLang.SelectedIndex==1)
            {
                
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
               ChangeLang.LoadLanguage(this, typeof(RFIDStation));
              

            }
            comboBoxLang.Enabled = true;
        }
    }
    }