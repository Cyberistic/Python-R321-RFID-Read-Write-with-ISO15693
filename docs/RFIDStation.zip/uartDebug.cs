using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace RFIDStation
{
    public partial class uartDebug : Form
    {
        public delegate void Delegate(object obj);
        public int serialDevice;                   //�����豸
        public static Thread txFrameThread = null;
        private bool bScaning = false;
        public const int HFREADER_LONG_BUFFER_MAX = 4096;
        public const int HFREADER_FRAME_NUM_MAX = 100;
        Byte[,] txFrameArray = new Byte[HFREADER_FRAME_NUM_MAX, HFREADER_LONG_BUFFER_MAX];
        int[] txFrameLenArray = new int[HFREADER_FRAME_NUM_MAX];
        int[] txFrameTimeoutArray = new int[HFREADER_FRAME_NUM_MAX];
        int[] txFrameDelayArray = new int[HFREADER_FRAME_NUM_MAX];
        int txFrameNum = 0;
        int testNum = 0;
        int scanDelay = 0;

        public uartDebug()
        {
            InitializeComponent();
            serialDevice = -1;
            comboBoxCtrlCode.SelectedIndex = 0;
        }

        private void uartDebug_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dispose();
            Close();
        }

        public void StartUartDebug()
        {
            txFrameThread = new Thread(new ThreadStart(Transceive));
            txFrameThread.IsBackground = true;
            txFrameThread.Start();
        }

        private void Transceive()
        {

        }

        public void DisableUartDebug()
        {
            if (txFrameThread != null)
            {
                txFrameThread.Abort();
            }

            serialDevice = -1;
        }

        public int GetHexInput(String s, Byte[] buffer, int num)
        {
            int i = 0;
            if (s.Length != 2 * num)
            {
                MessageBox.Show("���ݳ��ȴ���");
                return -1;
            }
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return -1;
                }
            }
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        public int GetHexInput(String s, Byte[] buffer)
        {
            int i = 0;
            int num = 0;
            for (i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F'))
                {
                    MessageBox.Show("����16���Ƹ�ʽ�������ݣ����磺00 01 FF");
                    return 0;
                }
            }
            num = s.Length / 2;
            for (i = 0; i < num; i++)
            {
                buffer[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            }

            return num;
        }

        private bool GetDeviceAddr(ushort[] addArray)
        {
            bool b = false;
            byte[] buffer = new Byte[255];
            if (GetHexInput(textBoxSrcAddr.Text, buffer, 2) > 0)
            {
                addArray[0] = (ushort)(buffer[0] * 256 + buffer[1]);
                if (GetHexInput(textBoxDestAddr.Text, buffer, 2) > 0)
                {
                    addArray[1] = (ushort)(buffer[0] * 256 + buffer[1]);
                    b = true;
                }
            }

            return b;
        }

        private void AddDisplayInfo(object obj)
        {
            if (this.textBoxInf.InvokeRequired)
            {
                Delegate d = new Delegate(AddDisplayInfo);
                this.textBoxInf.Invoke(d, obj);

            }
            else
            {
                this.textBoxInf.Text = obj.ToString();
                textBoxInf.SelectionStart = textBoxInf.Text.Length;
                textBoxInf.ScrollToCaret();
            }
        }

        private void AddTestNum(object obj)
        {
            if (this.textBoxClrNum.InvokeRequired)
            {
                Delegate d = new Delegate(AddTestNum);
                this.textBoxClrNum.Invoke(d, obj);

            }
            else
            {
                this.textBoxClrNum.Text = obj.ToString();
            }
        }

        private void UpdateButtonSendSel(object obj)
        {
            if (this.buttonStartSendSel.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateButtonSendSel);
                this.buttonStartSendSel.Invoke(d, obj);

            }
            else
            {
                this.buttonStartSendSel.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void UpdateButtonOk(object obj)
        {
            if (this.buttonOk.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateButtonOk);
                this.buttonOk.Invoke(d, obj);

            }
            else
            {
                this.buttonOk.Enabled = Convert.ToBoolean(obj);
            }
        }

        private void UpdateButtonClearFrame(object obj)
        {
            if (this.buttonClearFrame.InvokeRequired)
            {
                Delegate d = new Delegate(UpdateButtonClearFrame);
                this.buttonClearFrame.Invoke(d, obj);

            }
            else
            {
                this.buttonClearFrame.Enabled = Convert.ToBoolean(obj);
            }
        }

        public void DisplayInf(Byte[] pRcvBuf, int len, String cmdNmae)
        {
            String text = this.textBoxInf.Text;

            String s = cmdNmae;

            s += Hex2Str(pRcvBuf, len, 0);

            s += "\r\n";
            AddDisplayInfo(text + s);
        }

        private string Hex2Str(Byte[] frame, int len, int start)
        {
            string s = "";
            int i = 0;
            for (i = 0; i < len; i++)
            {
                //s += "0x";
                s += frame[i + start].ToString("X").PadLeft(2, '0');
                //s += ",";
            }
            return s;
        }

        private void AddFrame(Byte[] frame, int len, int start)
        {
            int count = 0;
            int index = 0;

            count = dataGridViewFrames.RowCount + 1;

            DataGridViewRow row = new DataGridViewRow();
            index = dataGridViewFrames.Rows.Add(row);

            dataGridViewFrames.Rows[index].Cells[0].Value = false;
            dataGridViewFrames.Rows[index].Cells[1].Value = count.ToString();
            dataGridViewFrames.Rows[index].Cells[2].Value = Hex2Str(frame, len, start);
            dataGridViewFrames.Rows[index].Cells[3].Value = textBoxFrameTimeout.Text;
            dataGridViewFrames.Rows[index].Cells[4].Value = textBoxFrameDelay.Text;
            
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            ushort[] addrArray = new ushort[2];
            Byte[] cmd = new Byte[1];
            Byte longFrame = 0;
            Byte rspFrame = 0;

            Byte[] frame = new Byte[HFREADER_LONG_BUFFER_MAX];
            int frameLen = 0;
            Byte[] param = new Byte[HFREADER_LONG_BUFFER_MAX];
            int paramsLen = 0;

            textBoxParm.Text = textBoxParm.Text.Replace(" ", "");
            textBoxParm.Text = textBoxParm.Text.Replace("0x", "");
            textBoxParm.Text = textBoxParm.Text.Replace(",", "");

            if (!GetDeviceAddr(addrArray))
            {
                return;
            }

            if (this.checkBoxLongFrame.Checked)
            {
                longFrame = 1;
            }

            if (this.comboBoxCtrlCode.SelectedIndex == 1)
            {
                rspFrame = 1;
            }

            if(GetHexInput(this.textBoxCmd.Text, cmd, 1) != 1)
            {
                return;
            }

            paramsLen = GetHexInput(this.textBoxParm.Text, param);
            /*frame[0] = 0xFE;
            int i = 0;
            for (i = 0; i < 14; i++)
            {
                frame[i + 1] = (Byte)(param[i] << 1);
            }
            frame[i + 1] = 0xFE;
            DisplayInf(frame, 16, "");*/
            

            frameLen = hfReaderDll.hfReaderFormatFrame(addrArray[0], addrArray[1], cmd[0], rspFrame, longFrame, param, paramsLen, frame);

            if (frameLen > 0)
            {
                DisplayInf(frame, frameLen, "��������֡��");
                AddFrame(frame, frameLen, 0);
            }
            DisplayInf(null, 0, "");
        }

        private void buttonClearInf_Click(object sender, EventArgs e)
        {
            this.textBoxInf.Text = "";
        }

        private void TransceiveFrame(Byte[] txFrame, int txLen, int timeout, int delay)
        {
            Byte[] rxFrame = new byte[HFREADER_LONG_BUFFER_MAX];
            int rlt = 0;

            Stopwatch sw = new Stopwatch();
            sw.Start();
            rlt = hfReaderDll.hfReaderTransFrame(serialDevice, txFrame, (uint)txLen);
            sw.Stop();
            if (rlt > 0)
            {
                DisplayInf(txFrame, txLen, "��������֡��");

                rlt = hfReaderDll.hfReaderReceiveFrame(serialDevice, rxFrame, timeout);
                if (rlt > 0)
                {
                    DisplayInf(rxFrame, rlt, "��������֡��");
                    DisplayInf(null, 0, "��ʱ��" + sw.ElapsedMilliseconds.ToString("D") + "ms");
                }
                else
                {
                    DisplayInf(rxFrame, 0, "��������֡��ʧ��");
                }
            }
            else
            {
                DisplayInf(txFrame, 0, "��������֡��ʧ��");
            }
            DisplayInf(null, 0, "");
            Thread.Sleep(delay);
        }

        private int GetFrame(DataGridViewRow row, Byte[] txFrame, ref int timeout, ref int delay)
        {
            int txLen = 0;
            string str = "";

            if ((row.Cells[2].Value != null) && (row.Cells[3].Value != null) && (row.Cells[4].Value != null))
            {
                str = row.Cells[2].Value.ToString();
                txLen = GetHexInput(str, txFrame, str.Length >> 1);

                try
                {
                    timeout = Convert.ToInt32(row.Cells[3].Value);
                }
                catch (Exception e)
                {
                    txLen = 0;
                }
                try
                {
                    delay = Convert.ToInt32(row.Cells[4].Value);
                }
                catch (Exception e)
                {
                    txLen = 0;
                }
            }

            return txLen;
        }

        private void buttonStartSendSel_Click(object sender, EventArgs e)
        {
            if (dataGridViewFrames.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridViewFrames.SelectedRows[0];
                if (row != null)
                {
                    int txLen = 0, timeout = 0, delay = 0;
                    Byte[] txFrame = new Byte[HFREADER_LONG_BUFFER_MAX];
                    txLen = GetFrame(row, txFrame, ref timeout, ref delay);
                    if (txLen > 0)
                    {
                        TransceiveFrame(txFrame, txLen, timeout, delay);
                    }
                    else
                    {
                        DisplayInf(null, 0, "�����ݻ����ݴ���");
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("����ѡ����Ҫ���͵�����֡!");
            }

        }

        private void ScanFrame()
        {
            int index = 0;
            Byte[] frame = new Byte[HFREADER_LONG_BUFFER_MAX];

            UpdateButtonClearFrame(false);
            UpdateButtonOk(false);
            UpdateButtonSendSel(false);
            while(bScaning == true)
            {
                int j = 0;
                for (j = 0; j < txFrameLenArray[index]; j++)
                {
                    frame[j] = txFrameArray[index, j];
                }
                //Array.Copy(txFrameArray, index * HFREADER_LONG_BUFFER_MAX, frame, 0, txFrameLenArray[index]);
                TransceiveFrame(frame, txFrameLenArray[index], txFrameTimeoutArray[index], txFrameDelayArray[index]);
                index++;
                if (index == txFrameNum)
                {
                    index = 0;
                    testNum++;
                    AddTestNum(testNum);
                    Thread.Sleep(scanDelay);
                }
            }
            bScaning = false;
            UpdateButtonClearFrame(true);
            UpdateButtonOk(true);
            UpdateButtonSendSel(true);
            if (txFrameThread != null)
            {
                txFrameThread.Abort();
            }
            txFrameThread = null;
        }

        private void buttonSendClr_Click(object sender, EventArgs e)
        {
            if (buttonSendClr.Text == "ѭ������")
            {
                
                int i = 0;
                txFrameNum = 0;
                for (i = 0; i < dataGridViewFrames.RowCount; i++)
                {
                    DataGridViewCheckBoxCell checkCell = (DataGridViewCheckBoxCell)dataGridViewFrames.Rows[i].Cells[0]; 
                    Boolean flag = Convert.ToBoolean(checkCell.Value); 
                    if(flag == true)
                    {
                        int txLen = 0;
                        Byte[] frame = new Byte[HFREADER_LONG_BUFFER_MAX];
                        int timeout = 0, delay = 0;
                        txLen = GetFrame(dataGridViewFrames.Rows[i], frame, ref timeout, ref delay);
                        if (txLen > 0 && txLen < HFREADER_LONG_BUFFER_MAX)
                        {
                            int j = 0;
                            for (j = 0; j < txLen; j++)
                            {
                                txFrameArray[txFrameNum, j] = frame[j];
                            }
                            txFrameLenArray[txFrameNum] = txLen;
                            txFrameTimeoutArray[txFrameNum] = timeout;
                            txFrameDelayArray[txFrameNum] = delay;
                            txFrameNum++;
                            if (txFrameNum == HFREADER_FRAME_NUM_MAX)
                            {
                                DisplayInf(null, 0, "���ֻ�ܷ���" + HFREADER_FRAME_NUM_MAX.ToString() + "����Ϣ");
                                break;
                            }
                        }
                    }
                }
                try
                {
                    scanDelay = Convert.ToInt32(textBoxClrDelay.Text);
                }
                catch (Exception ex)
                {
                    scanDelay = 1000;
                    textBoxClrDelay.Text = scanDelay.ToString();
                }
                if (txFrameNum == 0)
                {
                    DisplayInf(null, 0, "û�пɷ��͵�����֡");
                }
                else
                {
                    buttonSendClr.Text = "ֹͣ����";
                    testNum = 0;
                    AddTestNum(0);
                    bScaning = true;
                    txFrameThread = new Thread(new ThreadStart(ScanFrame));
                    txFrameThread.IsBackground = true;
                    txFrameThread.Start();  
                }
            }
            else
            {
                bScaning = false;
                Thread.Sleep(2000);
                buttonSendClr.Text = "ѭ������";
            }
        }

        private void buttonClearFrame_Click(object sender, EventArgs e)
        {
            dataGridViewFrames.Rows.Clear();
        }
    }
}