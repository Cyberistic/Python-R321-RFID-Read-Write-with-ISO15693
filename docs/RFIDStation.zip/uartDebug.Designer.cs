namespace RFIDStation
{
    partial class uartDebug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxInf = new System.Windows.Forms.TextBox();
            this.buttonClearInf = new System.Windows.Forms.Button();
            this.dataGridViewFrames = new System.Windows.Forms.DataGridView();
            this.EnableTx = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ColumnIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Frame = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RcvTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxParm = new System.Windows.Forms.TextBox();
            this.buttonOk = new System.Windows.Forms.Button();
            this.textBoxCmd = new System.Windows.Forms.TextBox();
            this.comboBoxCtrlCode = new System.Windows.Forms.ComboBox();
            this.textBoxDestAddr = new System.Windows.Forms.TextBox();
            this.textBoxSrcAddr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBoxLongFrame = new System.Windows.Forms.CheckBox();
            this.buttonStartSendSel = new System.Windows.Forms.Button();
            this.buttonSendClr = new System.Windows.Forms.Button();
            this.checkBoxLog = new System.Windows.Forms.CheckBox();
            this.textBoxClrNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxClrDelay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonClearFrame = new System.Windows.Forms.Button();
            this.textBoxFrameTimeout = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxFrameDelay = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFrames)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxInf);
            this.groupBox3.Location = new System.Drawing.Point(7, 396);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(816, 274);
            this.groupBox3.TabIndex = 163;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "���";
            // 
            // textBoxInf
            // 
            this.textBoxInf.Location = new System.Drawing.Point(8, 15);
            this.textBoxInf.Multiline = true;
            this.textBoxInf.Name = "textBoxInf";
            this.textBoxInf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxInf.Size = new System.Drawing.Size(802, 253);
            this.textBoxInf.TabIndex = 5;
            // 
            // buttonClearInf
            // 
            this.buttonClearInf.Location = new System.Drawing.Point(763, 373);
            this.buttonClearInf.Name = "buttonClearInf";
            this.buttonClearInf.Size = new System.Drawing.Size(60, 23);
            this.buttonClearInf.TabIndex = 162;
            this.buttonClearInf.Text = "���";
            this.buttonClearInf.UseVisualStyleBackColor = true;
            this.buttonClearInf.Click += new System.EventHandler(this.buttonClearInf_Click);
            // 
            // dataGridViewFrames
            // 
            this.dataGridViewFrames.AllowUserToAddRows = false;
            this.dataGridViewFrames.AllowUserToResizeColumns = false;
            this.dataGridViewFrames.AllowUserToResizeRows = false;
            this.dataGridViewFrames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewFrames.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EnableTx,
            this.ColumnIndex,
            this.Frame,
            this.RcvTo,
            this.Delay});
            this.dataGridViewFrames.Location = new System.Drawing.Point(7, 137);
            this.dataGridViewFrames.MultiSelect = false;
            this.dataGridViewFrames.Name = "dataGridViewFrames";
            this.dataGridViewFrames.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridViewFrames.RowHeadersWidth = 10;
            this.dataGridViewFrames.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewFrames.RowTemplate.Height = 23;
            this.dataGridViewFrames.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewFrames.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFrames.Size = new System.Drawing.Size(816, 230);
            this.dataGridViewFrames.TabIndex = 160;
            // 
            // EnableTx
            // 
            this.EnableTx.HeaderText = "ʹ��";
            this.EnableTx.Name = "EnableTx";
            this.EnableTx.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.EnableTx.Width = 40;
            // 
            // ColumnIndex
            // 
            this.ColumnIndex.HeaderText = "���";
            this.ColumnIndex.MaxInputLength = 5;
            this.ColumnIndex.Name = "ColumnIndex";
            this.ColumnIndex.ReadOnly = true;
            this.ColumnIndex.Width = 45;
            // 
            // Frame
            // 
            this.Frame.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Frame.HeaderText = "Frame";
            this.Frame.Name = "Frame";
            this.Frame.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RcvTo
            // 
            this.RcvTo.HeaderText = "��ʱ";
            this.RcvTo.MaxInputLength = 5;
            this.RcvTo.Name = "RcvTo";
            this.RcvTo.Width = 45;
            // 
            // Delay
            // 
            this.Delay.HeaderText = "��ʱ";
            this.Delay.MaxInputLength = 5;
            this.Delay.Name = "Delay";
            this.Delay.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Delay.Width = 45;
            // 
            // textBoxParm
            // 
            this.textBoxParm.Location = new System.Drawing.Point(62, 32);
            this.textBoxParm.Multiline = true;
            this.textBoxParm.Name = "textBoxParm";
            this.textBoxParm.Size = new System.Drawing.Size(761, 71);
            this.textBoxParm.TabIndex = 159;
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(763, 4);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(60, 23);
            this.buttonOk.TabIndex = 161;
            this.buttonOk.Text = "ȷ��";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // textBoxCmd
            // 
            this.textBoxCmd.Location = new System.Drawing.Point(405, 5);
            this.textBoxCmd.MaxLength = 2;
            this.textBoxCmd.Name = "textBoxCmd";
            this.textBoxCmd.Size = new System.Drawing.Size(35, 21);
            this.textBoxCmd.TabIndex = 156;
            this.textBoxCmd.Text = "00";
            // 
            // comboBoxCtrlCode
            // 
            this.comboBoxCtrlCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCtrlCode.FormattingEnabled = true;
            this.comboBoxCtrlCode.Items.AddRange(new object[] {
            "����",
            "��Ӧ"});
            this.comboBoxCtrlCode.Location = new System.Drawing.Point(281, 5);
            this.comboBoxCtrlCode.Name = "comboBoxCtrlCode";
            this.comboBoxCtrlCode.Size = new System.Drawing.Size(48, 20);
            this.comboBoxCtrlCode.TabIndex = 155;
            // 
            // textBoxDestAddr
            // 
            this.textBoxDestAddr.Location = new System.Drawing.Point(170, 5);
            this.textBoxDestAddr.MaxLength = 5;
            this.textBoxDestAddr.Name = "textBoxDestAddr";
            this.textBoxDestAddr.Size = new System.Drawing.Size(37, 21);
            this.textBoxDestAddr.TabIndex = 154;
            this.textBoxDestAddr.Text = "0001";
            // 
            // textBoxSrcAddr
            // 
            this.textBoxSrcAddr.Location = new System.Drawing.Point(62, 5);
            this.textBoxSrcAddr.MaxLength = 5;
            this.textBoxSrcAddr.Name = "textBoxSrcAddr";
            this.textBoxSrcAddr.Size = new System.Drawing.Size(37, 21);
            this.textBoxSrcAddr.TabIndex = 153;
            this.textBoxSrcAddr.Text = "0000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label9.Location = new System.Drawing.Point(4, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 150;
            this.label9.Text = "��������";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.Location = new System.Drawing.Point(346, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 147;
            this.label6.Text = "��  ��  ��";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label5.Location = new System.Drawing.Point(223, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 146;
            this.label5.Text = "��  ��  ��";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label4.Location = new System.Drawing.Point(112, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 145;
            this.label4.Text = "Ŀ���ַ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.Location = new System.Drawing.Point(4, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 144;
            this.label3.Text = "Դ  ��  ַ";
            // 
            // checkBoxLongFrame
            // 
            this.checkBoxLongFrame.AutoSize = true;
            this.checkBoxLongFrame.Location = new System.Drawing.Point(693, 7);
            this.checkBoxLongFrame.Name = "checkBoxLongFrame";
            this.checkBoxLongFrame.Size = new System.Drawing.Size(60, 16);
            this.checkBoxLongFrame.TabIndex = 169;
            this.checkBoxLongFrame.Text = "����֡";
            this.checkBoxLongFrame.UseVisualStyleBackColor = true;
            // 
            // buttonStartSendSel
            // 
            this.buttonStartSendSel.Location = new System.Drawing.Point(663, 109);
            this.buttonStartSendSel.Name = "buttonStartSendSel";
            this.buttonStartSendSel.Size = new System.Drawing.Size(94, 23);
            this.buttonStartSendSel.TabIndex = 173;
            this.buttonStartSendSel.Text = "���͵�֡";
            this.buttonStartSendSel.UseVisualStyleBackColor = true;
            this.buttonStartSendSel.Click += new System.EventHandler(this.buttonStartSendSel_Click);
            // 
            // buttonSendClr
            // 
            this.buttonSendClr.Location = new System.Drawing.Point(563, 109);
            this.buttonSendClr.Name = "buttonSendClr";
            this.buttonSendClr.Size = new System.Drawing.Size(94, 23);
            this.buttonSendClr.TabIndex = 174;
            this.buttonSendClr.Text = "ѭ������";
            this.buttonSendClr.UseVisualStyleBackColor = true;
            this.buttonSendClr.Click += new System.EventHandler(this.buttonSendClr_Click);
            // 
            // checkBoxLog
            // 
            this.checkBoxLog.AutoSize = true;
            this.checkBoxLog.Location = new System.Drawing.Point(255, 112);
            this.checkBoxLog.Name = "checkBoxLog";
            this.checkBoxLog.Size = new System.Drawing.Size(48, 16);
            this.checkBoxLog.TabIndex = 175;
            this.checkBoxLog.Text = "��־";
            this.checkBoxLog.UseVisualStyleBackColor = true;
            // 
            // textBoxClrNum
            // 
            this.textBoxClrNum.Location = new System.Drawing.Point(383, 110);
            this.textBoxClrNum.MaxLength = 5;
            this.textBoxClrNum.Name = "textBoxClrNum";
            this.textBoxClrNum.Size = new System.Drawing.Size(48, 21);
            this.textBoxClrNum.TabIndex = 177;
            this.textBoxClrNum.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label1.Location = new System.Drawing.Point(326, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 176;
            this.label1.Text = "ѭ������";
            // 
            // textBoxClrDelay
            // 
            this.textBoxClrDelay.Location = new System.Drawing.Point(506, 110);
            this.textBoxClrDelay.MaxLength = 5;
            this.textBoxClrDelay.Name = "textBoxClrDelay";
            this.textBoxClrDelay.Size = new System.Drawing.Size(48, 21);
            this.textBoxClrDelay.TabIndex = 179;
            this.textBoxClrDelay.Text = "1000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(449, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 178;
            this.label2.Text = "ѭ�����";
            // 
            // buttonClearFrame
            // 
            this.buttonClearFrame.Location = new System.Drawing.Point(763, 109);
            this.buttonClearFrame.Name = "buttonClearFrame";
            this.buttonClearFrame.Size = new System.Drawing.Size(60, 23);
            this.buttonClearFrame.TabIndex = 180;
            this.buttonClearFrame.Text = "���";
            this.buttonClearFrame.UseVisualStyleBackColor = true;
            this.buttonClearFrame.Click += new System.EventHandler(this.buttonClearFrame_Click);
            // 
            // textBoxFrameTimeout
            // 
            this.textBoxFrameTimeout.Location = new System.Drawing.Point(514, 5);
            this.textBoxFrameTimeout.MaxLength = 5;
            this.textBoxFrameTimeout.Name = "textBoxFrameTimeout";
            this.textBoxFrameTimeout.Size = new System.Drawing.Size(46, 21);
            this.textBoxFrameTimeout.TabIndex = 182;
            this.textBoxFrameTimeout.Text = "100";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.Location = new System.Drawing.Point(456, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 181;
            this.label7.Text = "��Ӧ��ʱ";
            // 
            // textBoxFrameDelay
            // 
            this.textBoxFrameDelay.Location = new System.Drawing.Point(630, 5);
            this.textBoxFrameDelay.MaxLength = 5;
            this.textBoxFrameDelay.Name = "textBoxFrameDelay";
            this.textBoxFrameDelay.Size = new System.Drawing.Size(46, 21);
            this.textBoxFrameDelay.TabIndex = 184;
            this.textBoxFrameDelay.Text = "100";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label8.Location = new System.Drawing.Point(572, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 183;
            this.label8.Text = "������ʱ";
            // 
            // uartDebug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 682);
            this.Controls.Add(this.textBoxFrameDelay);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxFrameTimeout);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.buttonClearFrame);
            this.Controls.Add(this.textBoxClrDelay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxClrNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBoxLog);
            this.Controls.Add(this.buttonSendClr);
            this.Controls.Add(this.buttonStartSendSel);
            this.Controls.Add(this.checkBoxLongFrame);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.buttonClearInf);
            this.Controls.Add(this.dataGridViewFrames);
            this.Controls.Add(this.textBoxParm);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.textBoxCmd);
            this.Controls.Add(this.comboBoxCtrlCode);
            this.Controls.Add(this.textBoxDestAddr);
            this.Controls.Add(this.textBoxSrcAddr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "uartDebug";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "���ڵ���";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.uartDebug_FormClosing);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFrames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxInf;
        private System.Windows.Forms.Button buttonClearInf;
        private System.Windows.Forms.DataGridView dataGridViewFrames;
        private System.Windows.Forms.TextBox textBoxParm;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.TextBox textBoxCmd;
        private System.Windows.Forms.ComboBox comboBoxCtrlCode;
        private System.Windows.Forms.TextBox textBoxDestAddr;
        private System.Windows.Forms.TextBox textBoxSrcAddr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxLongFrame;
        private System.Windows.Forms.Button buttonStartSendSel;
        private System.Windows.Forms.Button buttonSendClr;
        private System.Windows.Forms.DataGridViewCheckBoxColumn EnableTx;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnIndex;
        private System.Windows.Forms.DataGridViewTextBoxColumn Frame;
        private System.Windows.Forms.DataGridViewTextBoxColumn RcvTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Delay;
        private System.Windows.Forms.CheckBox checkBoxLog;
        private System.Windows.Forms.TextBox textBoxClrNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxClrDelay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonClearFrame;
        private System.Windows.Forms.TextBox textBoxFrameTimeout;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxFrameDelay;
        private System.Windows.Forms.Label label8;
    }
}